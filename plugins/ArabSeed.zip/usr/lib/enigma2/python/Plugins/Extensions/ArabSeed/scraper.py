# -*- coding: utf-8 -*-
"""
===================================================================
 ArabSeed Scraper Engine for Enigma2 - HIGH SPEED & STREAM EXTRACTOR
 Handles HTTP requests, Cloudflare bypass detection, poster caching,
 regex-based stream resolving (m3u8, mp4, p.a.c.k.e.r, iframes, API).
 Fixed:
   - Enhanced Poster Extraction (data-src, data-lazy-src, srcset, src)
   - Proper Referer header injection for Anti-Hotlinking protection
   - Safe URL encoding for Arabic / special characters
===================================================================
"""

import sys
import re
import os
import zlib
import gzip
import json

PY3 = sys.version_info[0] == 3
if PY3:
    import urllib.request as urllib2
    from urllib.parse import urljoin, quote, unquote, urlparse
    from io import BytesIO
else:
    import urllib2
    from urlparse import urljoin, urlparse
    from urllib import quote, unquote
    from StringIO import StringIO as BytesIO

LOG_FILE = "/tmp/arabseed.log"

def log_debug(msg):
    try:
        with open(LOG_FILE, "a") as f:
            f.write("[ArabSeed] " + str(msg) + "\n")
    except Exception:
        pass
    print("[ArabSeed] " + str(msg))

def safe_url(url):
    if not url:
        return ""
    if PY3:
        import urllib.parse
        return urllib.parse.quote(str(url), safe=":/%?&=+#@!$,;'*()")
    else:
        import urllib
        try:
            if isinstance(url, unicode):
                url = url.encode("utf-8")
        except NameError:
            pass
        return urllib.quote(str(url), safe=":/%?&=+#@!$,;'*()")

def baseN_decode(s, b):
    chars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
    val = 0
    for c in s:
        idx = chars.find(c)
        if idx != -1 and idx < b:
            val = val * b + idx
    return val

ssl_context = None
try:
    import ssl
    ssl_context = ssl._create_unverified_context()
except Exception:
    ssl_context = None

def extract_poster_url(inner_html, base_url="https://arabseed.store"):
    """
    استخراج دقيق للبوستر مع دعم التحميل الكسول وتخطي الصور الفارغة أو الـ SVG
    """
    if not inner_html:
        return ""
    patterns = [
        r'data-src=["\']([^"\']+)["\']',
        r'data-lazy-src=["\']([^"\']+)["\']',
        r'data-original=["\']([^"\']+)["\']',
        r'data-img=["\']([^"\']+)["\']',
        r'srcset=["\']([^"\'\s]+)',
        r'<img[^>]+src=["\']([^"\']+)["\']',
        r'url\(["\']?([^"\'\)]+)["\']?\)'
    ]
    for p in patterns:
        matches = re.findall(p, inner_html, re.IGNORECASE)
        for m in matches:
            m = m.strip()
            if m and not m.startswith("data:image") and not m.endswith(".svg") and "placeholder" not in m.lower():
                if m.startswith("//"):
                    return "https:" + m
                elif not m.startswith("http"):
                    return urljoin(base_url, m)
                return m

    m = re.search(r'<img[^>]+src=["\']([^"\']+)["\']', inner_html, re.IGNORECASE)
    if m:
        val = m.group(1).strip()
        if val and not val.startswith("data:image"):
            if val.startswith("//"):
                return "https:" + val
            elif not val.startswith("http"):
                return urljoin(base_url, val)
            return val
    return ""

class ArabSeedScraper:
    def __init__(self, base_url="https://arabseed.store"):
        self.base_url = (base_url or "https://arabseed.store").rstrip("/")
        self.last_error = ""
        self.memory_cache = {}
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
            "Accept-Language": "ar,en-US;q=0.9,en;q=0.8",
            "Accept-Encoding": "gzip, deflate",
            "Connection": "keep-alive"
        }

    def fetch_html(self, url, use_cache=True, custom_headers=None):
        if not url.startswith("http"):
            url = urljoin(self.base_url, url)
        url = safe_url(url)
        if use_cache and url in self.memory_cache:
            return self.memory_cache[url]

        log_debug("Fetching URL: " + url)
        self.last_error = ""
        req_headers = dict(self.headers)
        if custom_headers:
            req_headers.update(custom_headers)

        # Try requests if available
        try:
            import requests
            r = requests.get(url, headers=req_headers, verify=False, timeout=8)
            text = r.text
            if "Just a moment..." in text or "challenge-platform" in text:
                self.last_error = "CLOUDFLARE_BLOCKED"
                return ""
            if use_cache:
                self.memory_cache[url] = text
            return text
        except ImportError:
            pass
        except Exception as e:
            log_debug("Requests error: " + str(e))

        # Standard urllib fallback
        try:
            req = urllib2.Request(url, headers=req_headers)
            if ssl_context:
                res = urllib2.urlopen(req, timeout=8, context=ssl_context)
            else:
                res = urllib2.urlopen(req, timeout=8)

            raw_data = res.read()
            encoding = res.headers.get("Content-Encoding", "").lower()
            if encoding == "gzip" or raw_data[:2] == b"\x1f\x8b":
                try:
                    raw_data = gzip.GzipFile(fileobj=BytesIO(raw_data)).read()
                except Exception:
                    pass
            elif encoding == "deflate":
                try:
                    raw_data = zlib.decompress(raw_data)
                except Exception:
                    pass

            if PY3:
                html = raw_data.decode("utf-8", errors="ignore")
            else:
                html = raw_data

            if "Just a moment..." in html or "challenge-platform" in html:
                self.last_error = "CLOUDFLARE_BLOCKED"
                return ""

            if use_cache:
                self.memory_cache[url] = html
            return html
        except Exception as e:
            log_debug("Fetch error: " + str(e))
            self.last_error = str(e)
            return ""

    def check_connection(self):
        html = self.fetch_html(self.base_url, use_cache=False)
        if self.last_error == "CLOUDFLARE_BLOCKED":
            return False, "النطاق محمي بـ Cloudflare"
        if html and len(html) > 300:
            return True, "تم الاتصال بنجاح"
        return False, self.last_error or "تعذر الاتصال بالخادم"

    def get_items(self, path="/main/", page=1):
        if path in ["/home/", "/home"]:
            path = "/main/"
        if page > 1:
            if "?" in path:
                target_url = path + "&page=" + str(page)
            else:
                target_url = path.rstrip("/") + "/page/" + str(page) + "/"
        else:
            target_url = path

        html = self.fetch_html(target_url)
        if not html:
            return []

        items = []
        p1 = re.compile(
            r'<a[^>]*href=["\']([^"\']+)["\'][^>]*title=["\']([^"\']+)["\'][^>]*class=["\'][^"\']*movie__block[^"\']*["\'][^>]*>(.*?)</a>',
            re.DOTALL | re.IGNORECASE
        )
        matches1 = p1.findall(html)
        if matches1:
            for href, title, inner in matches1:
                poster = extract_poster_url(inner, self.base_url)
                q_m = re.search(r'class=["\'][^"\']*__quality[^"\']*["\'][^>]*>([^<]*)<', inner, re.IGNORECASE)
                quality = q_m.group(1).strip() if q_m else "HD"
                year_m = re.search(r'\(?\b(20\d\d|19\d\d)\b\)?', title)
                year = year_m.group(1) if year_m else "2024"
                clean_title = re.sub(r'\s+', ' ', title).strip()
                is_series = any(x in clean_title for x in ["مسلسل", "الموسم", "الحلقة"]) or "/series/" in href
                items.append({
                    "title": clean_title,
                    "url": href,
                    "poster": poster,
                    "year": year,
                    "quality": quality,
                    "is_series": is_series
                })
            return items

        p2 = re.compile(
            r'<div[^>]*class=["\']([^"\']*(?:MovieBlock|BlockItem|post-item|movie-item)[^"\']*)["\'][^>]*>(.*?)</div>\s*</div>',
            re.DOTALL | re.IGNORECASE
        )
        matches2 = p2.findall(html)
        if matches2:
            for block_class, inner in matches2:
                a_m = re.search(r'<a[^>]*href=["\']([^"\']+)["\'][^>]*title=["\']([^"\']+)["\']', inner)
                if not a_m:
                    continue
                href, title = a_m.group(1), a_m.group(2)
                poster = extract_poster_url(inner, self.base_url)
                clean_title = re.sub(r'\s+', ' ', title).strip()
                is_series = "مسلسل" in clean_title or "/series/" in href
                year_m = re.search(r'\(?\b(20\d\d|19\d\d)\b\)?', clean_title)
                year = year_m.group(1) if year_m else "2024"
                items.append({
                    "title": clean_title,
                    "url": href,
                    "poster": poster,
                    "year": year,
                    "quality": "1080p FHD",
                    "is_series": is_series
                })
            return items
        return items

    def get_episodes(self, series_url):
        html = self.fetch_html(series_url)
        if not html:
            return []
        episodes = []
        ep_blocks = re.findall(r'<ul class=["\']episodes__list[^"]*["\']>.*?</ul>', html, re.DOTALL)
        if ep_blocks:
            matches = re.findall(r'<a[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', ep_blocks[0], re.DOTALL)
            for href, inner in matches:
                clean_text = re.sub(r'<[^>]+>', ' ', inner).strip()
                if not clean_text:
                    num_m = re.search(r'الحلقة-(\d+)', href)
                    clean_text = "الحلقة " + (num_m.group(1) if num_m else "1")
                episodes.append({"title": clean_text, "url": href})
            return episodes

        matches = re.findall(r'<a[^>]*href=["\']([^"\']+)["\'][^>]*>(?:.*?)(?:الحلقة|Episode)\s*(\d+|الأخيرة|[^\s<]+)(?:.*?)</a>', html, re.IGNORECASE | re.DOTALL)
        for href, num in matches:
            episodes.append({"title": "الحلقة " + str(num).strip(), "url": href})
        return episodes

    def get_servers(self, media_url):
        servers = []
        if not media_url:
            return servers

        watch_url = media_url.rstrip("/") + "/watch/"
        watch_html = self.fetch_html(watch_url)
        if not watch_html:
            watch_html = self.fetch_html(media_url)

        if watch_html:
            server_matches = re.findall(
                r'<li[^>]*data-(?:src|url|embed)=["\']([^"\']+)["\'][^>]*>(.*?)</li>',
                watch_html,
                re.DOTALL | re.IGNORECASE
            )
            for s_url, inner in server_matches:
                name_m = re.search(r'<span>([^<]+)</span>', inner)
                raw_name = name_m.group(1).strip() if name_m else "Server"
                if "/watch/?url=" in s_url:
                    s_url = s_url.split("/watch/?url=")[-1]

                low_url = s_url.lower()
                if "vidara" in low_url:
                    s_name = "سيرفر Vidaraa (M3U8 سريع)"
                elif "vidmoly" in low_url:
                    s_name = "سيرفر VidMoly"
                elif "voe" in low_url:
                    s_name = "سيرفر VOE (Full HD)"
                elif "arabseed" in low_url or "reviewrate" in low_url:
                    s_name = "سيرفر عرب سيد الرسمي"
                else:
                    s_name = raw_name

                servers.append({
                    "name": s_name,
                    "url": s_url,
                    "quality": "Multi"
                })

            iframes = re.findall(r'<iframe[^>]*src=["\']([^"\']+)["\']', watch_html, re.IGNORECASE)
            for ifr in iframes:
                if "/watch/?url=" in ifr:
                    ifr = ifr.split("/watch/?url=")[-1]
                if not any(s["url"] == ifr for s in servers):
                    servers.append({
                        "name": "سيرفر مدمج (Fast Stream)",
                        "url": ifr,
                        "quality": "1080p"
                    })

        download_url = media_url.rstrip("/") + "/download/"
        download_html = self.fetch_html(download_url)
        if download_html:
            d_matches = re.findall(
                r'<a[^>]*href=["\']([^"\']+)["\'][^>]*class=["\'][^"\']*download__item[^"\']*["\'][^>]*>(.*?)</a>',
                download_html,
                re.DOTALL | re.IGNORECASE
            )
            for d_href, d_inner in d_matches:
                h4 = re.search(r'<h4>([^<]+)</h4>', d_inner)
                host_name = h4.group(1).strip() if h4 else "Direct"
                if not d_href.startswith("http"):
                    d_href = urljoin(self.base_url, d_href)
                servers.append({
                    "name": "تحميل/بث مباشر: " + host_name,
                    "url": d_href,
                    "quality": "Direct MP4"
                })

        return servers

    def resolve_stream_url(self, server_url):
        if not server_url:
            return "", ""

        log_debug("Resolving: " + server_url)

        if "/watch/?url=" in server_url:
            server_url = server_url.split("/watch/?url=")[-1]

        parsed = urlparse(server_url)
        referer = "%s://%s/" % (parsed.scheme or "https", parsed.netloc)
        low = server_url.lower()

        if any(ext in low for ext in [".m3u8", ".mp4", ".mkv", ".ts", "/hls/"]):
            return server_url, referer

        if "vidaraa" in low or "vidara" in low:
            try:
                filecode = server_url.rstrip("/").split("/")[-1]
                api_url = "https://vidaraa.cc/api/stream"
                payload = json.dumps({"filecode": filecode, "device": "desktop"}).encode("utf-8")
                req = urllib2.Request(
                    api_url,
                    data=payload,
                    headers={
                        "Content-Type": "application/json",
                        "Referer": server_url,
                        "User-Agent": self.headers["User-Agent"]
                    }
                )
                if ssl_context:
                    r = urllib2.urlopen(req, context=ssl_context, timeout=8)
                else:
                    r = urllib2.urlopen(req, timeout=8)
                res_data = json.loads(r.read().decode("utf-8"))
                st_url = res_data.get("streaming_url", "")
                if st_url:
                    return st_url, "https://vidaraa.cc/"
            except Exception as e:
                log_debug("Vidaraa API error: " + str(e))

        html = self.fetch_html(server_url, use_cache=False, custom_headers={"Referer": self.base_url + "/"})
        if not html:
            return "", ""

        voe_hls = re.search(r'["\']hls["\']\s*:\s*["\']([^"\']+)["\']', html)
        if voe_hls:
            return voe_hls.group(1), referer

        m3u8_file = re.search(r'(?:file|sources|src)\s*[:=]\s*["\']([^"\']+\.m3u8[^"\']*)["\']', html, re.I)
        if m3u8_file:
            return m3u8_file.group(1), referer

        mp4_file = re.search(r'(?:file|sources|src)\s*[:=]\s*["\']([^"\']+\.mp4[^"\']*)["\']', html, re.I)
        if mp4_file:
            return mp4_file.group(1), referer

        raw_m3u8 = re.search(r'["\'](https?://[^"\'\s]+\.m3u8[^"\'\s]*)["\']', html)
        if raw_m3u8:
            return raw_m3u8.group(1), referer

        raw_mp4 = re.search(r'["\'](https?://[^"\'\s]+\.mp4[^"\'\s]*)["\']', html)
        if raw_mp4:
            return raw_mp4.group(1), referer

        packed = re.search(r'(eval\(function\(p,a,c,k,e,d\).+?{}\)\))', html, re.DOTALL)
        if packed:
            try:
                unpacked = self.unpack_js(packed.group(1))
                m3u8_unp = re.search(r'["\'](https?://[^"\'\s]+\.m3u8[^"\'\s]*)["\']', unpacked)
                if m3u8_unp:
                    return m3u8_unp.group(1), referer
                mp4_unp = re.search(r'["\'](https?://[^"\'\s]+\.mp4[^"\'\s]*)["\']', unpacked)
                if mp4_unp:
                    return mp4_unp.group(1), referer
            except Exception as e:
                log_debug("Unpack error: " + str(e))

        return "", referer

    def unpack_js(self, packed_str):
        m = re.search(r"}\('(.*)',\s*(\d+),\s*(\d+),\s*'(.*?)'\.split\('\|'\)", packed_str, re.DOTALL)
        if not m:
            return ""
        payload, radix, count, symtab = m.groups()
        radix = int(radix)
        symbols = symtab.split('|')

        def lookup(match):
            word = match.group(0)
            val = baseN_decode(word, radix)
            return symbols[val] if val < len(symbols) and symbols[val] else word

        return re.sub(r'\b\w+\b', lookup, payload)
