# -*- coding: utf-8 -*-
# ArabSeed Plugin for Enigma2
