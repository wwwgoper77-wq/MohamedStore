# -*- coding: utf-8 -*-
"""
===================================================================
 ArabSeed Enigma2 Plugin - Fixed & Optimized Edition
 Compatible with: Python 2 & Python 3 (EGAMI, OpenATV, OpenPLi, Pure2, BlackHole)
 Features:
   - Full Stream Resolving (Vidaraa, Vidmoly, VOE, Arabseed Direct MP4, M3U8)
   - Proper User-Agent & Referer Injection to prevent 403 Forbidden
   - Full Playback Controls (Play, Pause, Fast Forward, Rewind, Quick Jump 1/3/4/6/7/9)
   - Real-time Progress Bar & Elapsed/Total/Remaining Time Display
   - Safe Non-blocking Async Threading & Instant Exit Protection
   - Clean UI and player engine fallback (4097 / 5001 / 5002)
   - Fixed: Crash on entering sections (picload AttributeError)
   - Fixed: Posters display & CDN Anti-Hotlinking bypass
===================================================================
"""

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.InputBox import InputBox
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.ProgressBar import ProgressBar
from Components.config import config, ConfigSubsection, ConfigText, ConfigSelection, getConfigListEntry
from Components.ConfigList import ConfigListScreen
from Tools.Directories import fileExists
from enigma import ePicLoad, eServiceReference, eTimer, iPlayableService, getDesktop

try:
    from Tools.LoadPixmap import LoadPixmap
except Exception:
    LoadPixmap = None

import sys
import os
import threading
import re
import zlib
import gzip
import json
import hashlib

PLUGIN_PATH = os.path.dirname(os.path.abspath(__file__))
if PLUGIN_PATH not in sys.path:
    sys.path.insert(0, PLUGIN_PATH)

PY3 = sys.version_info[0] == 3
if PY3:
    import urllib.request as urllib2
    from urllib.parse import urljoin, quote, unquote, urlparse
    from io import BytesIO
else:
    import urllib2
    from urlparse import urljoin, urlparse
    from urllib import quote, unquote
    from StringIO import StringIO as BytesIO

LOG_FILE = "/tmp/arabseed.log"

def log_debug(msg):
    try:
        with open(LOG_FILE, "a") as f:
            f.write("[ArabSeed] " + str(msg) + "\n")
    except Exception:
        pass
    print("[ArabSeed] " + str(msg))

def safe_url(url):
    if not url:
        return ""
    if PY3:
        import urllib.parse
        return urllib.parse.quote(str(url), safe=":/%?&=+#@!$,;'*()")
    else:
        import urllib
        try:
            if isinstance(url, unicode):
                url = url.encode("utf-8")
        except NameError:
            pass
        return urllib.quote(str(url), safe=":/%?&=+#@!$,;'*()")

def baseN_decode(s, b):
    chars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
    val = 0
    for c in s:
        idx = chars.find(c)
        if idx != -1 and idx < b:
            val = val * b + idx
    return val

ssl_context = None
try:
    import ssl
    ssl_context = ssl._create_unverified_context()
except Exception:
    ssl_context = None

def extract_poster_url(inner_html, base_url="https://arabseed.store"):
    """
    استخراج رابط البوستر بدقة متناهية مع دعم التحميل الكسول (Lazy-load)
    وتجاهل الصور الوهمية (SVG/Base64 Placeholders) وحل الروابط النسبية
    """
    if not inner_html:
        return ""
    patterns = [
        r'data-src=["\']([^"\']+)["\']',
        r'data-lazy-src=["\']([^"\']+)["\']',
        r'data-original=["\']([^"\']+)["\']',
        r'data-img=["\']([^"\']+)["\']',
        r'srcset=["\']([^"\'\s]+)',
        r'<img[^>]+src=["\']([^"\']+)["\']',
        r'url\(["\']?([^"\'\)]+)["\']?\)'
    ]
    for p in patterns:
        matches = re.findall(p, inner_html, re.IGNORECASE)
        for m in matches:
            m = m.strip()
            if m and not m.startswith("data:image") and not m.endswith(".svg") and "placeholder" not in m.lower():
                if m.startswith("//"):
                    return "https:" + m
                elif not m.startswith("http"):
                    return urljoin(base_url, m)
                return m

    m = re.search(r'<img[^>]+src=["\']([^"\']+)["\']', inner_html, re.IGNORECASE)
    if m:
        val = m.group(1).strip()
        if val and not val.startswith("data:image"):
            if val.startswith("//"):
                return "https:" + val
            elif not val.startswith("http"):
                return urljoin(base_url, val)
            return val
    return ""

def is_valid_image_bytes(data):
    if not data or len(data) < 100:
        return False
    if data.startswith(b"<!DOCTYPE") or data.startswith(b"<html") or b"<title>Just a moment" in data:
        return False
    return True

def convert_and_save_image(data, target_path):
    """
    تحويل الصور (وخاصة WebP الخاصة بموقع عرب سيد) إلى JPEG أو PNG متوافق تماماً مع مشغل ومكتبات Enigma2
    """
    if not is_valid_image_bytes(data):
        return False

    # 1. إذا كانت الصورة بالفعل بتنسيق JPEG أو PNG أصلي، يتم حفظها مباشرة
    if data.startswith(b"\xff\xd8") or data.startswith(b"\x89PNG"):
        try:
            with open(target_path, "wb") as f:
                f.write(data)
            return True
        except Exception as e:
            log_debug("Failed to write image directly: " + str(e))
            return False

    # 2. تحويل WebP إلى JPEG بواسطة مكتبة PIL (Pillow) إن وجدت في بيئة بايثون
    try:
        from PIL import Image
        import io
        img = Image.open(io.BytesIO(data))
        if img.mode != "RGB":
            img = img.convert("RGB")
        img.save(target_path, "JPEG", quality=85)
        if fileExists(target_path) and os.path.getsize(target_path) > 100:
            return True
    except Exception:
        pass

    # 3. تحويل WebP إلى JPEG عبر أداة النظام ffmpeg (المتوفرة على جميع أجهزة Enigma2 الحديثة)
    tmp_input = target_path + ".tmp.webp"
    try:
        with open(tmp_input, "wb") as f:
            f.write(data)
        cmd = "ffmpeg -y -i '%s' -q:v 2 '%s' > /dev/null 2>&1" % (tmp_input, target_path)
        os.system(cmd)
        if fileExists(target_path) and os.path.getsize(target_path) > 100:
            try:
                os.remove(tmp_input)
            except Exception:
                pass
            return True
    except Exception:
        pass
    finally:
        if fileExists(tmp_input):
            try:
                os.remove(tmp_input)
            except Exception:
                pass

    # 4. تحويل WebP عبر dwebp في حال توفره
    try:
        with open(tmp_input, "wb") as f:
            f.write(data)
        cmd = "dwebp '%s' -o '%s' > /dev/null 2>&1" % (tmp_input, target_path)
        os.system(cmd)
        if fileExists(target_path) and os.path.getsize(target_path) > 100:
            try:
                os.remove(tmp_input)
            except Exception:
                pass
            return True
    except Exception:
        pass
    finally:
        if fileExists(tmp_input):
            try:
                os.remove(tmp_input)
            except Exception:
                pass

    # 5. حفظ كحل أخير إذا لم تتوفر أدوات التحويل
    try:
        with open(target_path, "wb") as f:
            f.write(data)
        return True
    except Exception:
        return False

def is_valid_jpg_or_png_file(path):
    """ التحقق من أن الملف الموجود في الكاش هو صورة صالحة وغير تالفة وليس ملف WebP لم يتم تحويله """
    if not fileExists(path) or os.path.getsize(path) < 100:
        return False
    try:
        with open(path, "rb") as f:
            header = f.read(16)
        if header.startswith(b"\xff\xd8") or header.startswith(b"\x89PNG"):
            return True
        # إذا كان الملف لا يزال بتنسيق WebP تم تخزينه سابقاً، نقوم بتحويله فوراً
        if header.startswith(b"RIFF") and b"WEBP" in header:
            with open(path, "rb") as f:
                raw_bytes = f.read()
            if convert_and_save_image(raw_bytes, path):
                return True
        # إذا كان ملفاً تالفاً أو كود HTML، يتم حذفه لتنزيله من جديد
        try:
            os.remove(path)
        except Exception:
            pass
        return False
    except Exception:
        return False

class ArabSeedScraper:
    def __init__(self, base_url="https://arabseed.store"):
        self.base_url = (base_url or "https://arabseed.store").rstrip("/")
        self.last_error = ""
        self.memory_cache = {}
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
            "Accept-Language": "ar,en-US;q=0.9,en;q=0.8",
            "Accept-Encoding": "gzip, deflate",
            "Connection": "keep-alive"
        }

    def fetch_html(self, url, use_cache=True, custom_headers=None):
        if not url.startswith("http"):
            url = urljoin(self.base_url, url)
        url = safe_url(url)
        if use_cache and url in self.memory_cache:
            return self.memory_cache[url]

        log_debug("Fetching URL: " + url)
        self.last_error = ""
        req_headers = dict(self.headers)
        if custom_headers:
            req_headers.update(custom_headers)

        # 1. Try requests if available
        try:
            import requests
            r = requests.get(url, headers=req_headers, verify=False, timeout=8)
            text = r.text
            if "Just a moment..." in text or "challenge-platform" in text:
                self.last_error = "CLOUDFLARE_BLOCKED"
                return ""
            if use_cache:
                self.memory_cache[url] = text
            return text
        except ImportError:
            pass
        except Exception as e:
            log_debug("Requests fallback: " + str(e))

        # 2. Standard urllib fallback
        try:
            req = urllib2.Request(url, headers=req_headers)
            if ssl_context:
                res = urllib2.urlopen(req, timeout=8, context=ssl_context)
            else:
                res = urllib2.urlopen(req, timeout=8)

            raw_data = res.read()
            encoding = res.headers.get("Content-Encoding", "").lower()
            if encoding == "gzip" or raw_data[:2] == b"\x1f\x8b":
                try:
                    raw_data = gzip.GzipFile(fileobj=BytesIO(raw_data)).read()
                except Exception:
                    pass
            elif encoding == "deflate":
                try:
                    raw_data = zlib.decompress(raw_data)
                except Exception:
                    pass

            if PY3:
                html = raw_data.decode("utf-8", errors="ignore")
            else:
                html = raw_data

            if "Just a moment..." in html or "challenge-platform" in html:
                self.last_error = "CLOUDFLARE_BLOCKED"
                return ""

            if use_cache:
                self.memory_cache[url] = html
            return html
        except Exception as e:
            log_debug("Fetch error: " + str(e))
            self.last_error = str(e)
            return ""

    def check_connection(self):
        html = self.fetch_html(self.base_url, use_cache=False)
        if self.last_error == "CLOUDFLARE_BLOCKED":
            return False, "النطاق محمي بـ Cloudflare"
        if html and len(html) > 300:
            return True, "تم الاتصال بنجاح"
        return False, self.last_error or "تعذر الاتصال بالخادم"

    def get_items(self, path="/main/", page=1):
        if path in ["/home/", "/home"]:
            path = "/main/"
        if page > 1:
            if "?" in path:
                target_url = path + "&page=" + str(page)
            else:
                target_url = path.rstrip("/") + "/page/" + str(page) + "/"
        else:
            target_url = path

        html = self.fetch_html(target_url)
        if not html:
            return []

        items = []
        p1 = re.compile(
            r'<a[^>]*href=["\']([^"\']+)["\'][^>]*title=["\']([^"\']+)["\'][^>]*class=["\'][^"\']*movie__block[^"\']*["\'][^>]*>(.*?)</a>',
            re.DOTALL | re.IGNORECASE
        )
        matches1 = p1.findall(html)
        if matches1:
            for href, title, inner in matches1:
                poster = extract_poster_url(inner, self.base_url)
                q_m = re.search(r'class=["\'][^"\']*__quality[^"\']*["\'][^>]*>([^<]*)<', inner, re.IGNORECASE)
                quality = q_m.group(1).strip() if q_m else "HD"
                year_m = re.search(r'\(?\b(20\d\d|19\d\d)\b\)?', title)
                year = year_m.group(1) if year_m else "2024"
                clean_title = re.sub(r'\s+', ' ', title).strip()
                is_series = any(x in clean_title for x in ["مسلسل", "الموسم", "الحلقة"]) or "/series/" in href
                items.append({
                    "title": clean_title,
                    "url": href,
                    "poster": poster,
                    "year": year,
                    "quality": quality,
                    "is_series": is_series
                })
            return items

        p2 = re.compile(
            r'<div[^>]*class=["\']([^"\']*(?:MovieBlock|BlockItem|post-item|movie-item)[^"\']*)["\'][^>]*>(.*?)</div>\s*</div>',
            re.DOTALL | re.IGNORECASE
        )
        matches2 = p2.findall(html)
        if matches2:
            for block_class, inner in matches2:
                a_m = re.search(r'<a[^>]*href=["\']([^"\']+)["\'][^>]*title=["\']([^"\']+)["\']', inner)
                if not a_m:
                    continue
                href, title = a_m.group(1), a_m.group(2)
                poster = extract_poster_url(inner, self.base_url)
                clean_title = re.sub(r'\s+', ' ', title).strip()
                is_series = "مسلسل" in clean_title or "/series/" in href
                year_m = re.search(r'\(?\b(20\d\d|19\d\d)\b\)?', clean_title)
                year = year_m.group(1) if year_m else "2024"
                items.append({
                    "title": clean_title,
                    "url": href,
                    "poster": poster,
                    "year": year,
                    "quality": "1080p FHD",
                    "is_series": is_series
                })
            return items
        return items

    def get_episodes(self, series_url):
        html = self.fetch_html(series_url)
        if not html:
            return []
        episodes = []
        ep_blocks = re.findall(r'<ul class=["\']episodes__list[^"]*["\']>.*?</ul>', html, re.DOTALL)
        if ep_blocks:
            matches = re.findall(r'<a[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', ep_blocks[0], re.DOTALL)
            for href, inner in matches:
                clean_text = re.sub(r'<[^>]+>', ' ', inner).strip()
                if not clean_text:
                    num_m = re.search(r'الحلقة-(\d+)', href)
                    clean_text = "الحلقة " + (num_m.group(1) if num_m else "1")
                episodes.append({"title": clean_text, "url": href})
            return episodes

        matches = re.findall(r'<a[^>]*href=["\']([^"\']+)["\'][^>]*>(?:.*?)(?:الحلقة|Episode)\s*(\d+|الأخيرة|[^\s<]+)(?:.*?)</a>', html, re.IGNORECASE | re.DOTALL)
        for href, num in matches:
            episodes.append({"title": "الحلقة " + str(num).strip(), "url": href})
        return episodes

    def get_servers(self, media_url):
        servers = []
        if not media_url:
            return servers

        # 1. Fetch Watch Page
        watch_url = media_url.rstrip("/") + "/watch/"
        watch_html = self.fetch_html(watch_url)
        if not watch_html:
            watch_html = self.fetch_html(media_url)

        if watch_html:
            server_matches = re.findall(
                r'<li[^>]*data-(?:src|url|embed)=["\']([^"\']+)["\'][^>]*>(.*?)</li>',
                watch_html,
                re.DOTALL | re.IGNORECASE
            )
            for s_url, inner in server_matches:
                name_m = re.search(r'<span>([^<]+)</span>', inner)
                raw_name = name_m.group(1).strip() if name_m else "Server"
                if "/watch/?url=" in s_url:
                    s_url = s_url.split("/watch/?url=")[-1]

                low_url = s_url.lower()
                if "vidara" in low_url:
                    s_name = "سيرفر Vidaraa (سريع M3U8)"
                elif "vidmoly" in low_url:
                    s_name = "سيرفر VidMoly"
                elif "voe" in low_url:
                    s_name = "سيرفر VOE (Full HD)"
                elif "arabseed" in low_url or "reviewrate" in low_url:
                    s_name = "سيرفر عرب سيد الرسمي"
                else:
                    s_name = raw_name

                servers.append({
                    "name": s_name,
                    "url": s_url,
                    "quality": "Multi"
                })

            iframes = re.findall(r'<iframe[^>]*src=["\']([^"\']+)["\']', watch_html, re.IGNORECASE)
            for ifr in iframes:
                if "/watch/?url=" in ifr:
                    ifr = ifr.split("/watch/?url=")[-1]
                if not any(s["url"] == ifr for s in servers):
                    servers.append({
                        "name": "سيرفر مدمج (Fast Stream)",
                        "url": ifr,
                        "quality": "1080p"
                    })

        # 2. Fetch Download Page for Direct High-Speed MP4 Servers
        download_url = media_url.rstrip("/") + "/download/"
        download_html = self.fetch_html(download_url)
        if download_html:
            d_matches = re.findall(
                r'<a[^>]*href=["\']([^"\']+)["\'][^>]*class=["\'][^"\']*download__item[^"\']*["\'][^>]*>(.*?)</a>',
                download_html,
                re.DOTALL | re.IGNORECASE
            )
            for d_href, d_inner in d_matches:
                h4 = re.search(r'<h4>([^<]+)</h4>', d_inner)
                host_name = h4.group(1).strip() if h4 else "Direct"
                if not d_href.startswith("http"):
                    d_href = urljoin(self.base_url, d_href)
                servers.append({
                    "name": "تحميل/بث مباشر: " + host_name,
                    "url": d_href,
                    "quality": "Direct MP4"
                })

        return servers

    def resolve_stream_url(self, server_url):
        """
        Extract direct playable stream URL (m3u8 or mp4) and determine correct referer
        Returns a tuple: (stream_url, referer_domain)
        """
        if not server_url:
            return "", ""

        log_debug("Resolving: " + server_url)

        if "/watch/?url=" in server_url:
            server_url = server_url.split("/watch/?url=")[-1]

        parsed = urlparse(server_url)
        referer = "%s://%s/" % (parsed.scheme or "https", parsed.netloc)

        low = server_url.lower()

        if any(ext in low for ext in [".m3u8", ".mp4", ".mkv", ".ts", "/hls/"]):
            return server_url, referer

        if "vidaraa" in low or "vidara" in low:
            try:
                filecode = server_url.rstrip("/").split("/")[-1]
                api_url = "https://vidaraa.cc/api/stream"
                payload = json.dumps({"filecode": filecode, "device": "desktop"}).encode("utf-8")
                req = urllib2.Request(
                    api_url,
                    data=payload,
                    headers={
                        "Content-Type": "application/json",
                        "Referer": server_url,
                        "User-Agent": self.headers["User-Agent"]
                    }
                )
                if ssl_context:
                    r = urllib2.urlopen(req, context=ssl_context, timeout=8)
                else:
                    r = urllib2.urlopen(req, timeout=8)
                res_data = json.loads(r.read().decode("utf-8"))
                st_url = res_data.get("streaming_url", "")
                if st_url:
                    log_debug("Vidaraa resolved: " + st_url[:60])
                    return st_url, "https://vidaraa.cc/"
            except Exception as e:
                log_debug("Vidaraa API error: " + str(e))

        if "/download/?download_url=" in server_url:
            try:
                html = self.fetch_html(server_url, use_cache=False)
                final_btn = re.search(r'<a[^>]*href=["\']([^"\']+)["\'][^>]*class=["\'][^"\']*(?:btn|download)[^"\']*["\']', html)
                if final_btn:
                    cand = final_btn.group(1)
                    if any(cand.lower().endswith(x) for x in [".mp4", ".m3u8", ".mkv"]):
                        return cand, self.base_url + "/"
            except Exception as e:
                log_debug("Download page resolve error: " + str(e))

        html = self.fetch_html(server_url, use_cache=False, custom_headers={"Referer": self.base_url + "/"})
        if not html:
            return "", ""

        voe_hls = re.search(r'["\']hls["\']\s*:\s*["\']([^"\']+)["\']', html)
        if voe_hls:
            return voe_hls.group(1), referer

        m3u8_file = re.search(r'(?:file|sources|src)\s*[:=]\s*["\']([^"\']+\.m3u8[^"\']*)["\']', html, re.I)
        if m3u8_file:
            return m3u8_file.group(1), referer

        mp4_file = re.search(r'(?:file|sources|src)\s*[:=]\s*["\']([^"\']+\.mp4[^"\']*)["\']', html, re.I)
        if mp4_file:
            return mp4_file.group(1), referer

        raw_m3u8 = re.search(r'["\'](https?://[^"\'\s]+\.m3u8[^"\'\s]*)["\']', html)
        if raw_m3u8:
            return raw_m3u8.group(1), referer

        raw_mp4 = re.search(r'["\'](https?://[^"\'\s]+\.mp4[^"\'\s]*)["\']', html)
        if raw_mp4:
            return raw_mp4.group(1), referer

        packed = re.search(r'(eval\(function\(p,a,c,k,e,d\).+?{}\)\))', html, re.DOTALL)
        if packed:
            try:
                unpacked = self.unpack_js(packed.group(1))
                m3u8_unp = re.search(r'["\'](https?://[^"\'\s]+\.m3u8[^"\'\s]*)["\']', unpacked)
                if m3u8_unp:
                    return m3u8_unp.group(1), referer
                mp4_unp = re.search(r'["\'](https?://[^"\'\s]+\.mp4[^"\'\s]*)["\']', unpacked)
                if mp4_unp:
                    return mp4_unp.group(1), referer
            except Exception as e:
                log_debug("Unpack error: " + str(e))

        return "", referer

    def unpack_js(self, packed_str):
        m = re.search(r"}\('(.*)',\s*(\d+),\s*(\d+),\s*'(.*?)'\.split\('\|'\)", packed_str, re.DOTALL)
        if not m:
            return ""
        payload, radix, count, symtab = m.groups()
        radix = int(radix)
        symbols = symtab.split('|')

        def lookup(match):
            word = match.group(0)
            val = baseN_decode(word, radix)
            return symbols[val] if val < len(symbols) and symbols[val] else word

        return re.sub(r'\b\w+\b', lookup, payload)

CACHE_DIR = "/tmp/arabseed_cache"
if not os.path.exists(CACHE_DIR):
    try:
        os.makedirs(CACHE_DIR)
    except Exception:
        pass

# Settings & Configuration
config.plugins.arabseed = ConfigSubsection()
config.plugins.arabseed.domain = ConfigText(default="https://arabseed.store", fixed_size=False)
config.plugins.arabseed.player = ConfigSelection(default="4097", choices=[
    ("4097", "Default Enigma2 Player (افتراضي 4097 - لكافة الأجهزة)"),
    ("5002", "Exteplayer3 - FFmpeg (5002 - يتطلب حزمة exteplayer3)"),
    ("5001", "GstPlayer - GStreamer (5001)")
])

# =====================================================================
# Auto-Scaling Resolution Engine (Vu+ All Images & DreamBox DreamOS)
# =====================================================================

def get_resolution_info():
    """
    اكتشاف تلقائي دقيق لدقة سطح المكتب في الإنيجما 2 (Desktop Resolution):
    - 4K UHD: أجهزة Vu+ 4K (Duo 4K, Solo 4K, Uno 4K SE, Zero 4K) ودريم بوكس (DM900/920/One/Two UHD)
    - Full HD: شاشات FHD 1920x1080 (وهي القياسية لأغلب صور OpenATV / OpenPLi / Egami / BlackHole)
    - Standard HD: شاشات HD 1280x720 والشاشات القديمة
    """
    try:
        size = getDesktop(0).size()
        w = size.width()
        h = size.height()
    except Exception:
        w, h = 1920, 1080

    if w >= 2560:
        return w, h, "4k"
    elif w >= 1600:
        return w, h, "fhd"
    else:
        return w, h, "hd"

def bind_timer(timer, callback_func):
    """
    ربط آمن لمؤقتات eTimer يعمل بسلاسة تامة على:
    - صور الدريم بوكس (DreamOS OE2.5 و OE2.6 المبنية على Qt)
    - كافة صور أجهزة Vu+ والأجهزة الشبيهة (OpenATV, OpenPLi, VTi, BlackHole, Egami, PurE2)
    """
    if hasattr(timer, "callback"):
        try:
            timer.callback.append(callback_func)
            return
        except Exception:
            pass
    if hasattr(timer, "timeout"):
        try:
            timer.timeout.connect(callback_func)
            return
        except Exception:
            pass

def get_main_skin():
    w, h, tier = get_resolution_info()
    if tier == "4k":
        return """
        <screen name="ArabSeedMain" position="center,center" size="2400,1350" title="ArabSeed - عرب سيد" flags="wfNoBorder" backgroundColor="#0b0f19">
            <eLabel position="0,0" size="2400,150" backgroundColor="#111827" zPosition="1" />
            <eLabel position="70,45" size="20,60" backgroundColor="#f59e0b" zPosition="2" />
            <widget name="title" position="110,38" size="1100,75" font="Regular;46" foregroundColor="#f59e0b" backgroundColor="#111827" zPosition="2" halign="right" />
            <widget name="info" position="1230,48" size="1100,60" font="Regular;32" foregroundColor="#9ca3af" backgroundColor="#111827" zPosition="2" halign="left" />
            <eLabel position="0,146" size="2400,4" backgroundColor="#f59e0b" zPosition="3" />

            <widget name="menu" position="100,180" size="2200,950" font="Regular;38" itemHeight="88" scrollbarMode="showOnDemand" selectionColor="#1e293b" foregroundColor="#f3f4f6" backgroundColor="#0b0f19" transparent="1" />

            <eLabel position="0,1150" size="2400,200" backgroundColor="#111827" zPosition="1" />
            <eLabel position="100,1175" size="480,10" backgroundColor="#ef4444" zPosition="2" />
            <widget name="key_red" position="100,1198" size="480,55" font="Regular;32" foregroundColor="#f8fafc" backgroundColor="#111827" zPosition="2" halign="center" />
            <eLabel position="650,1175" size="480,10" backgroundColor="#10b981" zPosition="2" />
            <widget name="key_green" position="650,1198" size="480,55" font="Regular;32" foregroundColor="#f8fafc" backgroundColor="#111827" zPosition="2" halign="center" />
            <eLabel position="1200,1175" size="480,10" backgroundColor="#f59e0b" zPosition="2" />
            <widget name="key_yellow" position="1200,1198" size="480,55" font="Regular;32" foregroundColor="#f8fafc" backgroundColor="#111827" zPosition="2" halign="center" />
            <eLabel position="1750,1175" size="480,10" backgroundColor="#3b82f6" zPosition="2" />
            <widget name="key_blue" position="1750,1198" size="480,55" font="Regular;32" foregroundColor="#f8fafc" backgroundColor="#111827" zPosition="2" halign="center" />

            <eLabel text="هذا البلجن متاح في بنل MohamedStore" position="200,1280" size="2000,50" font="Regular;30" foregroundColor="#f59e0b" backgroundColor="#111827" zPosition="2" halign="center" transparent="1" />
        </screen>
        """
    elif tier == "fhd":
        return """
        <screen name="ArabSeedMain" position="center,center" size="1600,900" title="ArabSeed - عرب سيد" flags="wfNoBorder" backgroundColor="#0b0f19">
            <eLabel position="0,0" size="1600,100" backgroundColor="#111827" zPosition="1" />
            <eLabel position="50,30" size="14,40" backgroundColor="#f59e0b" zPosition="2" />
            <widget name="title" position="80,25" size="750,55" font="Regular;36" foregroundColor="#f59e0b" backgroundColor="#111827" zPosition="2" halign="right" />
            <widget name="info" position="850,32" size="700,40" font="Regular;24" foregroundColor="#9ca3af" backgroundColor="#111827" zPosition="2" halign="left" />
            <eLabel position="0,97" size="1600,3" backgroundColor="#f59e0b" zPosition="3" />

            <widget name="menu" position="80,125" size="1440,630" font="Regular;28" itemHeight="60" scrollbarMode="showOnDemand" selectionColor="#1e293b" foregroundColor="#f3f4f6" backgroundColor="#0b0f19" transparent="1" />

            <eLabel position="0,770" size="1600,130" backgroundColor="#111827" zPosition="1" />
            <eLabel position="80,788" size="320,7" backgroundColor="#ef4444" zPosition="2" />
            <widget name="key_red" position="80,802" size="320,38" font="Regular;22" foregroundColor="#f8fafc" backgroundColor="#111827" zPosition="2" halign="center" />
            <eLabel position="450,788" size="320,7" backgroundColor="#10b981" zPosition="2" />
            <widget name="key_green" position="450,802" size="320,38" font="Regular;22" foregroundColor="#f8fafc" backgroundColor="#111827" zPosition="2" halign="center" />
            <eLabel position="820,788" size="320,7" backgroundColor="#f59e0b" zPosition="2" />
            <widget name="key_yellow" position="820,802" size="320,38" font="Regular;22" foregroundColor="#f8fafc" backgroundColor="#111827" zPosition="2" halign="center" />
            <eLabel position="1190,788" size="320,7" backgroundColor="#3b82f6" zPosition="2" />
            <widget name="key_blue" position="1190,802" size="320,38" font="Regular;22" foregroundColor="#f8fafc" backgroundColor="#111827" zPosition="2" halign="center" />

            <eLabel text="هذا البلجن متاح في بنل MohamedStore" position="100,855" size="1400,35" font="Regular;22" foregroundColor="#f59e0b" backgroundColor="#111827" zPosition="2" halign="center" transparent="1" />
        </screen>
        """
    else:
        return """
        <screen name="ArabSeedMain" position="center,center" size="1160,640" title="ArabSeed - عرب سيد" flags="wfNoBorder" backgroundColor="#0b0f19">
            <eLabel position="0,0" size="1160,75" backgroundColor="#111827" zPosition="1" />
            <eLabel position="35,22" size="10,28" backgroundColor="#f59e0b" zPosition="2" />
            <widget name="title" position="55,18" size="550,40" font="Regular;26" foregroundColor="#f59e0b" backgroundColor="#111827" zPosition="2" halign="right" />
            <widget name="info" position="615,24" size="510,30" font="Regular;18" foregroundColor="#9ca3af" backgroundColor="#111827" zPosition="2" halign="left" />
            <eLabel position="0,73" size="1160,2" backgroundColor="#f59e0b" zPosition="3" />

            <widget name="menu" position="50,90" size="1060,450" font="Regular;22" itemHeight="45" scrollbarMode="showOnDemand" selectionColor="#1e293b" foregroundColor="#f3f4f6" backgroundColor="#0b0f19" transparent="1" />

            <eLabel position="0,550" size="1160,90" backgroundColor="#111827" zPosition="1" />
            <eLabel position="50,560" size="235,5" backgroundColor="#ef4444" zPosition="2" />
            <widget name="key_red" position="50,570" size="235,28" font="Regular;17" foregroundColor="#f8fafc" backgroundColor="#111827" zPosition="2" halign="center" />
            <eLabel position="320,560" size="235,5" backgroundColor="#10b981" zPosition="2" />
            <widget name="key_green" position="320,570" size="235,28" font="Regular;17" foregroundColor="#f8fafc" backgroundColor="#111827" zPosition="2" halign="center" />
            <eLabel position="590,560" size="235,5" backgroundColor="#f59e0b" zPosition="2" />
            <widget name="key_yellow" position="590,570" size="235,28" font="Regular;17" foregroundColor="#f8fafc" backgroundColor="#111827" zPosition="2" halign="center" />
            <eLabel position="860,560" size="235,5" backgroundColor="#3b82f6" zPosition="2" />
            <widget name="key_blue" position="860,570" size="235,28" font="Regular;17" foregroundColor="#f8fafc" backgroundColor="#111827" zPosition="2" halign="center" />

            <eLabel text="هذا البلجن متاح في بنل MohamedStore" position="50,605" size="1060,28" font="Regular;16" foregroundColor="#f59e0b" backgroundColor="#111827" zPosition="2" halign="center" transparent="1" />
        </screen>
        """

def get_list_skin():
    w, h, tier = get_resolution_info()
    if tier == "4k":
        return """
        <screen name="ArabSeedListScreen" position="center,center" size="3000,1650" title="قائمة الأفلام والمسلسلات" flags="wfNoBorder" backgroundColor="#0b0f19">
            <eLabel position="0,0" size="3000,150" backgroundColor="#111827" zPosition="1" />
            <widget name="title" position="80,35" size="2840,75" font="Regular;46" foregroundColor="#f59e0b" backgroundColor="#111827" zPosition="2" halign="right"/>
            <eLabel position="0,146" size="3000,4" backgroundColor="#f59e0b" zPosition="3" />

            <widget name="items" position="860,190" size="2060,1260" itemHeight="90" font="Regular;38" selectionColor="#1e293b" foregroundColor="#f8fafc" backgroundColor="#0b0f19" scrollbarMode="showOnDemand" transparent="1" />
            
            <widget name="poster" position="80,190" size="720,950" zPosition="2" alphatest="blend" />
            <widget name="details" position="80,1160" size="720,290" font="Regular;32" foregroundColor="#94a3b8" backgroundColor="#0b0f19" transparent="1" halign="right"/>
            
            <eLabel position="0,1500" size="3000,150" backgroundColor="#111827" zPosition="1" />
            <eLabel position="80,1525" size="650,10" backgroundColor="#ef4444" zPosition="2" />
            <widget name="key_red" position="80,1550" size="650,60" font="Regular;32" halign="center" transparent="1" zPosition="2" />
            <eLabel position="780,1525" size="650,10" backgroundColor="#10b981" zPosition="2" />
            <widget name="key_green" position="780,1550" size="650,60" font="Regular;32" halign="center" transparent="1" zPosition="2" />
            <eLabel position="1480,1525" size="650,10" backgroundColor="#f59e0b" zPosition="2" />
            <widget name="key_yellow" position="1480,1550" size="650,60" font="Regular;32" halign="center" transparent="1" zPosition="2" />
            <eLabel position="2180,1525" size="650,10" backgroundColor="#3b82f6" zPosition="2" />
            <widget name="key_blue" position="2180,1550" size="650,60" font="Regular;32" halign="center" transparent="1" zPosition="2" />
        </screen>
        """
    elif tier == "fhd":
        return """
        <screen name="ArabSeedListScreen" position="center,center" size="1800,980" title="قائمة الأفلام والمسلسلات" flags="wfNoBorder" backgroundColor="#0b0f19">
            <eLabel position="0,0" size="1800,95" backgroundColor="#111827" zPosition="1" />
            <widget name="title" position="50,22" size="1700,55" font="Regular;34" foregroundColor="#f59e0b" backgroundColor="#111827" zPosition="2" halign="right"/>
            <eLabel position="0,92" size="1800,3" backgroundColor="#f59e0b" zPosition="3" />

            <widget name="items" position="550,120" size="1200,730" itemHeight="55" font="Regular;26" selectionColor="#1e293b" foregroundColor="#f8fafc" backgroundColor="#0b0f19" scrollbarMode="showOnDemand" transparent="1" />
            
            <widget name="poster" position="50,120" size="460,600" zPosition="2" alphatest="blend" />
            <widget name="details" position="50,740" size="460,110" font="Regular;22" foregroundColor="#94a3b8" backgroundColor="#0b0f19" transparent="1" halign="right"/>
            
            <eLabel position="0,885" size="1800,95" backgroundColor="#111827" zPosition="1" />
            <eLabel position="50,900" size="390,6" backgroundColor="#ef4444" zPosition="2" />
            <widget name="key_red" position="50,915" size="390,40" font="Regular;22" halign="center" transparent="1" zPosition="2" />
            <eLabel position="480,900" size="390,6" backgroundColor="#10b981" zPosition="2" />
            <widget name="key_green" position="480,915" size="390,40" font="Regular;22" halign="center" transparent="1" zPosition="2" />
            <eLabel position="910,900" size="390,6" backgroundColor="#f59e0b" zPosition="2" />
            <widget name="key_yellow" position="910,915" size="390,40" font="Regular;22" halign="center" transparent="1" zPosition="2" />
            <eLabel position="1340,900" size="390,6" backgroundColor="#3b82f6" zPosition="2" />
            <widget name="key_blue" position="1340,915" size="390,40" font="Regular;22" halign="center" transparent="1" zPosition="2" />
        </screen>
        """
    else:
        return """
        <screen name="ArabSeedListScreen" position="center,center" size="1200,660" title="قائمة الأفلام والمسلسلات" flags="wfNoBorder" backgroundColor="#0b0f19">
            <eLabel position="0,0" size="1200,70" backgroundColor="#111827" zPosition="1" />
            <widget name="title" position="35,16" size="1130,40" font="Regular;24" foregroundColor="#f59e0b" backgroundColor="#111827" zPosition="2" halign="right"/>
            <eLabel position="0,68" size="1200,2" backgroundColor="#f59e0b" zPosition="3" />

            <widget name="items" position="410,90" size="750,490" itemHeight="42" font="Regular;20" selectionColor="#1e293b" foregroundColor="#f8fafc" backgroundColor="#0b0f19" scrollbarMode="showOnDemand" transparent="1" />
            
            <widget name="poster" position="40,90" size="340,440" zPosition="2" alphatest="blend" />
            <widget name="details" position="40,540" size="340,45" font="Regular;16" foregroundColor="#94a3b8" backgroundColor="#0b0f19" transparent="1" halign="right"/>
            
            <eLabel position="0,590" size="1200,70" backgroundColor="#111827" zPosition="1" />
            <eLabel position="35,602" size="260,5" backgroundColor="#ef4444" zPosition="2" />
            <widget name="key_red" position="35,615" size="260,30" font="Regular;18" halign="center" transparent="1" zPosition="2" />
            <eLabel position="325,602" size="260,5" backgroundColor="#10b981" zPosition="2" />
            <widget name="key_green" position="325,615" size="260,30" font="Regular;18" halign="center" transparent="1" zPosition="2" />
            <eLabel position="615,602" size="260,5" backgroundColor="#f59e0b" zPosition="2" />
            <widget name="key_yellow" position="615,615" size="260,30" font="Regular;18" halign="center" transparent="1" zPosition="2" />
            <eLabel position="905,602" size="260,5" backgroundColor="#3b82f6" zPosition="2" />
            <widget name="key_blue" position="905,615" size="260,30" font="Regular;18" halign="center" transparent="1" zPosition="2" />
        </screen>
        """

def get_episodes_skin():
    w, h, tier = get_resolution_info()
    if tier == "4k":
        return """
        <screen name="ArabSeedEpisodesScreen" position="center,center" size="2200,1300" title="قائمة الحلقات" flags="wfNoBorder" backgroundColor="#0b0f19">
            <eLabel position="0,0" size="2200,140" backgroundColor="#111827" zPosition="1" />
            <widget name="title" position="60,30" size="2080,75" font="Regular;44" foregroundColor="#f59e0b" backgroundColor="#111827" zPosition="2" halign="right"/>
            <eLabel position="0,136" size="2200,4" backgroundColor="#f59e0b" zPosition="3" />

            <widget name="episodes" position="60,170" size="2080,950" font="Regular;38" itemHeight="85" selectionColor="#1e293b" foregroundColor="#f8fafc" backgroundColor="#0b0f19" scrollbarMode="showOnDemand" transparent="1" />
            
            <eLabel position="0,1160" size="2200,140" backgroundColor="#111827" zPosition="1" />
            <eLabel position="60,1185" size="400,8" backgroundColor="#ef4444" zPosition="2" />
            <widget name="key_red" position="60,1210" size="400,60" font="Regular;32" halign="center" transparent="1" zPosition="2" />
        </screen>
        """
    elif tier == "fhd":
        return """
        <screen name="ArabSeedEpisodesScreen" position="center,center" size="1400,820" title="قائمة الحلقات" flags="wfNoBorder" backgroundColor="#0b0f19">
            <eLabel position="0,0" size="1400,90" backgroundColor="#111827" zPosition="1" />
            <widget name="title" position="40,20" size="1320,50" font="Regular;30" foregroundColor="#f59e0b" backgroundColor="#111827" zPosition="2" halign="right"/>
            <eLabel position="0,87" size="1400,3" backgroundColor="#f59e0b" zPosition="3" />

            <widget name="episodes" position="40,110" size="1320,600" font="Regular;26" itemHeight="52" selectionColor="#1e293b" foregroundColor="#f8fafc" backgroundColor="#0b0f19" scrollbarMode="showOnDemand" transparent="1" />
            
            <eLabel position="0,730" size="1400,90" backgroundColor="#111827" zPosition="1" />
            <eLabel position="40,745" size="250,6" backgroundColor="#ef4444" zPosition="2" />
            <widget name="key_red" position="40,760" size="250,40" font="Regular;22" halign="center" transparent="1" zPosition="2" />
        </screen>
        """
    else:
        return """
        <screen name="ArabSeedEpisodesScreen" position="center,center" size="960,540" title="قائمة الحلقات" flags="wfNoBorder" backgroundColor="#0b0f19">
            <eLabel position="0,0" size="960,65" backgroundColor="#111827" zPosition="1" />
            <widget name="title" position="30,15" size="900,35" font="Regular;24" foregroundColor="#f59e0b" backgroundColor="#111827" zPosition="2" halign="right"/>
            <eLabel position="0,63" size="960,2" backgroundColor="#f59e0b" zPosition="3" />

            <widget name="episodes" position="30,80" size="900,390" font="Regular;20" itemHeight="42" selectionColor="#1e293b" foregroundColor="#f8fafc" backgroundColor="#0b0f19" scrollbarMode="showOnDemand" transparent="1" />
            
            <eLabel position="0,480" size="960,60" backgroundColor="#111827" zPosition="1" />
            <eLabel position="30,490" size="180,4" backgroundColor="#ef4444" zPosition="2" />
            <widget name="key_red" position="30,500" size="180,30" font="Regular;18" halign="center" transparent="1" zPosition="2" />
        </screen>
        """

def get_servers_skin():
    w, h, tier = get_resolution_info()
    if tier == "4k":
        return """
        <screen name="ArabSeedServersScreen" position="center,center" size="2000,1200" title="اختر سيرفر المشاهدة" flags="wfNoBorder" backgroundColor="#0b0f19">
            <eLabel position="0,0" size="2000,140" backgroundColor="#111827" zPosition="1" />
            <widget name="title" position="60,30" size="1880,75" font="Regular;44" foregroundColor="#10b981" backgroundColor="#111827" zPosition="2" halign="right"/>
            <eLabel position="0,136" size="2000,4" backgroundColor="#10b981" zPosition="3" />

            <widget name="servers" position="60,170" size="1880,820" font="Regular;38" itemHeight="85" selectionColor="#1e293b" foregroundColor="#f8fafc" backgroundColor="#0b0f19" scrollbarMode="showOnDemand" transparent="1" />
            <widget name="status" position="550,1050" size="1390,70" font="Regular;32" foregroundColor="#94a3b8" backgroundColor="#0b0f19" transparent="1" halign="right"/>

            <eLabel position="60,1040" size="400,8" backgroundColor="#ef4444" zPosition="2" />
            <widget name="key_red" position="60,1065" size="400,60" font="Regular;32" halign="center" transparent="1" zPosition="2" />
        </screen>
        """
    elif tier == "fhd":
        return """
        <screen name="ArabSeedServersScreen" position="center,center" size="1300,750" title="اختر سيرفر المشاهدة" flags="wfNoBorder" backgroundColor="#0b0f19">
            <eLabel position="0,0" size="1300,90" backgroundColor="#111827" zPosition="1" />
            <widget name="title" position="40,20" size="1220,50" font="Regular;30" foregroundColor="#10b981" backgroundColor="#111827" zPosition="2" halign="right"/>
            <eLabel position="0,87" size="1300,3" backgroundColor="#10b981" zPosition="3" />

            <widget name="servers" position="40,110" size="1220,520" font="Regular;26" itemHeight="52" selectionColor="#1e293b" foregroundColor="#f8fafc" backgroundColor="#0b0f19" scrollbarMode="showOnDemand" transparent="1" />
            <widget name="status" position="350,670" size="910,50" font="Regular;22" foregroundColor="#94a3b8" backgroundColor="#0b0f19" transparent="1" halign="right"/>

            <eLabel position="40,660" size="250,6" backgroundColor="#ef4444" zPosition="2" />
            <widget name="key_red" position="40,675" size="250,40" font="Regular;22" halign="center" transparent="1" zPosition="2" />
        </screen>
        """
    else:
        return """
        <screen name="ArabSeedServersScreen" position="center,center" size="860,500" title="اختر سيرفر المشاهدة" flags="wfNoBorder" backgroundColor="#0b0f19">
            <eLabel position="0,0" size="860,65" backgroundColor="#111827" zPosition="1" />
            <widget name="title" position="30,15" size="800,35" font="Regular;24" foregroundColor="#10b981" backgroundColor="#111827" zPosition="2" halign="right"/>
            <eLabel position="0,63" size="860,2" backgroundColor="#10b981" zPosition="3" />

            <widget name="servers" position="30,80" size="800,350" font="Regular;20" itemHeight="42" selectionColor="#1e293b" foregroundColor="#f8fafc" backgroundColor="#0b0f19" scrollbarMode="showOnDemand" transparent="1" />
            <widget name="status" position="250,450" size="580,35" font="Regular;18" foregroundColor="#94a3b8" backgroundColor="#0b0f19" transparent="1" halign="right"/>

            <eLabel position="30,445" size="180,4" backgroundColor="#ef4444" zPosition="2" />
            <widget name="key_red" position="30,455" size="180,30" font="Regular;18" halign="center" transparent="1" zPosition="2" />
        </screen>
        """

def get_settings_skin():
    w, h, tier = get_resolution_info()
    if tier == "4k":
        return """
        <screen name="ArabSeedSettingsScreen" position="center,center" size="1900,900" title="إعدادات عرب سيد" flags="wfNoBorder" backgroundColor="#0b0f19">
            <eLabel position="0,0" size="1900,140" backgroundColor="#111827" zPosition="1" />
            <widget name="title" position="60,30" size="1780,75" font="Regular;44" foregroundColor="#f59e0b" backgroundColor="#111827" zPosition="2" halign="right" />
            <eLabel position="0,136" size="1900,4" backgroundColor="#f59e0b" zPosition="3" />

            <widget name="config" position="80,180" size="1740,500" itemHeight="85" font="Regular;36" scrollbarMode="showOnDemand" transparent="1" />
            
            <eLabel position="0,740" size="1900,160" backgroundColor="#111827" zPosition="1" />
            <eLabel position="80,770" size="440,8" backgroundColor="#10b981" zPosition="2" />
            <widget name="key_green" position="80,790" size="440,60" font="Regular;32" halign="center" transparent="1" zPosition="2" />
            <eLabel position="580,770" size="440,8" backgroundColor="#ef4444" zPosition="2" />
            <widget name="key_red" position="580,790" size="440,60" font="Regular;32" halign="center" transparent="1" zPosition="2" />
        </screen>
        """
    elif tier == "fhd":
        return """
        <screen name="ArabSeedSettingsScreen" position="center,center" size="1200,600" title="إعدادات عرب سيد" flags="wfNoBorder" backgroundColor="#0b0f19">
            <eLabel position="0,0" size="1200,90" backgroundColor="#111827" zPosition="1" />
            <widget name="title" position="40,20" size="1120,50" font="Regular;30" foregroundColor="#f59e0b" backgroundColor="#111827" zPosition="2" halign="right" />
            <eLabel position="0,87" size="1200,3" backgroundColor="#f59e0b" zPosition="3" />

            <widget name="config" position="50,125" size="1100,340" itemHeight="55" font="Regular;24" scrollbarMode="showOnDemand" transparent="1" />
            
            <eLabel position="0,490" size="1200,110" backgroundColor="#111827" zPosition="1" />
            <eLabel position="50,510" size="280,6" backgroundColor="#10b981" zPosition="2" />
            <widget name="key_green" position="50,525" size="280,40" font="Regular;22" halign="center" transparent="1" zPosition="2" />
            <eLabel position="380,510" size="280,6" backgroundColor="#ef4444" zPosition="2" />
            <widget name="key_red" position="380,525" size="280,40" font="Regular;22" halign="center" transparent="1" zPosition="2" />
        </screen>
        """
    else:
        return """
        <screen name="ArabSeedSettingsScreen" position="center,center" size="820,400" title="إعدادات عرب سيد" flags="wfNoBorder" backgroundColor="#0b0f19">
            <eLabel position="0,0" size="820,65" backgroundColor="#111827" zPosition="1" />
            <widget name="title" position="30,15" size="760,35" font="Regular;24" foregroundColor="#f59e0b" backgroundColor="#111827" zPosition="2" halign="right" />
            <eLabel position="0,63" size="820,2" backgroundColor="#f59e0b" zPosition="3" />

            <widget name="config" position="35,85" size="750,220" itemHeight="42" font="Regular;18" scrollbarMode="showOnDemand" transparent="1" />
            
            <eLabel position="0,325" size="820,75" backgroundColor="#111827" zPosition="1" />
            <eLabel position="35,338" size="190,4" backgroundColor="#10b981" zPosition="2" />
            <widget name="key_green" position="35,348" size="190,30" font="Regular;18" halign="center" transparent="1" zPosition="2" />
            <eLabel position="255,338" size="190,4" backgroundColor="#ef4444" zPosition="2" />
            <widget name="key_red" position="255,348" size="190,30" font="Regular;18" halign="center" transparent="1" zPosition="2" />
        </screen>
        """

class ArabSeedMain(Screen):
    """ الشاشة الرئيسية: تصفح أقسام عرب سيد مع تحجيم تلقائي لكافة الشاشات """
    skin = get_main_skin()

    def __init__(self, session):
        self.skin = get_main_skin()
        Screen.__init__(self, session)
        self.session = session
        self.scraper = ArabSeedScraper(config.plugins.arabseed.domain.value)

        self["title"] = Label("ArabSeed - عرب سيد")
        self["info"] = Label("اختر القسم واضغط OK للتصفح")
        self["key_red"] = Label("خروج")
        self["key_green"] = Label("بحث")
        self["key_yellow"] = Label("إعدادات")
        self["key_blue"] = Label("فحص النطاق")

        self.categories = [
            ("أحدث الإضافات (الرئيسية)", "/main/"),
            ("المضاف حديثاً (Recently)", "/recently/"),
            ("أفلام أجنبية مترجمة", "/category/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%a7%d8%ac%d9%86%d8%a8%d9%8a/"),
            ("أفلام عربية حديثة", "/category/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%b9%d8%b1%d8%a8%d9%8a/"),
            ("أفلام Netflix العالمية", "/category/netfilx/%d8%a7%d9%81%d9%84%d8%a7%d9%85-netfilx/"),
            ("مسلسلات أجنبية مترجمة", "/category/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa-%d8%a7%d8%ac%d9%86%d8%a8%d9%8a/"),
            ("مسلسلات عربية ومصرية", "/category/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa-%d8%b9%d8%b1%d8%a8%d9%8a/"),
            ("مسلسلات تركية مدبلجة ومترجمة", "/category/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa-%d8%aa%d8%b1%d9%83%d9%8a%d9%87/"),
            ("مسلسلات Netflix الحصرية", "/category/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa-netfilx/"),
            ("عروض المصارعة الحرة (WWE)", "/category/%d9%85%d8%b5%d8%a7%d8%b1%d8%b9%d9%87/")
        ]

        self.menu_list = MenuList([cat[0] for cat in self.categories])
        self["menu"] = self.menu_list

        self["actions"] = ActionMap(["ColorActions", "OkCancelActions"], {
            "ok": self.itemSelected,
            "cancel": self.close,
            "red": self.close,
            "green": self.openSearch,
            "yellow": self.openSettings,
            "blue": self.refreshDomain
        }, -1)

    def itemSelected(self):
        idx = self["menu"].getSelectedIndex()
        if idx is not None and idx < len(self.categories):
            title, url = self.categories[idx]
            self.session.open(ArabSeedListScreen, title, url)

    def openSearch(self):
        self.session.openWithCallback(self.performSearch, InputBox, title="أدخل اسم الفيلم أو المسلسل للبحث:")

    def performSearch(self, query):
        if query and query.strip():
            search_url = "/?s=" + quote(query.strip())
            self.session.open(ArabSeedListScreen, "نتائج البحث: " + query, search_url)

    def openSettings(self):
        self.session.openWithCallback(self.afterSettings, ArabSeedSettingsScreen)

    def afterSettings(self):
        self.scraper = ArabSeedScraper(config.plugins.arabseed.domain.value)
        self["info"].setText("النطاق النشط: " + config.plugins.arabseed.domain.value)

    def refreshDomain(self):
        self["info"].setText("جاري فحص الاتصال بموقع عرب سيد...")
        def run_check():
            status, msg = self.scraper.check_connection()
            self.check_timer = eTimer()
            bind_timer(self.check_timer, lambda: self.onCheckComplete(status, msg))
            self.check_timer.start(10, True)

        threading.Thread(target=run_check).start()

    def onCheckComplete(self, status, msg):
        if status:
            self["info"].setText("الموقع يعمل: " + str(config.plugins.arabseed.domain.value))
            self.session.open(MessageBox, "تم الاتصال بنجاح بموقع عرب سيد", MessageBox.TYPE_INFO, timeout=4)
        else:
            self["info"].setText("تعذر الاتصال، يرجى تغيير النطاق")
            self.session.open(MessageBox, "فشل الاتصال بموقع عرب سيد: " + str(msg), MessageBox.TYPE_ERROR)

class ArabSeedListScreen(Screen):
    """ شاشة عرض الأفلام والمسلسلات مع بوسترات سلسة وتصفح منظم وتحجيم تلقائي وحماية كاملة من الكراش """
    skin = get_list_skin()

    def __init__(self, session, cat_title, cat_url):
        self.skin = get_list_skin()
        Screen.__init__(self, session)
        self.session = session
        self.cat_title = cat_title
        self.cat_url = cat_url
        self.page = 1
        self.scraper = ArabSeedScraper(config.plugins.arabseed.domain.value)
        self.items_data = []
        self.current_poster_path = ""
        self.is_loading = False
        self.is_closing = False
        self.picload = None

        self["title"] = Label(cat_title)
        self["details"] = Label("جاري جلب القائمة من السيرفر...")
        self["poster"] = Pixmap()
        self["key_red"] = Label("رجوع")
        self["key_green"] = Label("الصفحة التالية (P+)")
        self["key_yellow"] = Label("الصفحة السابقة (P-)")
        self["key_blue"] = Label("إعدادات")

        self.list_widget = MenuList([])
        self["items"] = self.list_widget

        # تهيئة مشغل فك الصور بأمان تام
        self.initPicload()

        self.poster_timer = eTimer()
        bind_timer(self.poster_timer, self.fetchCurrentPoster)

        self.list_widget.onSelectionChanged.append(self.onSelectionChangedDebounced)

        self["actions"] = ActionMap(["ColorActions", "OkCancelActions", "DirectionActions"], {
            "ok": self.itemSelected,
            "cancel": self.exitScreen,
            "red": self.exitScreen,
            "green": self.nextPage,
            "yellow": self.prevPage,
            "blue": self.openSettings,
            "pageUp": self.nextPage,
            "pageDown": self.prevPage
        }, -1)

        self.onClose.append(self.onCloseScreen)
        self.onLayoutFinish.append(self.loadDataAsync)

    def initPicload(self):
        """ تهيئة ePicLoad بأمان مع التوافق التام مع Python 2 و Python 3 (EGAMI / OpenATV / OpenPLi) """
        if getattr(self, "picload", None) is None:
            try:
                self.picload = ePicLoad()
                connected = False
                try:
                    self.picload_conn = self.picload.PictureData.connect(self.paintPosterPixmapCB)
                    connected = True
                except Exception:
                    pass
                if not connected:
                    try:
                        self.picload.PictureData.get().append(self.paintPosterPixmapCB)
                        connected = True
                    except Exception:
                        pass
            except Exception as e:
                log_debug("ePicLoad init exception: " + str(e))
                self.picload = None

    def onCloseScreen(self):
        self.is_closing = True
        try:
            self.poster_timer.stop()
        except Exception:
            pass
        try:
            if hasattr(self, 'show_timer'):
                self.show_timer.stop()
        except Exception:
            pass
        if getattr(self, "picload", None):
            try:
                del self.picload
            except Exception:
                pass
            self.picload = None

    def exitScreen(self):
        self.close()

    def loadDataAsync(self):
        if self.is_loading or self.is_closing:
            return
        self.is_loading = True
        self["details"].setText("جاري التحميل في الخلفية... يرجى الانتظار")

        def worker():
            items = self.scraper.get_items(self.cat_url, self.page)
            if self.is_closing:
                return
            self.ui_timer = eTimer()
            bind_timer(self.ui_timer, lambda: self.onDataLoaded(items))
            self.ui_timer.start(10, True)

        threading.Thread(target=worker).start()

    def onDataLoaded(self, items):
        if self.is_closing:
            return
        self.is_loading = False
        self.items_data = items
        display_list = [item["title"] for item in self.items_data]
        self.list_widget.setList(display_list)

        if self.items_data:
            self["title"].setText(self.cat_title + " - صفحة " + str(self.page) + " (" + str(len(self.items_data)) + " عنصر)")
            self.onSelectionChangedDebounced()
        else:
            err = self.scraper.last_error
            if "CLOUDFLARE" in str(err):
                self["details"].setText("النطاق الحالي محمي بـ Cloudflare. اضغط الزر الأزرق لتحديث النطاق.")
            else:
                self["details"].setText("لم يتم العثور على محتوى في هذا القسم.")

    def onSelectionChangedDebounced(self):
        if self.is_closing:
            return
        idx = self.list_widget.getSelectedIndex()
        if idx is not None and idx < len(self.items_data):
            item = self.items_data[idx]
            info_text = "السنة: %s | الجودة: %s | النوع: %s" % (
                item.get("year", "2024"),
                item.get("quality", "HD"),
                "مسلسل" if item.get("is_series", False) else "فيلم"
            )
            self["details"].setText(info_text)
            self.poster_timer.stop()
            self.poster_timer.start(250, True)

    def fetchCurrentPoster(self):
        if self.is_closing:
            return
        idx = self.list_widget.getSelectedIndex()
        if idx is not None and idx < len(self.items_data):
            poster_url = self.items_data[idx].get("poster", "")
            if not poster_url or not poster_url.startswith("http"):
                # إخفاء أي بوستر سابق عند عدم توفر رابط
                if "poster" in self and self["poster"].instance:
                    try:
                        self["poster"].instance.setPixmap(None)
                    except Exception:
                        pass
                return

            # إنشاء اسم ملف فريد وآمن بناءً على تجزئة MD5 للرابط
            safe_name = hashlib.md5(poster_url.encode("utf-8", "ignore")).hexdigest()
            local_path = os.path.join(CACHE_DIR, safe_name + ".jpg")

            # إذا كان البوستر محملاً مسبقاً وبصيغة صالحة (JPEG/PNG)، يتم عرضه فوراً
            if is_valid_jpg_or_png_file(local_path):
                self.showPoster(local_path)
                return

            def dl():
                try:
                    headers = {
                        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                        "Referer": self.scraper.base_url + "/",
                        "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8"
                    }
                    encoded_url = safe_url(poster_url)
                    req = urllib2.Request(encoded_url, headers=headers)
                    if ssl_context:
                        resp = urllib2.urlopen(req, context=ssl_context, timeout=8)
                    else:
                        resp = urllib2.urlopen(req, timeout=8)

                    data = resp.read()
                    # تحويل وحفظ الصورة بصيغة JPEG صالحة تدعمها enigma2 بدون مشاكل WebP
                    if convert_and_save_image(data, local_path):
                        if not self.is_closing:
                            self.show_timer = eTimer()
                            bind_timer(self.show_timer, lambda: self.showPoster(local_path))
                            self.show_timer.start(10, True)
                except Exception as e:
                    log_debug("Poster download error: " + str(e))

            threading.Thread(target=dl).start()

    def showPoster(self, path):
        if self.is_closing or not is_valid_jpg_or_png_file(path):
            return

        self.current_poster_path = path
        w, h, tier = get_resolution_info()
        if tier == "4k":
            p_w, p_h = 720, 950
        elif tier == "fhd":
            p_w, p_h = 460, 600
        else:
            p_w, p_h = 340, 440

        # محاولة العرض عبر ePicLoad أولاً
        self.initPicload()
        decoded = False

        if getattr(self, "picload", None):
            for para in [
                (p_w, p_h, 1, 1, False, 1, "#00000000"),
                (p_w, p_h, 1, 1, 0, 1, "#00000000"),
                (p_w, p_h, 1, 1, False, 1, "#0b0f19"),
                (p_w, p_h, 1, 1, 0, 1, "#0b0f19")
            ]:
                try:
                    self.picload.setPara(para)
                    break
                except Exception:
                    continue

            try:
                self.picload.startDecode(path)
                decoded = True
            except Exception as e:
                log_debug("startDecode error: " + str(e))

        # دعم العرض الفوري والاحتياطي عبر LoadPixmap لضمان ظهور البوستر تحت كل الظروف
        if LoadPixmap and ("poster" in self and self["poster"].instance):
            try:
                pix = LoadPixmap(path)
                if pix:
                    try:
                        self["poster"].instance.setPixmap(pix)
                    except Exception:
                        try:
                            self["poster"].instance.setPixmap(pix.__deref__())
                        except Exception:
                            pass
                    try:
                        self["poster"].show()
                    except Exception:
                        pass
            except Exception as e:
                log_debug("LoadPixmap display error: " + str(e))

    def paintPosterPixmapCB(self, *args, **kwargs):
        if self.is_closing or not getattr(self, "picload", None):
            return
        try:
            ptr = self.picload.getData()
            if ptr and "poster" in self and self["poster"].instance:
                try:
                    self["poster"].instance.setPixmap(ptr)
                except Exception:
                    try:
                        self["poster"].instance.setPixmap(ptr.__deref__())
                    except Exception:
                        pass
                try:
                    self["poster"].show()
                except Exception:
                    pass
        except Exception as e:
            log_debug("paintPosterPixmapCB error: " + str(e))

    def itemSelected(self):
        idx = self.list_widget.getSelectedIndex()
        if idx is not None and idx < len(self.items_data):
            item = self.items_data[idx]
            if item.get("is_series", False):
                self.session.open(ArabSeedEpisodesScreen, item)
            else:
                self.session.open(ArabSeedServersScreen, item)

    def nextPage(self):
        if not self.is_loading:
            self.page += 1
            self.loadDataAsync()

    def prevPage(self):
        if not self.is_loading and self.page > 1:
            self.page -= 1
            self.loadDataAsync()

    def openSettings(self):
        self.session.openWithCallback(self.afterSettings, ArabSeedSettingsScreen)

    def afterSettings(self):
        self.scraper = ArabSeedScraper(config.plugins.arabseed.domain.value)
        self.page = 1
        self.loadDataAsync()

class ArabSeedEpisodesScreen(Screen):
    """ شاشة تصفح حلقات المسلسلات مع تحجيم تلقائي لكافة الصور """
    skin = get_episodes_skin()

    def __init__(self, session, series_item):
        self.skin = get_episodes_skin()
        Screen.__init__(self, session)
        self.session = session
        self.series_item = series_item
        self.scraper = ArabSeedScraper(config.plugins.arabseed.domain.value)

        self["title"] = Label("حلقات: " + series_item.get("title", ""))
        self["key_red"] = Label("رجوع")
        self.episodes_list = []
        self.menu_list = MenuList([])
        self["episodes"] = self.menu_list

        self["actions"] = ActionMap(["ColorActions", "OkCancelActions"], {
            "ok": self.episodeSelected,
            "cancel": self.close,
            "red": self.close
        }, -1)

        self.onLayoutFinish.append(self.loadEpisodesAsync)

    def loadEpisodesAsync(self):
        def worker():
            eps = self.scraper.get_episodes(self.series_item.get("url", ""))
            self.timer = eTimer()
            bind_timer(self.timer, lambda: self.onEpisodesLoaded(eps))
            self.timer.start(10, True)

        threading.Thread(target=worker).start()

    def onEpisodesLoaded(self, eps):
        self.episodes_list = eps
        display = [ep["title"] for ep in self.episodes_list]
        self.menu_list.setList(display)
        if not self.episodes_list:
            self.session.open(MessageBox, "تعذر جلب الحلقات، قد يكون الرابط بحاجة لتحديث.", MessageBox.TYPE_WARNING, timeout=4)

    def episodeSelected(self):
        idx = self.menu_list.getSelectedIndex()
        if idx is not None and idx < len(self.episodes_list):
            ep = self.episodes_list[idx]
            self.session.open(ArabSeedServersScreen, ep)

class ArabSeedServersScreen(Screen):
    """ شاشة اختيار سيرفر المشاهدة وفك روابط البث المباشرة مع الحماية ضد 403 وتحجيم تلقائي """
    skin = get_servers_skin()

    def __init__(self, session, media_item):
        self.skin = get_servers_skin()
        Screen.__init__(self, session)
        self.session = session
        self.media_item = media_item
        self.scraper = ArabSeedScraper(config.plugins.arabseed.domain.value)

        self["title"] = Label("سيرفرات: " + media_item.get("title", ""))
        self["status"] = Label("اختر السيرفر واضغط OK للمشاهدة")
        self["key_red"] = Label("رجوع")
        self.servers_data = []
        self.menu_list = MenuList([])
        self["servers"] = self.menu_list
        self.is_resolving = False

        self["actions"] = ActionMap(["ColorActions", "OkCancelActions"], {
            "ok": self.playSelected,
            "cancel": self.close,
            "red": self.close
        }, -1)

        self.onLayoutFinish.append(self.loadServersAsync)

    def loadServersAsync(self):
        self["status"].setText("جاري استخراج السيرفرات المتاحة...")
        def worker():
            servers = self.scraper.get_servers(self.media_item.get("url", ""))
            self.t = eTimer()
            bind_timer(self.t, lambda: self.onServersLoaded(servers))
            self.t.start(10, True)

        threading.Thread(target=worker).start()

    def onServersLoaded(self, servers):
        self.servers_data = servers
        display = [s.get("name", "سيرفر") + " (" + s.get("quality", "Auto") + ")" for s in self.servers_data]
        self.menu_list.setList(display)
        if self.servers_data:
            self["status"].setText("تم العثور على %d سيرفر. اضغط OK للتشغيل." % len(self.servers_data))
        else:
            self["status"].setText("لم يتم العثور على سيرفرات مباشرة.")

    def playSelected(self):
        if self.is_resolving:
            return
        idx = self.menu_list.getSelectedIndex()
        if idx is not None and idx < len(self.servers_data):
            server = self.servers_data[idx]
            self.is_resolving = True
            self["status"].setText("جاري فك تشفير رابط البث وتشغيله...")

            def resolve_and_play():
                direct_url, referer = self.scraper.resolve_stream_url(server.get("url", ""))
                self.res_timer = eTimer()
                bind_timer(self.res_timer, lambda: self.onStreamReady(direct_url, referer))
                self.res_timer.start(10, True)

            threading.Thread(target=resolve_and_play).start()

    def onStreamReady(self, direct_url, referer=""):
        self.is_resolving = False
        is_valid = False
        if direct_url and direct_url.startswith("http"):
            low = direct_url.lower()
            if any(ext in low for ext in [".m3u8", ".mp4", ".mkv", ".ts", "/hls/", "token="]):
                is_valid = True
            elif not any(ext in low for ext in [".html", ".htm", "/watch/"]):
                is_valid = True

        if is_valid:
            self["status"].setText("جاري بدء البث المباشر...")
            log_debug("Playback initialized with referer: " + str(referer))
            self.session.open(ArabSeedPlayer, direct_url, self.media_item.get("title", "ArabSeed Stream"), referer)
        else:
            self["status"].setText("تعذر استخراج البث، اختر سيرفراً آخر")
            self.session.open(
                MessageBox,
                "تعذر استخراج رابط الفيديو المباشر من هذا السيرفر.\n\nيرجى اختيار سيرفر آخر من القائمة (مثل Vidaraa أو سيرفرات التحميل المباشر).",
                MessageBox.TYPE_WARNING,
                timeout=5
            )

def get_player_skin():
    w, h, tier = get_resolution_info()
    if tier == "4k":
        return """
        <screen name="ArabSeedPlayer" position="0,0" size="3840,2160" title="ArabSeed Player" flags="wfNoBorder" backgroundColor="transparent">
            <widget name="infobar" position="360,1820" size="3120,270" backgroundColor="#0b0f19" zPosition="2" />
            <widget name="top_border" position="360,1820" size="3120,6" backgroundColor="#f59e0b" zPosition="3" />
            
            <widget name="title" position="400,1840" size="2320,64" font="Regular;48" foregroundColor="#f59e0b" backgroundColor="#0b0f19" zPosition="4" halign="right" transparent="1" />
            <widget name="badge" position="2740,1840" size="700,64" font="Regular;40" foregroundColor="#10b981" backgroundColor="#0b0f19" zPosition="4" halign="left" transparent="1" />
            
            <widget name="progress" position="400,1920" size="3040,16" backgroundColor="#1e293b" foregroundColor="#f59e0b" zPosition="4" />
            
            <widget name="time" position="400,1956" size="1400,56" font="Regular;40" foregroundColor="#f8fafc" backgroundColor="#0b0f19" zPosition="4" halign="left" transparent="1" />
            <widget name="hint" position="1840,1956" size="1600,56" font="Regular;32" foregroundColor="#94a3af" backgroundColor="#0b0f19" zPosition="4" halign="right" transparent="1" />
            <widget name="controls" position="400,2024" size="3040,48" font="Regular;28" foregroundColor="#64748b" backgroundColor="#0b0f19" zPosition="4" halign="center" transparent="1" />
        </screen>
        """
    elif tier == "fhd":
        return """
        <screen name="ArabSeedPlayer" position="0,0" size="1920,1080" title="ArabSeed Player" flags="wfNoBorder" backgroundColor="transparent">
            <widget name="infobar" position="180,910" size="1560,135" backgroundColor="#0b0f19" zPosition="2" />
            <widget name="top_border" position="180,910" size="1560,3" backgroundColor="#f59e0b" zPosition="3" />
            
            <widget name="title" position="200,920" size="1160,32" font="Regular;24" foregroundColor="#f59e0b" backgroundColor="#0b0f19" zPosition="4" halign="right" transparent="1" />
            <widget name="badge" position="1370,920" size="350,32" font="Regular;20" foregroundColor="#10b981" backgroundColor="#0b0f19" zPosition="4" halign="left" transparent="1" />
            
            <widget name="progress" position="200,960" size="1520,8" backgroundColor="#1e293b" foregroundColor="#f59e0b" zPosition="4" />
            
            <widget name="time" position="200,978" size="700,28" font="Regular;20" foregroundColor="#f8fafc" backgroundColor="#0b0f19" zPosition="4" halign="left" transparent="1" />
            <widget name="hint" position="920,978" size="800,28" font="Regular;16" foregroundColor="#94a3af" backgroundColor="#0b0f19" zPosition="4" halign="right" transparent="1" />
            <widget name="controls" position="200,1012" size="1520,24" font="Regular;14" foregroundColor="#64748b" backgroundColor="#0b0f19" zPosition="4" halign="center" transparent="1" />
        </screen>
        """
    else:
        return """
        <screen name="ArabSeedPlayer" position="0,0" size="1280,720" title="ArabSeed Player" flags="wfNoBorder" backgroundColor="transparent">
            <widget name="infobar" position="80,585" size="1120,115" backgroundColor="#0b0f19" zPosition="2" />
            <widget name="top_border" position="80,585" size="1120,3" backgroundColor="#f59e0b" zPosition="3" />
            
            <widget name="title" position="100,593" size="800,28" font="Regular;20" foregroundColor="#f59e0b" backgroundColor="#0b0f19" zPosition="4" halign="right" transparent="1" />
            <widget name="badge" position="910,593" size="270,28" font="Regular;18" foregroundColor="#10b981" backgroundColor="#0b0f19" zPosition="4" halign="left" transparent="1" />
            
            <widget name="progress" position="100,627" size="1080,6" backgroundColor="#1e293b" foregroundColor="#f59e0b" zPosition="4" />
            
            <widget name="time" position="100,642" size="500,24" font="Regular;17" foregroundColor="#f8fafc" backgroundColor="#0b0f19" zPosition="4" halign="left" transparent="1" />
            <widget name="hint" position="610,642" size="570,24" font="Regular;14" foregroundColor="#94a3af" backgroundColor="#0b0f19" zPosition="4" halign="right" transparent="1" />
            <widget name="controls" position="100,670" size="1080,20" font="Regular;12" foregroundColor="#64748b" backgroundColor="#0b0f19" zPosition="4" halign="center" transparent="1" />
        </screen>
        """

class ArabSeedPlayer(Screen):
    """
    مشغل مخصص آمن مع نظام تحكم كامل بالبث (Full Playback Controls):
    - إيقاف مؤقت واستئناف فوري (Pause / Play / Yellow / PlayPause Key)
    - تقديم وتأخير سريع بالأسهم: ◄/► 10 ثوانٍ | ▲/▼ 60 ثانية
    - قفز زمني سريع بالأرقام القياسية: 1/3 (15 ثانية) | 4/6 (دقيقة) | 7/9 (5 دقائق)
    - شريط تقدم لحظي تفاعلي (ProgressBar) مع حساب الوقت المنقضي والإجمالي والمتبقي
    - مؤشرات وتنبيهات بصرية (OSD Badges) تظهر عند التقديم والتأخير
    - شريط متمركز في منتصف وأسفل الشاشة تماماً ليتناسب مع شاشات FHD 1080p و HD 720p
    - إخفاء تام وسلس للشريط بدون بقاء أي خطوط أو بقايا على شاشة التلفاز
    - خروج فوري وآمن دون تجميد الرسيفر عند الضغط على Exit أو Back أو Stop
    - استعادة ذكية لمشغل 4097 إذا كان 5002 غير متوفر
    """
    skin = get_player_skin()

    def __init__(self, session, stream_url, title, referer=""):
        self.skin = get_player_skin()
        Screen.__init__(self, session)
        self.session = session
        self.stream_url = stream_url
        self.video_title = title
        self.referer = referer or "https://arabseed.store/"

        self["title"] = Label(title)
        self["badge"] = Label("جاري البدء...")
        self["progress"] = ProgressBar()
        self["time"] = Label("00:00:00 / 00:00:00")
        self["hint"] = Label("اضغط OK لإظهار/إخفاء الشريط | EXIT للرجوع")
        self["controls"] = Label("الأسهم: ◄/► ±10ث ▲/▼ ±1د | الأرقام: 1/3 ±15ث 4/6 ±1د 7/9 ±5د | الأصفر: إيقاف/استئناف")
        self["infobar"] = Label()
        self["top_border"] = Label()

        self.is_paused = False
        self.is_osd_visible = True
        self.playback_started = False

        self.service_type = 4097
        try:
            cfg_player = int(config.plugins.arabseed.player.value)
            if cfg_player == 5002:
                if os.path.exists("/usr/bin/exteplayer3") or os.path.exists("/bin/exteplayer3"):
                    self.service_type = 5002
                else:
                    log_debug("exteplayer3 not installed on system, defaulting safely to 4097")
                    self.service_type = 4097
            elif cfg_player in (4097, 5001):
                self.service_type = cfg_player
        except Exception:
            self.service_type = 4097

        self.clean_url = (self.stream_url or "").strip()
        self.sref = None

        log_debug("Target Playback URL: " + self.clean_url[:120])
        log_debug("Selected Service Engine: " + str(self.service_type))

        self["actions"] = ActionMap(["ArabSeedPlayerActions", "ColorActions", "OkCancelActions", "DirectionActions", "InfobarSeekActions", "NumberActions"], {
            "cancel": self.exitPlayer,
            "red": self.exitPlayer,
            "stop": self.exitPlayer,

            "ok": self.toggleInfo,
            "toggleInfo": self.toggleInfo,
            "info": self.toggleInfo,

            "play": self.resumeStream,
            "pause": self.pauseStream,
            "playpause": self.togglePlayPause,
            "yellow": self.togglePlayPause,

            "seekLeft": lambda: self.seekRelativeSeconds(-10),
            "seekRight": lambda: self.seekRelativeSeconds(10),
            "left": lambda: self.seekRelativeSeconds(-10),
            "right": lambda: self.seekRelativeSeconds(10),
            "seekUp": lambda: self.seekRelativeSeconds(60),
            "seekDown": lambda: self.seekRelativeSeconds(-60),
            "up": lambda: self.seekRelativeSeconds(60),
            "down": lambda: self.seekRelativeSeconds(-60),

            "seekFwd": lambda: self.seekRelativeSeconds(30),
            "seekBack": lambda: self.seekRelativeSeconds(-30),

            "1": lambda: self.seekRelativeSeconds(-15),
            "3": lambda: self.seekRelativeSeconds(15),
            "4": lambda: self.seekRelativeSeconds(-60),
            "6": lambda: self.seekRelativeSeconds(60),
            "7": lambda: self.seekRelativeSeconds(-300),
            "9": lambda: self.seekRelativeSeconds(300),
            "jumpBack15": lambda: self.seekRelativeSeconds(-15),
            "jumpFwd15": lambda: self.seekRelativeSeconds(15),
            "jumpBack60": lambda: self.seekRelativeSeconds(-60),
            "jumpFwd60": lambda: self.seekRelativeSeconds(60),
            "jumpBack300": lambda: self.seekRelativeSeconds(-300),
            "jumpFwd300": lambda: self.seekRelativeSeconds(300),
        }, -1)

        self.onLayoutFinish.append(self.triggerPlaybackStart)

        self.start_timer = eTimer()
        bind_timer(self.start_timer, self.triggerPlaybackStart)
        self.start_timer.start(150, True)

        self.hide_timer = eTimer()
        bind_timer(self.hide_timer, self.hideOSD)

        self.pos_timer = eTimer()
        bind_timer(self.pos_timer, self.updatePosition)

    def triggerPlaybackStart(self):
        if self.playback_started:
            return
        self.playback_started = True
        try:
            self.start_timer.stop()
        except Exception:
            pass
        self.startPlayback()

    def startPlayback(self):
        log_debug("Starting playback for: " + str(self.video_title))
        try:
            self.session.nav.stopService()
        except Exception as e:
            log_debug("stopService exception: " + str(e))

        candidates = []
        candidates.append((self.service_type, self.clean_url, "بدء البث المباشر"))

        if self.service_type != 4097:
            candidates.append((4097, self.clean_url, "مشغل 4097 القياسي"))

        ua_url = self.clean_url
        if "#" not in ua_url and "User-Agent" not in ua_url:
            ua_url += "#User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            candidates.append((4097, ua_url, "مشغل 4097 مع ترويسة المتصفح"))

        started = False
        for s_type, url, label in candidates:
            try:
                log_debug("Attempting playService with type %d: %s" % (s_type, url[:90]))
                self.sref = eServiceReference(s_type, 0, url)
                self.sref.setName(self.video_title)
                res = self.session.nav.playService(self.sref)
                if res == 0 or res is None:
                    curr = self.session.nav.getCurrentService()
                    if curr is not None:
                        log_debug("Playback successfully initialized with type %d" % s_type)
                        started = True
                        self.pos_timer.start(1000, False)
                        self.showOSD("▶ " + label, 4000)
                        break
            except Exception as e:
                log_debug("playService attempt error (%d): %s" % (s_type, str(e)))

        if not started:
            try:
                log_debug("Force playing with 4097 as last resort...")
                self.sref = eServiceReference(4097, 0, self.clean_url)
                self.sref.setName(self.video_title)
                self.session.nav.playService(self.sref)
                self.pos_timer.start(1000, False)
                self.showOSD("▶ بدء التشغيل", 4000)
            except Exception as e:
                log_debug("Final player start error: " + str(e))
                self.session.openWithCallback(
                    self.close,
                    MessageBox,
                    "حدث خطأ أثناء بدء البث:\n" + str(e) + "\n\nيرجى تجربة سيرفر آخر من قائمة السيرفرات.",
                    MessageBox.TYPE_ERROR
                )

    def togglePlayPause(self):
        try:
            service = self.session.nav.getCurrentService()
            pauseable = service and service.pause()
            if pauseable:
                if self.is_paused:
                    pauseable.unpause()
                    self.is_paused = False
                    self.showOSD("استئناف ▶", 2500)
                else:
                    pauseable.pause()
                    self.is_paused = True
                    self.showOSD("إيقاف مؤقت ❚❚", 0)
        except Exception as e:
            log_debug("PlayPause error: " + str(e))

    def pauseStream(self):
        if not self.is_paused:
            self.togglePlayPause()

    def resumeStream(self):
        if self.is_paused:
            self.togglePlayPause()

    def seekRelativeSeconds(self, seconds):
        try:
            service = self.session.nav.getCurrentService()
            seek = service and service.seek()
            if not seek:
                self.showOSD("التقديم غير مدعوم في هذا البث", 2500)
                return

            if seconds > 0:
                if seconds >= 60:
                    badge_msg = "+%d دقيقة ⏩" % (seconds // 60)
                else:
                    badge_msg = "+%d ثانية ⏩" % seconds
            else:
                abs_sec = abs(seconds)
                if abs_sec >= 60:
                    badge_msg = "-%d دقيقة ⏪" % (abs_sec // 60)
                else:
                    badge_msg = "-%d ثانية ⏪" % abs_sec

            pos_res, current_pts = seek.getPlayPosition()
            len_res, total_pts = seek.getLength()

            if pos_res == 0 and len_res == 0 and total_pts > 0:
                target_pts = current_pts + (seconds * 90000)
                if target_pts < 0:
                    target_pts = 0
                elif target_pts > total_pts:
                    target_pts = max(0, total_pts - (5 * 90000))
                seek.seekTo(target_pts)
            else:
                direction = 1 if seconds > 0 else -1
                pts = abs(seconds) * 90000
                seek.seekRelative(direction, pts)

            self.showOSD(badge_msg, 3000)
        except Exception as e:
            log_debug("Seek error: " + str(e))

    def updatePosition(self):
        if not self.is_osd_visible:
            return

        try:
            service = self.session.nav.getCurrentService()
            seek = service and service.seek()
            if seek:
                pos_res, current_pts = seek.getPlayPosition()
                len_res, total_pts = seek.getLength()

                current_sec = (current_pts // 90000) if pos_res == 0 else 0

                if len_res == 0 and total_pts > 0:
                    total_sec = total_pts // 90000
                    percent = int((float(current_pts) / float(total_pts)) * 100)
                    rem_sec = max(0, total_sec - current_sec)
                    time_str = "%s / %s (-%s)" % (
                        self.formatTime(current_sec),
                        self.formatTime(total_sec),
                        self.formatTime(rem_sec)
                    )
                    self["progress"].setValue(percent)
                else:
                    time_str = "%s (بث مباشر)" % self.formatTime(current_sec)
                    self["progress"].setValue(0)

                self["time"].setText(time_str)
        except Exception:
            pass

    def formatTime(self, seconds):
        if seconds < 0:
            seconds = 0
        h = seconds // 3600
        m = (seconds % 3600) // 60
        s = seconds % 60
        if h > 0:
            return "%02d:%02d:%02d" % (h, m, s)
        else:
            return "%02d:%02d" % (m, s)

    def showOSD(self, badge_text="", timeout=4000):
        self.is_osd_visible = True

        self["infobar"].show()
        self["top_border"].show()
        self["title"].show()
        self["time"].show()
        self["progress"].show()
        self["hint"].show()
        self["controls"].show()

        if badge_text:
            self["badge"].setText(badge_text)
            self["badge"].show()
        else:
            self["badge"].hide()

        self.updatePosition()

        try:
            self.show()
        except Exception:
            pass

        self.hide_timer.stop()
        if timeout > 0 and not self.is_paused:
            self.hide_timer.start(timeout, True)

    def hideOSD(self):
        if self.is_paused:
            return

        self.is_osd_visible = False
        self.hide_timer.stop()

        self["infobar"].hide()
        self["top_border"].hide()
        self["title"].hide()
        self["time"].hide()
        self["progress"].hide()
        self["hint"].hide()
        self["controls"].hide()
        self["badge"].hide()

        try:
            self.hide()
        except Exception:
            pass

    def toggleInfo(self):
        if self.is_osd_visible:
            self.hideOSD()
        else:
            status_text = "❚❚ متوقف مؤقتاً" if self.is_paused else "▶ جاري البث"
            self.showOSD(status_text, 5000)

    def exitPlayer(self):
        log_debug("Safely closing ArabSeedPlayer and stopping service...")
        try:
            self.start_timer.stop()
        except Exception:
            pass
        try:
            self.pos_timer.stop()
        except Exception:
            pass
        try:
            self.hide_timer.stop()
        except Exception:
            pass
        try:
            self.session.nav.stopService()
        except Exception as e:
            log_debug("Stop service error: " + str(e))
        self.close()

class ArabSeedSettingsScreen(ConfigListScreen, Screen):
    """ شاشة إعدادات النطاق والمشغل الافتراضي مع تحجيم تلقائي لكافة الشاشات والصور """
    skin = get_settings_skin()

    def __init__(self, session):
        self.skin = get_settings_skin()
        Screen.__init__(self, session)
        self.session = session
        self.list = [
            getConfigListEntry("رابط نطاق موقع عرب سيد (Mirror):", config.plugins.arabseed.domain),
            getConfigListEntry("نوع مشغل الفيديو الافتراضي:", config.plugins.arabseed.player)
        ]
        ConfigListScreen.__init__(self, self.list)
        self["title"] = Label("إعدادات عرب سيد")
        self["key_green"] = Label("حفظ الإعدادات")
        self["key_red"] = Label("إلغاء")
        self["actions"] = ActionMap(["ColorActions", "OkCancelActions"], {
            "green": self.save,
            "red": self.cancel,
            "cancel": self.cancel
        }, -1)

    def save(self):
        for x in self["config"].list:
            x[1].save()
        self.close()

    def cancel(self):
        for x in self["config"].list:
            x[1].cancel()
        self.close()

def main(session, **kwargs):
    session.open(ArabSeedMain)

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="ArabSeed",
            description="مشاهدة الأفلام والمسلسلات من موقع عرب سيد مباشرة (نسخة سريعة ومحدثة)",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="icon.png",
            fnc=main
        ),
        PluginDescriptor(
            name="ArabSeed",
            description="عرب سيد Enigma2",
            where=PluginDescriptor.WHERE_EXTENSIONSMENU,
            fnc=main
        )
    ]
