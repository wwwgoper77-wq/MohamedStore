# -*- coding: utf-8 -*-
# =========================================================================
# Protected by MohamedStore Security Shield v3.0
# MohamedStore Cinema Movies & Series System
# Multi-layer encrypted - Python 2.7 & 3.x Compatible
# Unauthorized decompilation is strictly prohibited.
# =========================================================================
from __future__ import print_function, absolute_import
import sys
import zlib
import base64
import hashlib

_VOqedPlRiYrER = """+25L0St+INBC/eXWPzTXnOsSqdDTDJvb8igKQ+zvWYehW8JBbE6FCHZkE/wRLQOzlgN1luSusccPGfGxTQscsmQEcvZ5DpV9PmgKbv+z6s69ZCPGsJGIHIWsqsmgXXvjq7AZM1FgvWZqmodEgP71BugSdaHg3GKD/fj2M4YxvT7i9MMkMb7lxV7/kfA43mCoKsRj/PYRmyszpYjVBEDodzrEqKYJaGq42H3ytWpnbL0bDt+ZIE3oBkueSmIKgIqdJUzG2YgC6j+4+3JyeACrZaOTsRhXJerXut23EgCLRUpGQLJ06vC5iARY1XbATsJeq+6bxnNcku1GGDEX6vnUL8GClf0Arx23qyjgep8/NK1V5KYCm2WTBsJP8zQzeEjTwPHx5h2RtMyJMdbcdPUWx7Z8kGR7wlB5H74Lb8DyrE3ip5BKGMDOvZA2qE6nD2gb/zV4xcEEu65FqeY/fmz5PsRqEydgOayg8/hvSzZQfzE9TSUcy/+cYOc9OIVXXj/xb4CvYc2xGhOLjcBz2AY1DnhVs5MK02I0SaSVdofBT7REtkuItzEb3RLY17ckqWw0IqtmgsVb62z1jc7AJBGWqEo5E9NPomF70sjBkFxJwCOX7LD4q1CYXXeEkr37/LG4HoMRkGrpXwYxGrKtO4Ot9ezJYV5hskZOMcSpAia/fXrBjyfmJ7k9t0LZLExARO10kFybmIJ+n3sSs8C0wJXyWQ2dhxTpjyoGhJl8iubMsfUuhtcaBeiIhwlmGAI9gFL9Qp7HUXPKacY5Hm7m28zcNIpJBgQ9Oe2E3Qbf4MUqp0lL1LEqyMUoH63FDEbKMvJEQJc0SAHloUUbre+5rApw2hXjwt75/EmeXtZPcDTDzj0DyWmTFjY8s61/WsMS7ks7okh+3Fy95rOIZ0aBZ+b4P3KBsxMmb4PYBJZWRiaoA+9QEXIYOW7nxNxOYqnGxzcK7FyROvWCWOU2ni7r8cj9fCsQclEQCoLho9+MD1wQ9lcrdzm/NcseVmIRIk6kIbnJ9Lc0Hwd4/pqkZWKgSVLRSFnBWGSKj2V9WY9VD6tIiR6yYw/9jk/7lw6Fzw5iqkiSiZOIdBBzg2XzLnBAATU9JUvmhmyBUOax61Y9VCS0LN3hI4lvmLMNDpx+ayBMYuTDn8LYJAkHuuu0UsWDBaqMQPQ4cvkbhbNql6PBmRm0BbF3bRlMDv9RliqpQguU7bO1aCvu+h6eaz4itTJD+zvi3TcojZeuoRyVhh6VbtgwSS0gHsEN1C4Ze3O+Bc8zy+yMniNWVUC1vDCCpHiH4oqH30zb6PhZoormLQA/cN7fRCJAhgUvAcww1dEZUGJVB/X8MyQi6PJEJotVbsMD3CAKZecteDRb4FQeY7BBtvgiAyjBbVcAwGwA8ryb0r04n1iQAvOuIYMW5B7lSE3tmQlHjG37OWKXaxC8lu9ruoDXT+wAOD+kMtIGGpxHRWQY4T9YYzsx5VaEg/WCHJ7Mo5cIXohgtn6H8MrbKX16NDy4/0PtvYM0zSyobhw8pwMkLw28/zbNpRIgbnzUOwzG/T4Nr7ua82/qW1BB/b+Fp4dCS/0hHQUNT3Xn9b0pMHE8rcntxfj4fkUmiZm2DPuGRsdD1eb+/RStcdtCcmyRx3NqDyaIciF/TnrmHX3pRjffrejHeS6GJ2zHrPndJSTp9XeumxtVO2A/8+mQiTQyU1gHKZvH1nV/JAWnTlCWIlN4orlPORz1WWtgXyC/rYjZtA=="""

_EeJpWtimtDEY = b"MSH_2026_SHIELD_P"
_uEllLhNX = b"EY_SEC_DYN"
_HfgLFgjCvlvNdwYllC = b"ART_A_XOR_K"
_ChoGQhRSwgrMBmzMV = b"AMIC_SALT_7"

_BHQUUYeSKdDo = "c3c515a32a6e3e79ef9e863451aff338"

_JjHUqdmqVZkpl = 3

def _UkgHA_fpjzsTMh():
    _EhLmMujlaZTjv = _EeJpWtimtDEY + _uEllLhNX + _HfgLFgjCvlvNdwYllC + _ChoGQhRSwgrMBmzMV
    for _Zlmiwr_EBXUc_RpP in range(64):
        _EhLmMujlaZTjv = hashlib.sha256(_EhLmMujlaZTjv).digest()
    return _EhLmMujlaZTjv

def _nrkjyZIrMzSLsgcg(_rdKtjIEKZ, _IFEFNhhBHz):
    _FgnfsZPl = bytearray(len(_rdKtjIEKZ))
    for _OWPdEFomDzZDRfO in range(len(_rdKtjIEKZ)):
        _NmgZCyFr = (_JjHUqdmqVZkpl + (_OWPdEFomDzZDRfO % 7)) & 0x7
        _zsoJW_urXyuS = _rdKtjIEKZ[_OWPdEFomDzZDRfO]
        _FgnfsZPl[_OWPdEFomDzZDRfO] = ((_zsoJW_urXyuS >> _NmgZCyFr) | (_zsoJW_urXyuS << (8 - _NmgZCyFr))) & 0xFF
    return bytes(_FgnfsZPl)

def _tsENOSHtFDTXSeRXO(_rdKtjIEKZ, _HgntYbqXoAB):
    _FgnfsZPl = bytearray(len(_rdKtjIEKZ))
    _DTgkCwcNBwPWjN = len(_HgntYbqXoAB)
    for _OWPdEFomDzZDRfO in range(len(_rdKtjIEKZ)):
        _iqNawKqIF = _HgntYbqXoAB[_OWPdEFomDzZDRfO % _DTgkCwcNBwPWjN] ^ (_OWPdEFomDzZDRfO & 0xFF)
        _FgnfsZPl[_OWPdEFomDzZDRfO] = _rdKtjIEKZ[_OWPdEFomDzZDRfO] ^ _iqNawKqIF
    return bytes(_FgnfsZPl)

def _UegoHsPk(_rdKtjIEKZ, _HgntYbqXoAB):
    _RRpMRmJl = hashlib.sha256(_HgntYbqXoAB + _rdKtjIEKZ + _HgntYbqXoAB).digest()[:16].hex()
    return _RRpMRmJl == _BHQUUYeSKdDo

def _SYHZdFieDfpCNSw_H(_CpBKEiqZZAunIJ):
    try:
        _QRucdmgXQkfafyB = base64.b64decode(_VOqedPlRiYrER)
        _BHOirLfERzPYOal = _UkgHA_fpjzsTMh()
        if not _UegoHsPk(_QRucdmgXQkfafyB, _BHOirLfERzPYOal):
            return False
        _hCwDFCGJGPrcBt = _nrkjyZIrMzSLsgcg(_QRucdmgXQkfafyB, _JjHUqdmqVZkpl)
        _NyUvGwfrjlJWIv = _tsENOSHtFDTXSeRXO(_hCwDFCGJGPrcBt, _BHOirLfERzPYOal)
        if sys.version_info[0] == 2:
            _dwaNvwun_j = zlib.decompress(str(_NyUvGwfrjlJWIv))
        else:
            _dwaNvwun_j = zlib.decompress(bytes(_NyUvGwfrjlJWIv)).decode("utf-8")
        exec(_dwaNvwun_j, _CpBKEiqZZAunIJ)
        return True
    except Exception as _JwbJeVjbThJ:
        try:
            with open("/tmp/cinema_boot_error.log", "w") as _XffLIKuBFL:
                import traceback
                traceback.print_exc(file=_XffLIKuBFL)
        except:
            pass
        return False

_MHAE_QPDIPspJYuTr = _SYHZdFieDfpCNSw_H(globals())

if "Plugins" not in globals():
    try:
        from Plugins.Plugin import PluginDescriptor
        def Plugins(**kwargs):
            try:
                from Screens.MessageBox import MessageBox
                def _notify_err(session, **kw):
                    session.open(MessageBox, "سينما: حدث خطأ. راجع /tmp/cinema_boot_error.log", MessageBox.TYPE_ERROR)
                return [PluginDescriptor(name="سينما افلام ومسلسلات", where=PluginDescriptor.WHERE_PLUGINMENU, fnc=_notify_err)]
            except:
                return []
    except:
        pass
