# -*- coding: utf-8 -*-
# =========================================================================
# Protected by MohamedStore Security Shield v3.0
# MohamedStore Cinema Movies & Series System
# Multi-layer encrypted - Python 2.7 & 3.x Compatible
# Unauthorized decompilation is strictly prohibited.
# =========================================================================
from __future__ import print_function, absolute_import
import sys
import zlib
import base64
import hashlib

_SPmIxQHZC = """/psSlFrfiAyQb3u0x5l6wuFYdgwnmMcHuUcHm2x3MwmnJuMRU+OYnArRKTphNtdTU5CPOdR9NqcEyaPOD66vOSvaYN3kLOVY9b78VCD0g3piNczGKWWjlih6AwPGP4wXgpv78mttRtKhkIphTshEc/HGBj3xSwTnKO5BsjauoofQS7pu20SUATnXG8y7ARJd/t2tB5NhURz6cGRK1uY/svX1+krZ7Tuz/KAlcWFZai4YzcbZLQ1UXy9RjzH8DVFuWuaC0A08pZ4fD0y4SNtzTyc3Z4HwAL33FuqIdlszvtBOhq9wtaJl3semlygGLQBJ5aoCur1WJXHP9hDJ5maU7qQziQootWU9zWCLrVzPfOOLjw4TeEJiNIjOjQp90wf3TnX4Md3sOUfL6Q7VVm3WzVIqfrXwPG81JZjgxeIc/eLZaPYwHJOc6WFAwZknrYWM4NU27CcHCNCAltJtZa9jgwaYdAljQQFD0dwrPAmcuB/6wjQhjfEcofXydxNz49zKldWeSLJD/k887X+UmUDmu4F6pcix2MqPRzXYsrYJqVH6cL0HZn4t2rhbM7r/qnA7r50mo8eZRVEctH5DQHcqs5SEn1eKcp+2iC+WMXLArnNE+Bc+ekJzThGNaohXSRneiO8W9NM81f+YHlxzgIcVb6C9E/J6aj9Z5Sp5cp1Pl/dK0shSGcHMyow8GQAJO6v56JpBp3S2O8t2/l11aDtn5X87mP3y13XxvRJSoygtwEwuXTs6TAy7AIvCLWP54bkPmMMRzDSxG5yPcfhPtOsP+/ufWTyKcYZSkAKQsOnpEMCA1YIMPij/ExngPvfcfDGuZkBrt3635FKYBkpMMkMC4u4Ns/oSLzUuY8XpMqY1/lZlk+bNmnKJEPAH0X/d28tbRMX+rNvuu4NmGNDmpMaaKkyvpepHVvmNtZu0BnJIGqsKry/G/cQVNIml6InoZTMR8xIblr3lTo0/yxhDafR9uBr2O/YtpQWcHCIy4gFlJPaFvnNT4XwGpOpsktnMtdcpq8psiVqrNYJitBTy+5oTL2dvaEooWUrP/lcmi5p/U+9O2gQrAdWm9IamaPpHur+PJ3oB/GoKqiaOGstnSs9VDmhw46A0a7Zx6zxAk+DNjlaK2y0+UOqYQ7TKg8KX5wpGAwLeT3O0r0MezFum+eZskFlR1UrNCiInrtdYfttHQjpesw+o584X8zU8MlwO+MZsD0qhrRFKoi1evESA84IHcFxqPe9aMjaMkr2CoV7MmxAggZnNmxGYR+1oLVSRyjSF5fHnsRqIZo0ue2lqh7s97w9a1873GnsIGPpSXl+H/w+MR+D8aK2mWO32/aW4zuSsnCzTwSDNRBqXPC+sa9povEmT82v+sbpOrSAM4u2ECKvScwfEeWIqKZ6x8ggNg2xlpCLbOxkMH/o57hjBokevBDub/kCWTH+Fp8F+CWo6t2d/yU786DGZ1bV9XMZFh4IafYS0kUw+F9kGsRMSaVYn+UeX4+ZpDXttiaWX3i7XohBNhsGcJB6+PgnHE37mMm1AiN7j2FHAwQkjQfSc8e47EyKtMJ78dcXEt2Vdk9aCVl65JcxadhnO8pevO6vjxesPZoejE1OE1NCax+y+OgMnofo0r/QTbb8jeMgF/L+IFJKpp9NC5+ZKJcc55hlwlf1XpG5JdYvwA7EApHcihmAKFAqS5E3HBn5tA4BKX31xnKvKzOW1Nb3gelnYgxydUqpHjkugm9pyfgYdVrtfokxTgXkC5i90t/H1X5cXtawbw47qtVG0oBlQ5R3yzeTmBcoxFiC7BJB3ojLl73Lghcc8WFwBX4KY71PjGINt/iOpbAXksmEi5259tSYRNyr1E9kHebVukHZRA9j8Y4L7+D0bfZ6VRw2jTHNjpGo2I1GFDaTv0rT+SD8N+TAgVeEi4Kd3sVhXhD9gdGt9kG13lgYtyCtwK+/5Peot+WToCxkmR+pqlFKgP5lAXVoJYICsmqSFulIN+bIknaJpKPGY1knUDP3muNRdz0/tj/968dZ2r6ck5bbW28cb+AJ2hSvuN9ltstN6tIBPwivjF0TTpMwwkCLZ+ROQersiCtB0vO1ATdoSUKZJqxPaHIVuJhGeAx/YsVEmREsh7g+LqFRggEy11j7zKN7Iy9LAWoPn1Y2f9IGLW3AbzdOoXJOrXiAcnZJVoXmE0ReE0zhyyNgZFSXZ8hzdJ5Flkx1jbJqw+KBAF8v2ZxFb70OWiJXyvpeoMCqjEmDMkWxXsLUma/zJz8QG8gFZe7t1g+bLNq7oXeMEY9QPMYdNalg0ILL0EyFB9jjZIefNIn8GEJuloIAijMGT2QF+lr0="""

_LudItZppRzQkGaw = b"MSH_2026_SHIELD_P"
_sjwHnggkG = b"EY_SEC_DYN"
_UgritpLfKiyqEsCPo = b"ART_A_XOR_K"
_UnKGfJMOQhKIKCGV = b"AMIC_SALT_7"

_MnHfDlep_ = "9bdc9a58176fa54d8b8ecda2a52615d9"

_PEnZJrEh = 1

def _foWvQMCXpoy():
    _qrfhkIKfvosP = _LudItZppRzQkGaw + _sjwHnggkG + _UgritpLfKiyqEsCPo + _UnKGfJMOQhKIKCGV
    for _MXwRZJAdx in range(64):
        _qrfhkIKfvosP = hashlib.sha256(_qrfhkIKfvosP).digest()
    return _qrfhkIKfvosP

def _NPySIugqgHF(_GCOHMOdIj, _CpeWXZDcnD):
    _BImijRlEXHLLX = bytearray(len(_GCOHMOdIj))
    for _zmupQXCGy in range(len(_GCOHMOdIj)):
        _FmtvWPBEF_QZYTvASR = (_PEnZJrEh + (_zmupQXCGy % 7)) & 0x7
        _FXpqwDXzejvLmP = _GCOHMOdIj[_zmupQXCGy]
        _BImijRlEXHLLX[_zmupQXCGy] = ((_FXpqwDXzejvLmP >> _FmtvWPBEF_QZYTvASR) | (_FXpqwDXzejvLmP << (8 - _FmtvWPBEF_QZYTvASR))) & 0xFF
    return bytes(_BImijRlEXHLLX)

def _vdrlpZjqkt(_GCOHMOdIj, _rdXVLsaiESi):
    _BImijRlEXHLLX = bytearray(len(_GCOHMOdIj))
    _IbzfqcOLjEUU = len(_rdXVLsaiESi)
    for _zmupQXCGy in range(len(_GCOHMOdIj)):
        _QiVfhrgvPhYVRS = _rdXVLsaiESi[_zmupQXCGy % _IbzfqcOLjEUU] ^ (_zmupQXCGy & 0xFF)
        _BImijRlEXHLLX[_zmupQXCGy] = _GCOHMOdIj[_zmupQXCGy] ^ _QiVfhrgvPhYVRS
    return bytes(_BImijRlEXHLLX)

def _dCzIKzUJOQkkfy(_GCOHMOdIj, _rdXVLsaiESi):
    _VfqdFNYQRTXbsbte = hashlib.sha256(_rdXVLsaiESi + _GCOHMOdIj + _rdXVLsaiESi).digest()[:16].hex()
    return _VfqdFNYQRTXbsbte == _MnHfDlep_

def _zyRlEkyzRZGMdXlUp(_jNUEzTqzV_wcgDC):
    try:
        _JyfIunghdyhypuFbOG = base64.b64decode(_SPmIxQHZC)
        _AqCBtLlRQwgSEaigFd = _foWvQMCXpoy()
        if not _dCzIKzUJOQkkfy(_JyfIunghdyhypuFbOG, _AqCBtLlRQwgSEaigFd):
            return False
        _LBILfrbGoTie = _NPySIugqgHF(_JyfIunghdyhypuFbOG, _PEnZJrEh)
        _LVZVXwKfpXYsUIypTM = _vdrlpZjqkt(_LBILfrbGoTie, _AqCBtLlRQwgSEaigFd)
        if sys.version_info[0] == 2:
            _ciFYrdxUpOIcOO = zlib.decompress(str(_LVZVXwKfpXYsUIypTM))
        else:
            _ciFYrdxUpOIcOO = zlib.decompress(bytes(_LVZVXwKfpXYsUIypTM)).decode("utf-8")
        exec(_ciFYrdxUpOIcOO, _jNUEzTqzV_wcgDC)
        return True
    except Exception as _B_dUoRnP_hRHU:
        try:
            with open("/tmp/cinema_boot_error.log", "w") as _unniM_OFWVN:
                import traceback
                traceback.print_exc(file=_unniM_OFWVN)
        except:
            pass
        return False

_xyDMpwKQcDMqT = _zyRlEkyzRZGMdXlUp(globals())

if "Plugins" not in globals():
    try:
        from Plugins.Plugin import PluginDescriptor
        def Plugins(**kwargs):
            try:
                from Screens.MessageBox import MessageBox
                def _notify_err(session, **kw):
                    session.open(MessageBox, "سينما: حدث خطأ. راجع /tmp/cinema_boot_error.log", MessageBox.TYPE_ERROR)
                return [PluginDescriptor(name="سينما افلام ومسلسلات", where=PluginDescriptor.WHERE_PLUGINMENU, fnc=_notify_err)]
            except:
                return []
    except:
        pass
