# -*- coding: utf-8 -*-
"""
===================================================================
 Arabseed Enigma2 Plugin - Fixed & Optimized Edition
 Compatible with: Python 2 & Python 3 (EGAMI, OpenATV, OpenPLi, Pure2, BlackHole, DreamOS)
 Target Website: https://www.arabseed.wine/home/ (and official mirrors)
 Features:
   - Full support for Arabseed site (arabseed.wine) and official mirrors
   - Standalone Years Filter (فترة السنوات منفصلة تماماً عن الأفلام والمسلسلات)
   - Comprehensive Years Listing: Merges all movies and series per year (2026, 2025, 2024...)
   - Automatic Series & Shows Grouping: Groups multiple episode dumps into clean Series cards
   - Full Stream Resolving (MegaMax, EarnVids, Morencius, MixDrop, HGCloud, Direct MP4, CDN)
   - Proper User-Agent & Referer Injection to prevent 403 Forbidden
   - Full Playback Controls (Play, Pause, Fast Forward, Rewind, Quick Jump 1/3/4/6/7/9, Minute Jump via Blue key)
   - Real-time Progress Bar & Elapsed/Total/Remaining Time Display
   - Safe Non-blocking Async Threading & Instant Exit Protection
   - Auto-scaling Resolution (4K UHD, FHD 1080p, HD 720p)
   - Posters display & WebP to JPEG auto-conversion (PIL / ffmpeg / dwebp)
   - Branding: هذا البلجن متاح MohamedStore
===================================================================
"""

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.InputBox import InputBox
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.ProgressBar import ProgressBar
from Components.config import config, ConfigSubsection, ConfigText, ConfigSelection, getConfigListEntry
from Components.ConfigList import ConfigListScreen
from Tools.Directories import fileExists
from enigma import ePicLoad, eServiceReference, eTimer, iPlayableService, getDesktop

try:
    from Tools.LoadPixmap import LoadPixmap
except Exception:
    LoadPixmap = None

import sys
import os
import threading
import re
import zlib
import gzip
import json
import hashlib

PLUGIN_PATH = os.path.dirname(os.path.abspath(__file__))
# Do NOT pollute sys.path[0] to prevent collisions with other plugins like Akwam
if PLUGIN_PATH not in sys.path:
    sys.path.append(PLUGIN_PATH)

PY3 = sys.version_info[0] == 3
if PY3:
    import urllib.request as urllib2
    from urllib.parse import urljoin, quote, unquote, urlparse
    from io import BytesIO
else:
    import urllib2
    from urlparse import urljoin, urlparse
    from urllib import quote, unquote
    from StringIO import StringIO as BytesIO

LOG_FILE = "/tmp/arabseed.log"

def log_debug(msg):
    try:
        with open(LOG_FILE, "a") as f:
            f.write("[Arabseed] " + str(msg) + "\n")
    except Exception:
        pass
    print("[Arabseed] " + str(msg))

def safe_url(url):
    if not url:
        return ""
    if PY3:
        import urllib.parse
        return urllib.parse.quote(str(url), safe=":/%?&=+#@!$,;'*()")
    else:
        import urllib
        try:
            if isinstance(url, unicode):
                url = url.encode("utf-8")
        except NameError:
            pass
        return urllib.quote(str(url), safe=":/%?&=+#@!$,;'*()")

ssl_context = None
try:
    import ssl
    ssl_context = ssl._create_unverified_context()
except Exception:
    ssl_context = None

def is_valid_image_bytes(data):
    if not data or len(data) < 100:
        return False
    if data.startswith(b"<!DOCTYPE") or data.startswith(b"<html") or b"<title>Just a moment" in data:
        return False
    return True

def convert_and_save_image(data, target_path):
    if not is_valid_image_bytes(data):
        return False

    if data.startswith(b"\xff\xd8") or data.startswith(b"\x89PNG"):
        try:
            with open(target_path, "wb") as f:
                f.write(data)
            return True
        except Exception:
            return False

    try:
        from PIL import Image
        import io
        img = Image.open(io.BytesIO(data))
        if img.mode != "RGB":
            img = img.convert("RGB")
        img.save(target_path, "JPEG", quality=85)
        if fileExists(target_path) and os.path.getsize(target_path) > 100:
            return True
    except Exception:
        pass

    tmp_input = target_path + ".tmp.webp"
    try:
        with open(tmp_input, "wb") as f:
            f.write(data)
        cmd = "ffmpeg -y -i '%s' -q:v 2 '%s' > /dev/null 2>&1" % (tmp_input, target_path)
        os.system(cmd)
        if fileExists(target_path) and os.path.getsize(target_path) > 100:
            return True
    except Exception:
        pass
    finally:
        if fileExists(tmp_input):
            try:
                os.remove(tmp_input)
            except Exception:
                pass

    try:
        with open(target_path, "wb") as f:
            f.write(data)
        return True
    except Exception:
        return False

def is_valid_jpg_or_png_file(path):
    if not fileExists(path) or os.path.getsize(path) < 100:
        return False
    try:
        with open(path, "rb") as f:
            header = f.read(16)
        if header.startswith(b"\xff\xd8") or header.startswith(b"\x89PNG"):
            return True
        if header.startswith(b"RIFF") and b"WEBP" in header:
            with open(path, "rb") as f:
                raw_bytes = f.read()
            if convert_and_save_image(raw_bytes, path):
                return True
        return False
    except Exception:
        return False

try:
    from Plugins.Extensions.Arabseed.arabseed_scraper import ArabseedScraper, safe_url
except Exception:
    try:
        from arabseed_scraper import ArabseedScraper, safe_url
    except Exception:
        from scraper import ArabseedScraper, safe_url

CACHE_DIR = "/tmp/arabseed_cache"
if not os.path.exists(CACHE_DIR):
    try:
        os.makedirs(CACHE_DIR)
    except Exception:
        pass

config.plugins.arabseed = ConfigSubsection()
config.plugins.arabseed.domain = ConfigText(default="https://www.arabseed.wine/home/", fixed_size=False)
config.plugins.arabseed.player = ConfigSelection(default="4097", choices=[
    ("4097", "Default Enigma2 Player (افتراضي 4097 - لكافة الأجهزة)"),
    ("5002", "Exteplayer3 - FFmpeg (5002 - يتطلب حزمة exteplayer3)"),
    ("5001", "GstPlayer - GStreamer (5001)")
])

def get_resolution_info():
    try:
        size = getDesktop(0).size()
        w = size.width()
        h = size.height()
    except Exception:
        w, h = 1920, 1080

    if w >= 2560:
        return w, h, "4k"
    elif w >= 1600:
        return w, h, "fhd"
    else:
        return w, h, "hd"

def bind_timer(timer, callback_func, screen_instance=None, conn_name=None):
    if hasattr(timer, "callback"):
        try:
            timer.callback.append(callback_func)
            return
        except Exception:
            pass
    if hasattr(timer, "timeout"):
        try:
            conn = timer.timeout.connect(callback_func)
            if screen_instance and conn_name:
                setattr(screen_instance, conn_name, conn)
            return
        except Exception:
            pass

def format_time_hms(seconds):
    if seconds < 0:
        seconds = 0
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    if h > 0:
        return "%02d:%02d:%02d" % (h, m, s)
    return "%02d:%02d" % (m, s)

def prepare_stream_url_with_headers(raw_url, referer=""):
    url = (raw_url or "").strip()
    if not url.startswith("http"):
        return url

    if "#" in url:
        url = url.split("#")[0].strip()

    low = url.lower()
    if any(ext in low for ext in [".mp4", ".mkv", ".ts", ".avi"]) and ("megaup" in low or "cdn" in low or "1cloud" in low):
        return url

    # HLS streams or external embedded hosts
    ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    ref = referer or "https://www.arabseed.wine/"
    return url + "#User-Agent=" + quote(ua) + "&Referer=" + quote(ref)

def get_main_skin():
    w, h, tier = get_resolution_info()
    if tier == "4k":
        return """
        <screen name="ArabseedMain" position="center,center" size="2400,1350" title="Arabseed - عرب سيد" flags="wfNoBorder" backgroundColor="#0b0f19">
            <eLabel position="0,0" size="2400,150" backgroundColor="#111827" zPosition="1" />
            <eLabel position="70,45" size="20,60" backgroundColor="#f59e0b" zPosition="2" />
            <widget name="title" position="110,38" size="1100,75" font="Regular;46" foregroundColor="#f59e0b" backgroundColor="#111827" zPosition="2" halign="right" />
            <widget name="info" position="1230,48" size="1100,60" font="Regular;32" foregroundColor="#9ca3af" backgroundColor="#111827" zPosition="2" halign="left" />
            <eLabel position="0,146" size="2400,4" backgroundColor="#f59e0b" zPosition="3" />

            <widget name="menu" position="100,180" size="2200,950" font="Regular;38" itemHeight="88" scrollbarMode="showOnDemand" selectionColor="#1e293b" foregroundColor="#f3f4f6" backgroundColor="#0b0f19" transparent="1" />

            <eLabel position="0,1150" size="2400,200" backgroundColor="#111827" zPosition="1" />
            <eLabel position="100,1175" size="480,10" backgroundColor="#ef4444" zPosition="2" />
            <widget name="key_red" position="100,1198" size="480,55" font="Regular;32" foregroundColor="#f8fafc" backgroundColor="#111827" zPosition="2" halign="center" />
            <eLabel position="650,1175" size="480,10" backgroundColor="#10b981" zPosition="2" />
            <widget name="key_green" position="650,1198" size="480,55" font="Regular;32" foregroundColor="#f8fafc" backgroundColor="#111827" zPosition="2" halign="center" />
            <eLabel position="1200,1175" size="480,10" backgroundColor="#f59e0b" zPosition="2" />
            <widget name="key_yellow" position="1200,1198" size="480,55" font="Regular;32" foregroundColor="#f8fafc" backgroundColor="#111827" zPosition="2" halign="center" />
            <eLabel position="1750,1175" size="480,10" backgroundColor="#3b82f6" zPosition="2" />
            <widget name="key_blue" position="1750,1198" size="480,55" font="Regular;32" foregroundColor="#f8fafc" backgroundColor="#111827" zPosition="2" halign="center" />

            <eLabel text="هذا البلجن متاح MohamedStore" position="200,1280" size="2000,50" font="Regular;30" foregroundColor="#f59e0b" backgroundColor="#111827" zPosition="2" halign="center" transparent="1" />
        </screen>
        """
    elif tier == "fhd":
        return """
        <screen name="ArabseedMain" position="center,center" size="1600,900" title="Arabseed - عرب سيد" flags="wfNoBorder" backgroundColor="#0b0f19">
            <eLabel position="0,0" size="1600,100" backgroundColor="#111827" zPosition="1" />
            <eLabel position="50,30" size="14,40" backgroundColor="#f59e0b" zPosition="2" />
            <widget name="title" position="80,25" size="750,55" font="Regular;36" foregroundColor="#f59e0b" backgroundColor="#111827" zPosition="2" halign="right" />
            <widget name="info" position="850,32" size="700,40" font="Regular;24" foregroundColor="#9ca3af" backgroundColor="#111827" zPosition="2" halign="left" />
            <eLabel position="0,97" size="1600,3" backgroundColor="#f59e0b" zPosition="3" />

            <widget name="menu" position="80,125" size="1440,630" font="Regular;28" itemHeight="60" scrollbarMode="showOnDemand" selectionColor="#1e293b" foregroundColor="#f3f4f6" backgroundColor="#0b0f19" transparent="1" />

            <eLabel position="0,770" size="1600,130" backgroundColor="#111827" zPosition="1" />
            <eLabel position="80,788" size="320,7" backgroundColor="#ef4444" zPosition="2" />
            <widget name="key_red" position="80,802" size="320,38" font="Regular;22" foregroundColor="#f8fafc" backgroundColor="#111827" zPosition="2" halign="center" />
            <eLabel position="450,788" size="320,7" backgroundColor="#10b981" zPosition="2" />
            <widget name="key_green" position="450,802" size="320,38" font="Regular;22" foregroundColor="#f8fafc" backgroundColor="#111827" zPosition="2" halign="center" />
            <eLabel position="820,788" size="320,7" backgroundColor="#f59e0b" zPosition="2" />
            <widget name="key_yellow" position="820,802" size="320,38" font="Regular;22" foregroundColor="#f8fafc" backgroundColor="#111827" zPosition="2" halign="center" />
            <eLabel position="1190,788" size="320,7" backgroundColor="#3b82f6" zPosition="2" />
            <widget name="key_blue" position="1190,802" size="320,38" font="Regular;22" foregroundColor="#f8fafc" backgroundColor="#111827" zPosition="2" halign="center" />

            <eLabel text="هذا البلجن متاح MohamedStore" position="100,855" size="1400,35" font="Regular;22" foregroundColor="#f59e0b" backgroundColor="#111827" zPosition="2" halign="center" transparent="1" />
        </screen>
        """
    else:
        return """
        <screen name="ArabseedMain" position="center,center" size="1160,640" title="Arabseed - عرب سيد" flags="wfNoBorder" backgroundColor="#0b0f19">
            <eLabel position="0,0" size="1160,75" backgroundColor="#111827" zPosition="1" />
            <eLabel position="35,22" size="10,28" backgroundColor="#f59e0b" zPosition="2" />
            <widget name="title" position="55,18" size="550,40" font="Regular;26" foregroundColor="#f59e0b" backgroundColor="#111827" zPosition="2" halign="right" />
            <widget name="info" position="615,24" size="510,30" font="Regular;18" foregroundColor="#9ca3af" backgroundColor="#111827" zPosition="2" halign="left" />
            <eLabel position="0,73" size="1160,2" backgroundColor="#f59e0b" zPosition="3" />

            <widget name="menu" position="50,90" size="1060,450" font="Regular;22" itemHeight="45" scrollbarMode="showOnDemand" selectionColor="#1e293b" foregroundColor="#f3f4f6" backgroundColor="#0b0f19" transparent="1" />

            <eLabel position="0,550" size="1160,90" backgroundColor="#111827" zPosition="1" />
            <eLabel position="50,560" size="235,5" backgroundColor="#ef4444" zPosition="2" />
            <widget name="key_red" position="50,570" size="235,28" font="Regular;17" foregroundColor="#f8fafc" backgroundColor="#111827" zPosition="2" halign="center" />
            <eLabel position="320,560" size="235,5" backgroundColor="#10b981" zPosition="2" />
            <widget name="key_green" position="320,570" size="235,28" font="Regular;17" foregroundColor="#f8fafc" backgroundColor="#111827" zPosition="2" halign="center" />
            <eLabel position="590,560" size="235,5" backgroundColor="#f59e0b" zPosition="2" />
            <widget name="key_yellow" position="590,570" size="235,28" font="Regular;17" foregroundColor="#f8fafc" backgroundColor="#111827" zPosition="2" halign="center" />
            <eLabel position="860,560" size="235,5" backgroundColor="#3b82f6" zPosition="2" />
            <widget name="key_blue" position="860,570" size="235,28" font="Regular;17" foregroundColor="#f8fafc" backgroundColor="#111827" zPosition="2" halign="center" />

            <eLabel text="هذا البلجن متاح MohamedStore" position="50,605" size="1060,28" font="Regular;16" foregroundColor="#f59e0b" backgroundColor="#111827" zPosition="2" halign="center" transparent="1" />
        </screen>
        """

def get_list_skin():
    w, h, tier = get_resolution_info()
    if tier == "4k":
        return """
        <screen name="ArabseedListScreen" position="center,center" size="3000,1650" title="قائمة الأفلام والمسلسلات" flags="wfNoBorder" backgroundColor="#0b0f19">
            <eLabel position="0,0" size="3000,150" backgroundColor="#111827" zPosition="1" />
            <widget name="title" position="80,35" size="2840,75" font="Regular;46" foregroundColor="#f59e0b" backgroundColor="#111827" zPosition="2" halign="right"/>
            <eLabel position="0,146" size="3000,4" backgroundColor="#f59e0b" zPosition="3" />

            <widget name="items" position="860,190" size="2060,1260" itemHeight="90" font="Regular;38" selectionColor="#1e293b" foregroundColor="#f8fafc" backgroundColor="#0b0f19" scrollbarMode="showOnDemand" transparent="1" />
            
            <widget name="poster" position="80,190" size="720,950" zPosition="2" alphatest="blend" />
            <widget name="details" position="80,1160" size="720,290" font="Regular;32" foregroundColor="#94a3b8" backgroundColor="#0b0f19" transparent="1" halign="right"/>
            
            <eLabel position="0,1480" size="3000,170" backgroundColor="#111827" zPosition="1" />
            <eLabel position="80,1500" size="650,10" backgroundColor="#ef4444" zPosition="2" />
            <widget name="key_red" position="80,1520" size="650,55" font="Regular;30" halign="center" transparent="1" zPosition="2" />
            <eLabel position="780,1500" size="650,10" backgroundColor="#10b981" zPosition="2" />
            <widget name="key_green" position="780,1520" size="650,55" font="Regular;30" halign="center" transparent="1" zPosition="2" />
            <eLabel position="1480,1500" size="650,10" backgroundColor="#f59e0b" zPosition="2" />
            <widget name="key_yellow" position="1480,1520" size="650,55" font="Regular;30" halign="center" transparent="1" zPosition="2" />
            <eLabel position="2180,1500" size="650,10" backgroundColor="#3b82f6" zPosition="2" />
            <widget name="key_blue" position="2180,1520" size="650,55" font="Regular;30" halign="center" transparent="1" zPosition="2" />

            <eLabel text="هذا البلجن متاح MohamedStore" position="200,1585" size="2600,45" font="Regular;26" foregroundColor="#f59e0b" backgroundColor="#111827" zPosition="2" halign="center" transparent="1" />
        </screen>
        """
    elif tier == "fhd":
        return """
        <screen name="ArabseedListScreen" position="center,center" size="1800,980" title="قائمة الأفلام والمسلسلات" flags="wfNoBorder" backgroundColor="#0b0f19">
            <eLabel position="0,0" size="1800,95" backgroundColor="#111827" zPosition="1" />
            <widget name="title" position="50,22" size="1700,55" font="Regular;34" foregroundColor="#f59e0b" backgroundColor="#111827" zPosition="2" halign="right"/>
            <eLabel position="0,92" size="1800,3" backgroundColor="#f59e0b" zPosition="3" />

            <widget name="items" position="550,120" size="1200,730" itemHeight="55" font="Regular;26" selectionColor="#1e293b" foregroundColor="#f8fafc" backgroundColor="#0b0f19" scrollbarMode="showOnDemand" transparent="1" />
            
            <widget name="poster" position="50,120" size="460,600" zPosition="2" alphatest="blend" />
            <widget name="details" position="50,740" size="460,110" font="Regular;22" foregroundColor="#94a3b8" backgroundColor="#0b0f19" transparent="1" halign="right"/>
            
            <eLabel position="0,865" size="1800,115" backgroundColor="#111827" zPosition="1" />
            <eLabel position="50,880" size="390,6" backgroundColor="#ef4444" zPosition="2" />
            <widget name="key_red" position="50,895" size="390,38" font="Regular;22" halign="center" transparent="1" zPosition="2" />
            <eLabel position="480,880" size="390,6" backgroundColor="#10b981" zPosition="2" />
            <widget name="key_green" position="480,895" size="390,38" font="Regular;22" halign="center" transparent="1" zPosition="2" />
            <eLabel position="910,880" size="390,6" backgroundColor="#f59e0b" zPosition="2" />
            <widget name="key_yellow" position="910,895" size="390,38" font="Regular;22" halign="center" transparent="1" zPosition="2" />
            <eLabel position="1340,880" size="390,6" backgroundColor="#3b82f6" zPosition="2" />
            <widget name="key_blue" position="1340,895" size="390,38" font="Regular;22" halign="center" transparent="1" zPosition="2" />

            <eLabel text="هذا البلجن متاح MohamedStore" position="100,940" size="1600,30" font="Regular;18" foregroundColor="#f59e0b" backgroundColor="#111827" zPosition="2" halign="center" transparent="1" />
        </screen>
        """
    else:
        return """
        <screen name="ArabseedListScreen" position="center,center" size="1200,660" title="قائمة الأفلام والمسلسلات" flags="wfNoBorder" backgroundColor="#0b0f19">
            <eLabel position="0,0" size="1200,70" backgroundColor="#111827" zPosition="1" />
            <widget name="title" position="35,16" size="1130,40" font="Regular;24" foregroundColor="#f59e0b" backgroundColor="#111827" zPosition="2" halign="right"/>
            <eLabel position="0,68" size="1200,2" backgroundColor="#f59e0b" zPosition="3" />

            <widget name="items" position="410,90" size="750,490" itemHeight="42" font="Regular;20" selectionColor="#1e293b" foregroundColor="#f8fafc" backgroundColor="#0b0f19" scrollbarMode="showOnDemand" transparent="1" />
            
            <widget name="poster" position="40,90" size="340,440" zPosition="2" alphatest="blend" />
            <widget name="details" position="40,540" size="340,45" font="Regular;16" foregroundColor="#94a3b8" backgroundColor="#0b0f19" transparent="1" halign="right"/>
            
            <eLabel position="0,580" size="1200,80" backgroundColor="#111827" zPosition="1" />
            <eLabel position="35,590" size="260,5" backgroundColor="#ef4444" zPosition="2" />
            <widget name="key_red" position="35,602" size="260,26" font="Regular;17" halign="center" transparent="1" zPosition="2" />
            <eLabel position="325,590" size="260,5" backgroundColor="#10b981" zPosition="2" />
            <widget name="key_green" position="325,602" size="260,26" font="Regular;17" halign="center" transparent="1" zPosition="2" />
            <eLabel position="615,590" size="260,5" backgroundColor="#f59e0b" zPosition="2" />
            <widget name="key_yellow" position="615,602" size="260,26" font="Regular;17" halign="center" transparent="1" zPosition="2" />
            <eLabel position="905,590" size="260,5" backgroundColor="#3b82f6" zPosition="2" />
            <widget name="key_blue" position="905,602" size="260,26" font="Regular;17" halign="center" transparent="1" zPosition="2" />

            <eLabel text="هذا البلجن متاح MohamedStore" position="50,632" size="1100,22" font="Regular;14" foregroundColor="#f59e0b" backgroundColor="#111827" zPosition="2" halign="center" transparent="1" />
        </screen>
        """

def get_player_skin():
    w, h, tier = get_resolution_info()
    if tier == "4k":
        return """
        <screen name="ArabseedPlayer" position="0,0" size="3840,2160" title="Arabseed Easy Player" flags="wfNoBorder" backgroundColor="transparent">
            <widget name="infobar" position="200,1880" size="3440,200" backgroundColor="#0b1120" zPosition="2" />
            <widget name="top_border" position="200,1880" size="3440,6" backgroundColor="#f59e0b" zPosition="3" />
            
            <widget name="title" position="250,1900" size="2400,60" font="Regular;42" foregroundColor="#f8fafc" backgroundColor="#0b1120" zPosition="4" halign="right" transparent="1" />
            <widget name="badge" position="2700,1900" size="900,60" font="Regular;36" foregroundColor="#f59e0b" backgroundColor="#0b1120" zPosition="4" halign="left" transparent="1" />
            
            <widget name="progress" position="250,1980" size="3340,14" backgroundColor="#1e293b" foregroundColor="#f59e0b" zPosition="4" />
            
            <widget name="time" position="250,2010" size="1400,50" font="Regular;34" foregroundColor="#94a3b8" backgroundColor="#0b1120" zPosition="4" halign="left" transparent="1" />
            <widget name="hint" position="1700,2010" size="1890,50" font="Regular;30" foregroundColor="#64748b" backgroundColor="#0b1120" zPosition="4" halign="right" transparent="1" />
        </screen>
        """
    elif tier == "fhd":
        return """
        <screen name="ArabseedPlayer" position="0,0" size="1920,1080" title="Arabseed Easy Player" flags="wfNoBorder" backgroundColor="transparent">
            <widget name="infobar" position="100,940" size="1720,105" backgroundColor="#0b1120" zPosition="2" />
            <widget name="top_border" position="100,940" size="1720,4" backgroundColor="#f59e0b" zPosition="3" />
            
            <widget name="title" position="130,950" size="1200,34" font="Regular;24" foregroundColor="#f8fafc" backgroundColor="#0b1120" zPosition="4" halign="right" transparent="1" />
            <widget name="badge" position="1350,950" size="440,34" font="Regular;20" foregroundColor="#f59e0b" backgroundColor="#0b1120" zPosition="4" halign="left" transparent="1" />
            
            <widget name="progress" position="130,992" size="1660,7" backgroundColor="#1e293b" foregroundColor="#f59e0b" zPosition="4" />
            
            <widget name="time" position="130,1008" size="700,26" font="Regular;19" foregroundColor="#94a3b8" backgroundColor="#0b1120" zPosition="4" halign="left" transparent="1" />
            <widget name="hint" position="850,1008" size="940,26" font="Regular;16" foregroundColor="#64748b" backgroundColor="#0b1120" zPosition="4" halign="right" transparent="1" />
        </screen>
        """
    else:
        return """
        <screen name="ArabseedPlayer" position="0,0" size="1280,720" title="Arabseed Easy Player" flags="wfNoBorder" backgroundColor="transparent">
            <widget name="infobar" position="50,620" size="1180,85" backgroundColor="#0b1120" zPosition="2" />
            <widget name="top_border" position="50,620" size="1180,3" backgroundColor="#f59e0b" zPosition="3" />
            
            <widget name="title" position="70,628" size="820,28" font="Regular;20" foregroundColor="#f8fafc" backgroundColor="#0b1120" zPosition="4" halign="right" transparent="1" />
            <widget name="badge" position="900,628" size="310,28" font="Regular;17" foregroundColor="#f59e0b" backgroundColor="#0b1120" zPosition="4" halign="left" transparent="1" />
            
            <widget name="progress" position="70,662" size="1140,5" backgroundColor="#1e293b" foregroundColor="#f59e0b" zPosition="4" />
            
            <widget name="time" position="70,674" size="500,22" font="Regular;16" foregroundColor="#94a3b8" backgroundColor="#0b1120" zPosition="4" halign="left" transparent="1" />
            <widget name="hint" position="590,674" size="620,22" font="Regular;13" foregroundColor="#64748b" backgroundColor="#0b1120" zPosition="4" halign="right" transparent="1" />
        </screen>
        """

def build_years_menu():
    """
    Build standalone years menu containing:
    1. Direct combined movies & series per year (2026, 2025, 2024...)
    2. Historical era filters
    3. Dedicated sub-browsers (Movies only / Series only)
    """
    years = [2026, 2025, 2024, 2023, 2022, 2021, 2020, 2019, 2018, 2017, 2016, 2015, 2014, 2013, 2012, 2011, 2010]
    menu = []

    # Combined movies + series for each year
    for y in years:
        menu.append(("🌟 أفلام ومسلسلات سنة %s" % y, "YEAR_ALL:%s" % y))

    # Eras & Decades
    menu.append(("أفلام وفترة 2005 - 2009", "YEAR_ALL:2005-2009"))
    menu.append(("أفلام وفترة 2000 - 2004", "YEAR_ALL:2000-2004"))
    menu.append(("أفلام التسعينات (1990 - 1999)", "YEAR_ALL:1990-1999"))
    menu.append(("أفلام الثمانينات (1980 - 1989)", "YEAR_ALL:1980-1989"))
    menu.append(("أفلام كلاسيكية (قبل 1980)", "YEAR_ALL:1970-1979"))

    # Dedicated filters for movies only and series only
    movies_only_submenu = []
    series_only_submenu = []
    for y in years:
        movies_only_submenu.append(("أفلام سنة %s فقط" % y, "YEAR_MOVIES:%s" % y))
        series_only_submenu.append(("مسلسلات سنة %s فقط" % y, "YEAR_SERIES:%s" % y))

    menu.append(("🎬 تصفح أفلام السنوات فقط »", movies_only_submenu))
    menu.append(("📺 تصفح مسلسلات السنوات فقط »", series_only_submenu))

    return menu

def build_root_menu():
    """
    Root menu structure for Arabseed with completely standalone Years section.
    """
    years_submenu = build_years_menu()

    movies_categories = [
        ("كل الأفلام", "/category/films/"),
        ("أفلام أجنبية", "/category/films/foreign-movies/"),
        ("أفلام تركية", "/category/films/turkish-movies/"),
        ("أفلام تركية مدبلجة", "/category/films/movies-turkish-dubbed/"),
        ("أفلام آسيوية", "/category/films/asian-movies/"),
        ("أفلام إسلام الجيزاوي", "/category/films/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%a7%d8%b3%d9%84%d8%a7%d9%85-%d8%a7%d9%84%d8%ac%d9%8a%d8%b2%d8%a7%d9%88%d9%8a/"),
        ("أفلام أنمي وكرتون", "/category/anime/anime-movies/")
    ]

    series_categories = [
        ("كل المسلسلات", "/category/tv/"),
        ("مسلسلات أجنبية", "/category/tv/foreign-series/"),
        ("مسلسلات آسيوية", "/category/tv/asian-series/"),
        ("مسلسلات لاتينية", "/category/tv/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa-%d9%84%d8%a7%d8%aa%d9%8a%d9%86%d9%8a%d8%a9/"),
        ("مسلسلات وثائقية", "/category/tv/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa-%d9%88%d8%ab%d8%a7%d8%a6%d9%82%d9%8a%d8%a9/"),
        ("مسلسلات أنمي وكرتون", "/category/anime/anime-series/")
    ]

    anime_categories = [
        ("كل الأنمي والكرتون", "/category/anime/"),
        ("مسلسلات أنمي", "/category/anime/anime-series/"),
        ("أفلام أنمي", "/category/anime/anime-movies/"),
        ("مسلسلات كرتون", "/category/anime/cartoon-series/"),
        ("أفلام كرتون", "/category/anime/cartoon-movies/"),
        ("كرتون ديزني بالمصري", "/category/anime/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d9%83%d8%b1%d8%aa%d9%88%d9%86-%d8%af%d9%8a%d8%b2%d9%86%d9%8a-%d8%a8%d8%a7%d9%84%d9%84%d9%87%d8%ac%d8%a9-%d8%a7%d9%84%d9%85%d8%b5%d8%b1%d9%8a%d8%a9/")
    ]

    return [
        ("أضيف حديثاً (الصفحة الرئيسية)", "/home/"),
        ("🔍 خانة البحث (البحث في عرب سيد)", "SEARCH"),
        ("الأفلام »", movies_categories),
        ("المسلسلات »", series_categories),
        ("📅 فترة السنوات (أفلام ومسلسلات حسب السنة) »", years_submenu),
        ("الأنمي والكرتون »", anime_categories),
        ("برامج تلفزيونية", "/category/tv-shows/"),
        ("رياضة ومصارعة", "/category/sport/"),
        ("تريند (الأكثر مشاهدة)", "/trend/")
    ]

class ArabseedMain(Screen):
    skin = get_main_skin()

    def __init__(self, session, menu_title=None, menu_items=None):
        self.skin = get_main_skin()
        Screen.__init__(self, session)
        self.session = session
        current_domain = config.plugins.arabseed.domain.value
        self.scraper = ArabseedScraper(current_domain)

        self.is_root = menu_items is None
        if menu_items is None:
            menu_items = build_root_menu()
        self.categories = menu_items

        header = menu_title if menu_title else "Arabseed - عرب سيد"
        self["title"] = Label(header)
        self["info"] = Label("اختر القسم واضغط OK للتصفح")
        self["key_red"] = Label("خروج" if self.is_root else "رجوع")
        self["key_green"] = Label("بحث")
        self["key_yellow"] = Label("إعدادات")
        self["key_blue"] = Label("فحص النطاق")

        self.menu_list = MenuList([cat[0] for cat in self.categories])
        self["menu"] = self.menu_list

        self["actions"] = ActionMap(["ColorActions", "OkCancelActions"], {
            "ok": self.itemSelected,
            "cancel": self.close,
            "red": self.close,
            "green": self.openSearch,
            "yellow": self.openSettings,
            "blue": self.refreshDomain
        }, -1)

    def itemSelected(self):
        idx = self["menu"].getSelectedIndex()
        if idx is not None and idx < len(self.categories):
            title, target = self.categories[idx]
            if target == "SEARCH":
                self.openSearch()
                return
            if isinstance(target, (list, tuple)) and target and isinstance(target[0], (list, tuple)):
                clean_title = title.replace(" »", "")
                self.session.open(ArabseedMain, clean_title, list(target))
            else:
                self.session.open(ArabseedListScreen, title, target)

    def openSearch(self):
        self.session.openWithCallback(self.performSearch, InputBox, title="أدخل اسم الفيلم أو المسلسل للبحث في عرب سيد:")

    def performSearch(self, query):
        if query and query.strip():
            search_url = "/search/" + quote(query.strip()) + "/"
            self.session.open(ArabseedListScreen, "نتائج البحث: " + query, search_url)

    def openSettings(self):
        self.session.openWithCallback(self.afterSettings, ArabseedSettingsScreen)

    def afterSettings(self):
        self.scraper = ArabseedScraper(config.plugins.arabseed.domain.value)
        self["info"].setText("النطاق النشط: " + config.plugins.arabseed.domain.value)
        if self.is_root:
            self.categories = build_root_menu()
            self.menu_list.setList([cat[0] for cat in self.categories])

    def refreshDomain(self):
        self["info"].setText("جاري فحص الاتصال بموقع عرب سيد...")
        def run_check():
            status, msg = self.scraper.check_connection()
            self.check_timer = eTimer()
            bind_timer(self.check_timer, lambda: self.onCheckComplete(status, msg))
            self.check_timer.start(10, True)

        threading.Thread(target=run_check).start()

    def onCheckComplete(self, status, msg):
        if status:
            self["info"].setText("الموقع يعمل: " + str(config.plugins.arabseed.domain.value))
            self.session.open(MessageBox, "تم الاتصال بنجاح بموقع عرب سيد", MessageBox.TYPE_INFO, timeout=4)
        else:
            self["info"].setText("تعذر الاتصال، يرجى تغيير النطاق")
            self.session.open(MessageBox, "فشل الاتصال بموقع عرب سيد: " + str(msg), MessageBox.TYPE_ERROR)

class ArabseedListScreen(Screen):
    skin = get_list_skin()

    def __init__(self, session, cat_title, cat_url):
        self.skin = get_list_skin()
        Screen.__init__(self, session)
        self.session = session
        self.cat_title = cat_title
        self.cat_url = cat_url
        self.page = 1
        self.scraper = ArabseedScraper(config.plugins.arabseed.domain.value)
        self.items_data = []
        self.current_poster_path = ""
        self.is_loading = False
        self.is_closing = False
        self.picload = None

        self["title"] = Label(cat_title)
        self["details"] = Label("جاري جلب القائمة من السيرفر...")
        self["poster"] = Pixmap()
        self["key_red"] = Label("رجوع")
        self["key_green"] = Label("الصفحة التالية (P+)")
        self["key_yellow"] = Label("الصفحة السابقة (P-)")
        self["key_blue"] = Label("إعدادات")

        self.list_widget = MenuList([])
        self["items"] = self.list_widget

        self.initPicload()

        self.poster_timer = eTimer()
        bind_timer(self.poster_timer, self.fetchCurrentPoster)

        self.list_widget.onSelectionChanged.append(self.onSelectionChangedDebounced)

        self["actions"] = ActionMap(["ColorActions", "OkCancelActions", "DirectionActions", "HelpActions"], {
            "ok": self.itemSelected,
            "cancel": self.exitScreen,
            "red": self.exitScreen,
            "green": self.nextPage,
            "yellow": self.prevPage,
            "blue": self.openSettings,
            "pageUp": self.nextPage,
            "pageDown": self.prevPage,
            "displayHelp": self.openSearch
        }, -1)

        self.onClose.append(self.onCloseScreen)
        self.onLayoutFinish.append(self.loadDataAsync)

    def initPicload(self):
        if getattr(self, "picload", None) is None:
            try:
                self.picload = ePicLoad()
                connected = False
                try:
                    self.picload_conn = self.picload.PictureData.connect(self.paintPosterPixmapCB)
                    connected = True
                except Exception:
                    pass
                if not connected:
                    try:
                        self.picload.PictureData.get().append(self.paintPosterPixmapCB)
                        connected = True
                    except Exception:
                        pass
            except Exception as e:
                log_debug("ePicLoad init error: " + str(e))
                self.picload = None

    def onCloseScreen(self):
        self.is_closing = True
        try:
            self.poster_timer.stop()
        except Exception:
            pass
        if getattr(self, "picload", None):
            try:
                del self.picload
            except Exception:
                pass
            self.picload = None

    def exitScreen(self):
        self.close()

    def loadDataAsync(self):
        if self.is_loading or self.is_closing:
            return
        self.is_loading = True
        self["details"].setText("جاري التحميل في الخلفية... يرجى الانتظار")

        def worker():
            items = self.scraper.get_items(self.cat_url, self.page)
            if self.is_closing:
                return
            self.ui_timer = eTimer()
            bind_timer(self.ui_timer, lambda: self.onDataLoaded(items))
            self.ui_timer.start(10, True)

        threading.Thread(target=worker).start()

    def onDataLoaded(self, items):
        if self.is_closing:
            return
        self.is_loading = False
        self.items_data = items
        display_list = [item["title"] for item in self.items_data]
        self.list_widget.setList(display_list)

        if self.items_data:
            self["title"].setText(self.cat_title + " - صفحة " + str(self.page) + " (" + str(len(self.items_data)) + " عنصر)")
            self.onSelectionChangedDebounced()
        else:
            self["details"].setText("لم يتم العثور على محتوى في هذا القسم.")

    def onSelectionChangedDebounced(self):
        if self.is_closing:
            return
        idx = self.list_widget.getSelectedIndex()
        if idx is not None and idx < len(self.items_data):
            item = self.items_data[idx]
            info_text = "السنة: %s | الجودة: %s | النوع: %s" % (
                item.get("year", "2024"),
                item.get("quality", "HD"),
                "مسلسل / برنامج" if item.get("is_series", False) else "فيلم"
            )
            self["details"].setText(info_text)
            self.poster_timer.stop()
            self.poster_timer.start(250, True)

    def fetchCurrentPoster(self):
        if self.is_closing:
            return
        idx = self.list_widget.getSelectedIndex()
        if idx is not None and idx < len(self.items_data):
            poster_url = self.items_data[idx].get("poster", "")
            if not poster_url or not poster_url.startswith("http"):
                if "poster" in self and self["poster"].instance:
                    try:
                        self["poster"].instance.setPixmap(None)
                    except Exception:
                        pass
                return

            safe_name = hashlib.md5(poster_url.encode("utf-8", "ignore")).hexdigest()
            local_path = os.path.join(CACHE_DIR, safe_name + ".jpg")

            if is_valid_jpg_or_png_file(local_path):
                self.showPoster(local_path)
                return

            def dl():
                try:
                    headers = {
                        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                        "Referer": self.scraper.domain_root + "/home/"
                    }
                    encoded_url = safe_url(poster_url)
                    req = urllib2.Request(encoded_url, headers=headers)
                    resp = urllib2.urlopen(req, timeout=8, context=ssl_context) if ssl_context else urllib2.urlopen(req, timeout=8)
                    data = resp.read()
                    if convert_and_save_image(data, local_path):
                        if not self.is_closing:
                            self.show_timer = eTimer()
                            bind_timer(self.show_timer, lambda: self.showPoster(local_path))
                            self.show_timer.start(10, True)
                except Exception as e:
                    log_debug("Poster error: " + str(e))

            threading.Thread(target=dl).start()

    def showPoster(self, path):
        if self.is_closing or not is_valid_jpg_or_png_file(path):
            return

        self.current_poster_path = path
        w, h, tier = get_resolution_info()
        p_w, p_h = (720, 950) if tier == "4k" else ((460, 600) if tier == "fhd" else (340, 440))

        self.initPicload()
        if getattr(self, "picload", None):
            try:
                self.picload.setPara((p_w, p_h, 1, 1, False, 1, "#0b0f19"))
                self.picload.startDecode(path)
            except Exception:
                pass

        if LoadPixmap and ("poster" in self and self["poster"].instance):
            try:
                pix = LoadPixmap(path)
                if pix:
                    self["poster"].instance.setPixmap(pix)
                    self["poster"].show()
            except Exception:
                pass

    def paintPosterPixmapCB(self, *args, **kwargs):
        if self.is_closing or not getattr(self, "picload", None):
            return
        try:
            ptr = self.picload.getData()
            if ptr and "poster" in self and self["poster"].instance:
                self["poster"].instance.setPixmap(ptr)
                self["poster"].show()
        except Exception:
            pass

    def itemSelected(self):
        idx = self.list_widget.getSelectedIndex()
        if idx is not None and idx < len(self.items_data):
            item = self.items_data[idx]
            if item.get("is_series", False):
                self.session.open(ArabseedEpisodesScreen, item)
            else:
                self.session.open(ArabseedServersScreen, item)

    def nextPage(self):
        if not self.is_loading:
            self.page += 1
            self.loadDataAsync()

    def prevPage(self):
        if not self.is_loading and self.page > 1:
            self.page -= 1
            self.loadDataAsync()

    def openSearch(self):
        self.session.openWithCallback(self.performSearch, InputBox, title="أدخل اسم الفيلم أو المسلسل للبحث في عرب سيد:")

    def performSearch(self, query):
        if query and query.strip():
            search_url = "/search/" + quote(query.strip()) + "/"
            self.session.open(ArabseedListScreen, "نتائج البحث: " + query, search_url)

    def openSettings(self):
        self.session.openWithCallback(self.afterSettings, ArabseedSettingsScreen)

    def afterSettings(self):
        self.scraper = ArabseedScraper(config.plugins.arabseed.domain.value)
        self.page = 1
        self.loadDataAsync()

class ArabseedEpisodesScreen(Screen):
    skin = """
    <screen name="ArabseedEpisodesScreen" position="center,center" size="1400,820" title="قائمة الحلقات" flags="wfNoBorder" backgroundColor="#0b0f19">
        <eLabel position="0,0" size="1400,90" backgroundColor="#111827" zPosition="1" />
        <widget name="title" position="40,20" size="1320,50" font="Regular;30" foregroundColor="#f59e0b" backgroundColor="#111827" zPosition="2" halign="right"/>
        <eLabel position="0,87" size="1400,3" backgroundColor="#f59e0b" zPosition="3" />
        <widget name="episodes" position="40,110" size="1320,600" font="Regular;26" itemHeight="52" selectionColor="#1e293b" foregroundColor="#f8fafc" backgroundColor="#0b0f19" scrollbarMode="showOnDemand" transparent="1" />
        <eLabel position="0,730" size="1400,90" backgroundColor="#111827" zPosition="1" />
        <eLabel position="40,745" size="250,6" backgroundColor="#ef4444" zPosition="2" />
        <widget name="key_red" position="40,760" size="250,40" font="Regular;22" halign="center" transparent="1" zPosition="2" />
        <eLabel text="هذا البلجن متاح MohamedStore" position="320,760" size="1040,35" font="Regular;20" foregroundColor="#f59e0b" backgroundColor="#111827" zPosition="2" halign="center" transparent="1" />
    </screen>
    """

    def __init__(self, session, series_item):
        Screen.__init__(self, session)
        self.session = session
        self.series_item = series_item
        self.scraper = ArabseedScraper(config.plugins.arabseed.domain.value)

        self["title"] = Label("حلقات: " + series_item.get("title", ""))
        self["key_red"] = Label("رجوع")
        self.episodes_list = []
        self.menu_list = MenuList([])
        self["episodes"] = self.menu_list

        self["actions"] = ActionMap(["ColorActions", "OkCancelActions"], {
            "ok": self.episodeSelected,
            "cancel": self.close,
            "red": self.close
        }, -1)

        self.onLayoutFinish.append(self.loadEpisodesAsync)

    def loadEpisodesAsync(self):
        def worker():
            eps = self.scraper.get_episodes(self.series_item.get("url", ""))
            self.timer = eTimer()
            bind_timer(self.timer, lambda: self.onEpisodesLoaded(eps))
            self.timer.start(10, True)

        threading.Thread(target=worker).start()

    def onEpisodesLoaded(self, eps):
        self.episodes_list = eps
        if self.episodes_list:
            display = [ep["title"] for ep in self.episodes_list]
            self.menu_list.setList(display)
        else:
            self.session.open(ArabseedServersScreen, self.series_item)
            self.close()

    def episodeSelected(self):
        idx = self.menu_list.getSelectedIndex()
        if idx is not None and idx < len(self.episodes_list):
            ep = self.episodes_list[idx]
            self.session.open(ArabseedServersScreen, ep)

class ArabseedServersScreen(Screen):
    skin = """
    <screen name="ArabseedServersScreen" position="center,center" size="1300,750" title="اختر سيرفر المشاهدة" flags="wfNoBorder" backgroundColor="#0b0f19">
        <eLabel position="0,0" size="1300,90" backgroundColor="#111827" zPosition="1" />
        <widget name="title" position="40,20" size="1220,50" font="Regular;30" foregroundColor="#10b981" backgroundColor="#111827" zPosition="2" halign="right"/>
        <eLabel position="0,87" size="1300,3" backgroundColor="#10b981" zPosition="3" />
        <widget name="servers" position="40,110" size="1220,520" font="Regular;26" itemHeight="52" selectionColor="#1e293b" foregroundColor="#f8fafc" backgroundColor="#0b0f19" scrollbarMode="showOnDemand" transparent="1" />
        <widget name="status" position="350,670" size="910,50" font="Regular;22" foregroundColor="#94a3b8" backgroundColor="#0b0f19" transparent="1" halign="right"/>
        <eLabel position="40,660" size="250,6" backgroundColor="#ef4444" zPosition="2" />
        <widget name="key_red" position="40,675" size="250,40" font="Regular;22" halign="center" transparent="1" zPosition="2" />
        <eLabel text="هذا البلجن متاح MohamedStore" position="320,675" size="940,35" font="Regular;20" foregroundColor="#f59e0b" backgroundColor="#111827" zPosition="2" halign="center" transparent="1" />
    </screen>
    """

    def __init__(self, session, media_item):
        Screen.__init__(self, session)
        self.session = session
        self.media_item = media_item
        self.scraper = ArabseedScraper(config.plugins.arabseed.domain.value)

        self["title"] = Label("سيرفرات: " + media_item.get("title", ""))
        self["status"] = Label("اختر السيرفر واضغط OK للمشاهدة المباشرة")
        self["key_red"] = Label("رجوع")
        self.servers_data = []
        self.menu_list = MenuList([])
        self["servers"] = self.menu_list
        self.is_resolving = False

        self["actions"] = ActionMap(["ColorActions", "OkCancelActions"], {
            "ok": self.playSelected,
            "cancel": self.close,
            "red": self.close
        }, -1)

        self.onLayoutFinish.append(self.loadServersAsync)

    def loadServersAsync(self):
        self["status"].setText("جاري استخراج سيرفرات المشاهدة والتحميل...")
        def worker():
            servers = self.scraper.get_servers(self.media_item.get("url", ""))
            self.t = eTimer()
            bind_timer(self.t, lambda: self.onServersLoaded(servers))
            self.t.start(10, True)

        threading.Thread(target=worker).start()

    def onServersLoaded(self, servers):
        self.servers_data = servers
        display = [s.get("name", "سيرفر") + " [" + s.get("quality", "Auto") + "]" for s in self.servers_data]
        self.menu_list.setList(display)
        if self.servers_data:
            self["status"].setText("تم العثور على %d سيرفر. اضغط OK للتشغيل المباشر." % len(self.servers_data))
        else:
            self["status"].setText("لم يتم العثور على سيرفرات مباشرة لهذا الرابط.")

    def playSelected(self):
        if self.is_resolving:
            return
        idx = self.menu_list.getSelectedIndex()
        if idx is not None and idx < len(self.servers_data):
            server = self.servers_data[idx]
            self.is_resolving = True
            self["status"].setText("جاري استخراج رابط البث وتشغيله فوراً...")

            def resolve_and_play():
                direct_url, referer = self.scraper.resolve_stream_url(server.get("url", ""))
                self.res_timer = eTimer()
                bind_timer(self.res_timer, lambda: self.onStreamReady(direct_url, referer))
                self.res_timer.start(10, True)

            threading.Thread(target=resolve_and_play).start()

    def onStreamReady(self, direct_url, referer=""):
        self.is_resolving = False
        is_valid_stream = bool(
            direct_url and direct_url.startswith("http") and
            any(ext in direct_url.lower() for ext in [".m3u8", ".mp4", ".mkv", ".ts", "urlset", "master", "playlist", "video"]) and
            not any(bad in direct_url.lower() for bad in ["/iframe/", ".html", ".htm", "/download/"])
        )
        if is_valid_stream:
            self["status"].setText("جاري تشغيل البث المباشر الآن...")
            self.session.open(ArabseedPlayer, direct_url, self.media_item.get("title", "Arabseed Stream"), referer)
        else:
            self["status"].setText("تعذر استخراج البث، اختر سيرفراً آخر من القائمة")
            self.session.open(MessageBox, "تعذر استخراج رابط الفيديو المباشر من هذا السيرفر.\nيرجى اختيار سيرفر آخر من القائمة (مثل VidMoly أو Uqload أو StreamRuby).", MessageBox.TYPE_WARNING, timeout=5)

class ArabseedPlayer(Screen):
    def __init__(self, session, stream_url, title, referer=""):
        self.skin = get_player_skin()
        Screen.__init__(self, session)
        self.session = session
        self.video_title = title or "Arabseed Stream"
        self.referer = referer or "https://www.arabseed.wine/"
        self.stream_url = stream_url

        self.clean_url = prepare_stream_url_with_headers(self.stream_url, self.referer)

        self["title"] = Label(self.video_title)
        self["badge"] = Label("جاري البدء...")
        self["progress"] = ProgressBar()
        self["time"] = Label("00:00 / 00:00")
        self["hint"] = Label("OK: إظهار/إخفاء | ◄►: تقديم وتأخير | EXIT: خروج | BLUE: انتقال لدقيقة")
        self["infobar"] = Label()
        self["top_border"] = Label()

        self.is_paused = False
        self.is_osd_visible = False
        self.playback_started = False
        self.total_length_sec = 0
        self.stall_counter = 0
        self.retry_fallback_done = False
        self.stream_playing_verified = False

        self.service_type = 4097
        try:
            cfg_player = int(config.plugins.arabseed.player.value)
            if cfg_player == 5002 and (os.path.exists("/usr/bin/exteplayer3") or os.path.exists("/bin/exteplayer3")):
                self.service_type = 5002
            elif cfg_player in (4097, 5001):
                self.service_type = cfg_player
        except Exception:
            self.service_type = 4097

        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions", "NumberActions", "MoviePlayerActions", "InfobarSeekActions"], {
            "cancel": self.exitPlayer,
            "back": self.exitPlayer,
            "red": self.exitPlayer,
            "stop": self.exitPlayer,
            "leavePlayer": self.exitPlayer,

            "ok": self.toggleInfo,
            "info": self.toggleInfo,

            "yellow": self.togglePlayPause,
            "play": self.resumeStream,
            "pause": self.pauseStream,
            "playpause": self.togglePlayPause,
            "pauseService": self.pauseStream,
            "unPauseService": self.resumeStream,

            "left": lambda: self.seekRelativeSeconds(-10),
            "right": lambda: self.seekRelativeSeconds(10),
            "up": lambda: self.seekRelativeSeconds(60),
            "down": lambda: self.seekRelativeSeconds(-60),
            "seekBack": lambda: self.seekRelativeSeconds(-10),
            "seekFwd": lambda: self.seekRelativeSeconds(10),

            "0": lambda: None,
            "1": lambda: self.seekRelativeSeconds(-10),
            "2": lambda: None,
            "3": lambda: self.seekRelativeSeconds(10),
            "4": lambda: self.seekRelativeSeconds(-60),
            "5": lambda: None,
            "6": lambda: self.seekRelativeSeconds(60),
            "7": lambda: self.seekRelativeSeconds(-300),
            "8": lambda: None,
            "9": lambda: self.seekRelativeSeconds(300),

            "blue": self.askJumpToMinute,
        }, -100)

        self.suppressSystemPVRDialogs()
        self.session.nav.event.append(self.__serviceEvent)
        self.onLayoutFinish.append(self.triggerPlaybackStart)
        self.onClose.append(self.cleanup)

        self.hide_timer = eTimer()
        bind_timer(self.hide_timer, self.hideOSD, self, "hide_timer_conn")

        self.pos_timer = eTimer()
        bind_timer(self.pos_timer, self.updatePosition, self, "pos_timer_conn")

    def suppressSystemPVRDialogs(self):
        try:
            from Screens.InfoBar import InfoBar
            if InfoBar and InfoBar.instance:
                ib = InfoBar.instance
                if hasattr(ib, "pvrStateDialog") and ib.pvrStateDialog:
                    try:
                        ib.pvrStateDialog.hide()
                        if not hasattr(self, "_orig_pvr_show"):
                            self._orig_pvr_show = ib.pvrStateDialog.show
                            ib.pvrStateDialog.show = lambda *a, **kw: None
                    except Exception:
                        pass
                if hasattr(ib, "timeshiftStateDialog") and ib.timeshiftStateDialog:
                    try:
                        ib.timeshiftStateDialog.hide()
                        if not hasattr(self, "_orig_ts_show"):
                            self._orig_ts_show = ib.timeshiftStateDialog.show
                            ib.timeshiftStateDialog.show = lambda *a, **kw: None
                    except Exception:
                        pass
                if hasattr(ib, "pts_pvrState") and ib.pts_pvrState:
                    try:
                        ib.pts_pvrState.hide()
                    except Exception:
                        pass
                if hasattr(ib, "hide"):
                    ib.hide()
        except Exception:
            pass

    def restoreSystemPVRDialogs(self):
        try:
            from Screens.InfoBar import InfoBar
            if InfoBar and InfoBar.instance:
                ib = InfoBar.instance
                if hasattr(self, "_orig_pvr_show") and hasattr(ib, "pvrStateDialog") and ib.pvrStateDialog:
                    ib.pvrStateDialog.show = self._orig_pvr_show
                if hasattr(self, "_orig_ts_show") and hasattr(ib, "timeshiftStateDialog") and ib.timeshiftStateDialog:
                    ib.timeshiftStateDialog.show = self._orig_ts_show
        except Exception:
            pass

    def __serviceEvent(self, event):
        if event == iPlayableService.evEOF:
            log_debug("Playback EOF detected. Exiting player...")
            self.exitPlayer()

    def cleanup(self):
        self.restoreSystemPVRDialogs()
        try:
            if self.__serviceEvent in self.session.nav.event:
                self.session.nav.event.remove(self.__serviceEvent)
        except Exception:
            pass
        try:
            self.pos_timer.stop()
        except Exception:
            pass
        try:
            self.hide_timer.stop()
        except Exception:
            pass

    def triggerPlaybackStart(self):
        if self.playback_started:
            return
        self.playback_started = True
        self.startPlayback()

    def startPlayback(self):
        try:
            self.session.nav.stopService()
        except Exception:
            pass

        self.stall_counter = 0
        self.retry_fallback_done = False
        self.stream_playing_verified = False

        try:
            log_debug("Starting ArabseedPlayer with sref: " + str(self.clean_url) + " [Service: %d]" % self.service_type)
            sref = eServiceReference(self.service_type, 0, self.clean_url)
            sref.setName(self.video_title)
            self.session.nav.playService(sref)
            self.suppressSystemPVRDialogs()
            self.pos_timer.start(1000, False)
            self.showOSD("▶ جاري الاتصال بالسيرفر وبدء البث...", 4000)
        except Exception as e:
            log_debug("Player start error: " + str(e))
            self.session.openWithCallback(self.close, MessageBox, "حدث خطأ أثناء تشغيل البث:\n" + str(e), MessageBox.TYPE_ERROR)

    def togglePlayPause(self):
        try:
            service = self.session.nav.getCurrentService()
            pauseable = service and service.pause()
            if pauseable:
                if self.is_paused:
                    pauseable.unpause()
                    self.is_paused = False
                    self.showOSD("استئناف ▶", 2500)
                else:
                    pauseable.pause()
                    self.is_paused = True
                    self.showOSD("إيقاف مؤقت ❚❚", 0)
        except Exception as e:
            log_debug("togglePlayPause error: " + str(e))

    def pauseStream(self):
        if not self.is_paused:
            self.togglePlayPause()

    def resumeStream(self):
        if self.is_paused:
            self.togglePlayPause()

    def seekRelativeSeconds(self, seconds):
        try:
            service = self.session.nav.getCurrentService()
            seek = service and service.seek()
            if not seek:
                return

            pos_res = seek.getPlayPosition()
            len_res = seek.getLength()

            cur_pts = pos_res[1] if (pos_res and pos_res[0] == 0) else 0
            total_pts = len_res[1] if (len_res and len_res[0] == 0) else 0

            delta_pts = int(seconds * 90000)
            target_pts = cur_pts + delta_pts

            if target_pts < 10 * 90000:
                target_pts = 10 * 90000

            if total_pts > 0 and target_pts > (total_pts - 15 * 90000):
                target_pts = max(10 * 90000, total_pts - 15 * 90000)

            seek.seekTo(target_pts)
            self.suppressSystemPVRDialogs()

            if abs(seconds) >= 60:
                mins = abs(seconds) // 60
                badge_text = ("+%d دقيقة ⏩" % mins) if seconds > 0 else ("-%d دقيقة ⏪" % mins)
            else:
                badge_text = ("+%d ثانية ⏩" % seconds) if seconds > 0 else ("-%d ثانية ⏪" % abs(seconds))

            self.showOSD(badge_text, 1800)
        except Exception as e:
            log_debug("seekRelativeSeconds error: " + str(e))

    def askJumpToMinute(self):
        self.session.openWithCallback(self.onMinuteEntered, InputBox, title="أدخل الدقيقة التي تريد القفز إليها مباشرة (مثلاً 45):", windowTitle="انتقال سريع للوقت")

    def onMinuteEntered(self, val):
        if not val:
            return
        try:
            digits = re.sub(r'\D', '', str(val))
            if not digits:
                return
            minute = int(digits)
            sec = minute * 60
            service = self.session.nav.getCurrentService()
            if not service:
                return
            seek = service.seek()
            if not seek:
                return
            target_pts = int(sec * 90000)
            len_res = seek.getLength()
            if len_res and len_res[0] == 0 and len_res[1] > 0:
                if target_pts > len_res[1]:
                    target_pts = max(0, len_res[1] - 15 * 90000)
            seek.seekTo(target_pts)
            self.showOSD("انتقال للدقيقة %d ⏱" % minute, 3000)
        except Exception as e:
            log_debug("onMinuteEntered error: " + str(e))

    def updatePosition(self):
        self.suppressSystemPVRDialogs()
        try:
            service = self.session.nav.getCurrentService()
            seek = service and service.seek()
            if seek:
                pos_res = seek.getPlayPosition()
                len_res = seek.getLength()

                current_sec = 0
                if pos_res and pos_res[0] == 0:
                    current_sec = pos_res[1] // 90000

                total_sec = 0
                if len_res and len_res[0] == 0 and len_res[1] > 0:
                    total_sec = len_res[1] // 90000
                    self.total_length_sec = total_sec

                if current_sec > 0 or total_sec > 0:
                    if not self.stream_playing_verified:
                        self.stream_playing_verified = True
                        if self.is_osd_visible:
                            self["badge"].setText("▶ جاري التشغيل")
                            self["badge"].show()
                else:
                    self.stall_counter += 1
                    if self.stall_counter == 3:
                        if self.is_osd_visible:
                            self["badge"].setText("جاري تحميل البث...")
                            self["badge"].show()
                    elif self.stall_counter >= 10 and not self.stream_playing_verified:
                        self.showOSD("⚠️ تعذر استجابة السيرفر - اضغط EXIT لاختيار سيرفر آخر", 0)

                if self.is_osd_visible:
                    if total_sec > 0:
                        percent = int((float(current_sec) / float(total_sec)) * 100)
                        self["progress"].setValue(percent)
                        rem_sec = max(0, total_sec - current_sec)
                        time_str = "%s / %s (متبقي: -%s)" % (
                            format_time_hms(current_sec),
                            format_time_hms(total_sec),
                            format_time_hms(rem_sec)
                        )
                        self["time"].setText(time_str)
                    else:
                        self["time"].setText("%s" % format_time_hms(current_sec))
        except Exception as e:
            log_debug("updatePosition error: " + str(e))

    def showOSD(self, badge_text="", timeout=2500):
        self.is_osd_visible = True
        self["infobar"].show()
        self["top_border"].show()
        self["title"].show()
        self["time"].show()
        self["progress"].show()
        self["hint"].show()

        if badge_text:
            self["badge"].setText(badge_text)
            self["badge"].show()
        else:
            self["badge"].hide()

        self.updatePosition()
        self.hide_timer.stop()
        if timeout > 0 and not self.is_paused:
            self.hide_timer.start(timeout, True)

    def hideOSD(self):
        if self.is_paused:
            return
        self.is_osd_visible = False
        self["infobar"].hide()
        self["top_border"].hide()
        self["title"].hide()
        self["time"].hide()
        self["progress"].hide()
        self["hint"].hide()
        self["badge"].hide()

    def toggleInfo(self):
        if self.is_osd_visible:
            self.hideOSD()
        else:
            self.showOSD("▶ جاري البث" if not self.is_paused else "❚❚ متوقف مؤقتاً", 2500)

    def exitPlayer(self):
        try:
            self.pos_timer.stop()
            self.hide_timer.stop()
            self.session.nav.stopService()
        except Exception:
            pass
        self.close()

class ArabseedSettingsScreen(ConfigListScreen, Screen):
    skin = """
    <screen name="ArabseedSettingsScreen" position="center,center" size="1200,600" title="إعدادات عرب سيد" flags="wfNoBorder" backgroundColor="#0b0f19">
        <eLabel position="0,0" size="1200,90" backgroundColor="#111827" zPosition="1" />
        <widget name="title" position="40,20" size="1120,50" font="Regular;30" foregroundColor="#f59e0b" backgroundColor="#111827" zPosition="2" halign="right" />
        <eLabel position="0,87" size="1200,3" backgroundColor="#f59e0b" zPosition="3" />
        <widget name="config" position="50,125" size="1100,340" itemHeight="55" font="Regular;24" scrollbarMode="showOnDemand" transparent="1" />
        <eLabel position="0,490" size="1200,110" backgroundColor="#111827" zPosition="1" />
        <eLabel position="50,510" size="280,6" backgroundColor="#10b981" zPosition="2" />
        <widget name="key_green" position="50,525" size="280,40" font="Regular;22" halign="center" transparent="1" zPosition="2" />
        <eLabel position="380,510" size="280,6" backgroundColor="#ef4444" zPosition="2" />
        <widget name="key_red" position="380,525" size="280,40" font="Regular;22" halign="center" transparent="1" zPosition="2" />
        <eLabel text="هذا البلجن متاح MohamedStore" position="700,525" size="450,40" font="Regular;20" foregroundColor="#f59e0b" backgroundColor="#111827" zPosition="2" halign="center" transparent="1" />
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.list = [
            getConfigListEntry("رابط نطاق موقع عرب سيد (Mirror):", config.plugins.arabseed.domain),
            getConfigListEntry("نوع مشغل الفيديو الافتراضي:", config.plugins.arabseed.player)
        ]
        ConfigListScreen.__init__(self, self.list)
        self["title"] = Label("إعدادات بلجن عرب سيد")
        self["key_green"] = Label("حفظ الإعدادات")
        self["key_red"] = Label("إلغاء")
        self["actions"] = ActionMap(["ColorActions", "OkCancelActions"], {
            "green": self.save,
            "red": self.cancel,
            "cancel": self.cancel
        }, -1)

    def save(self):
        for x in self["config"].list:
            x[1].save()
        self.close()

    def cancel(self):
        for x in self["config"].list:
            x[1].cancel()
        self.close()

def main(session, **kwargs):
    session.open(ArabseedMain)

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="Arabseed",
            description="مشاهدة الأفلام والمسلسلات من موقع عرب سيد (https://www.arabseed.wine/home/)",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="icon.png",
            fnc=main
        ),
        PluginDescriptor(
            name="Arabseed",
            description="عرب سيد Enigma2",
            where=PluginDescriptor.WHERE_EXTENSIONSMENU,
            fnc=main
        )
    ]
