# -*- coding: utf-8 -*-
"""
===================================================================
 Arabseed Scraper Engine (arabseed_scraper.py)
 Dedicated Scraper for https://www.arabseed.wine/
 Fully isolated module to eliminate any Enigma2 namespace collisions
 Compatible with Python 2 & Python 3 (EGAMI, OpenATV, OpenPLi, DreamOS)
===================================================================
"""

import sys
import os
import re
import zlib
import gzip
import json
import time

PY3 = sys.version_info[0] == 3

if PY3:
    import urllib.request as urllib2
    from urllib.parse import urljoin, quote, unquote, urlparse, urlencode
    from io import BytesIO
    import http.cookiejar as cookielib
else:
    import urllib2
    from urlparse import urljoin, urlparse
    from urllib import quote, unquote, urlencode
    from StringIO import StringIO as BytesIO
    import cookielib

ssl_context = None
try:
    import ssl
    ssl_context = ssl._create_unverified_context()
except Exception:
    ssl_context = None

def log_debug(msg):
    try:
        with open("/tmp/arabseed.log", "a") as f:
            f.write("[Scraper] " + str(msg) + "\n")
    except Exception:
        pass
    print("[ArabseedScraper] " + str(msg))

def safe_url(url):
    if not url:
        return ""
    if PY3:
        import urllib.parse
        return urllib.parse.quote(str(url), safe=":/%?&=+#@!$,;'*()")
    else:
        import urllib
        try:
            if isinstance(url, unicode):
                url = url.encode("utf-8")
        except NameError:
            pass
        return urllib.quote(str(url), safe=":/%?&=+#@!$,;'*()")

def clean_arabic_title(raw_text):
    if not raw_text:
        return ""
    t = re.sub(r'<[^>]+>', ' ', raw_text)
    t = re.sub(r'[\r\n\t]+', ' ', t)
    t = re.sub(r'\s{2,}', ' ', t)
    return t.strip()

def extract_image_src(inner_html, base_url):
    if not inner_html:
        return ""
    for attr in ['data-src', 'data-original', 'data-lazy-src', 'data-image', 'data-img']:
        matches = re.findall(r'%s=["\']([^"\']+)["\']' % attr, inner_html, re.IGNORECASE)
        for m in matches:
            m = m.strip()
            if m and not m.startswith("data:image") and not m.endswith(".svg") and "no-image" not in m.lower():
                if m.startswith("//"):
                    return "https:" + m
                elif not m.startswith("http"):
                    return urljoin(base_url, m)
                return m
    m = re.search(r'<img[^>]+src=["\']([^"\']+)["\']', inner_html, re.IGNORECASE)
    if m:
        val = m.group(1).strip()
        if val and not val.startswith("data:image") and not val.endswith(".svg"):
            if val.startswith("//"):
                return "https:" + val
            elif not val.startswith("http"):
                return urljoin(base_url, val)
            return val
    return ""


class ArabseedScraper(object):
    def __init__(self, base_url="https://www.arabseed.wine/home/"):
        raw_url = (base_url or "https://www.arabseed.wine/home/").strip()
        if not raw_url.startswith("http"):
            raw_url = "https://" + raw_url
        self.raw_input_url = raw_url

        parsed = urlparse(raw_url)
        self.domain_root = "%s://%s" % (parsed.scheme, parsed.netloc)
        self.base_url = raw_url.rstrip("/")

        self.last_error = ""
        self.memory_cache = {}
        self.cj = cookielib.CookieJar()
        if ssl_context:
            self.opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(self.cj), urllib2.HTTPSHandler(context=ssl_context))
        else:
            self.opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(self.cj))

        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
            "Accept-Language": "ar,en-US;q=0.9,en;q=0.8",
            "Accept-Encoding": "gzip, deflate",
            "Connection": "keep-alive"
        }

    def build_full_url(self, path):
        if not path:
            return self.domain_root + "/home/"
        if path.startswith("http://") or path.startswith("https://"):
            return path
        if not path.startswith("/"):
            path = "/" + path
        return self.domain_root + path

    def fetch_html(self, url, use_cache=True, custom_headers=None):
        target_url = self.build_full_url(url)
        target_url = safe_url(target_url)

        if use_cache and target_url in self.memory_cache:
            return self.memory_cache[target_url]

        log_debug("Fetching URL: " + target_url)
        self.last_error = ""
        req_headers = dict(self.headers)
        req_headers["Referer"] = self.domain_root + "/home/"
        if custom_headers:
            req_headers.update(custom_headers)

        # 1. Try requests if installed on the box
        try:
            import requests
            r = requests.get(target_url, headers=req_headers, verify=False, timeout=10)
            text = r.text
            if "Just a moment..." in text or "challenge-platform" in text:
                self.last_error = "CLOUDFLARE_BLOCKED"
                return ""
            if use_cache:
                self.memory_cache[target_url] = text
            return text
        except ImportError:
            pass
        except Exception as e:
            log_debug("Requests fallback: " + str(e))

        # 2. Standard urllib fallback
        try:
            req = urllib2.Request(target_url, headers=req_headers)
            res = self.opener.open(req, timeout=10)

            raw_data = res.read()
            encoding = res.headers.get("Content-Encoding", "").lower() if hasattr(res, "headers") else ""
            if encoding == "gzip" or raw_data[:2] == b"\x1f\x8b":
                try:
                    raw_data = gzip.GzipFile(fileobj=BytesIO(raw_data)).read()
                except Exception:
                    pass
            elif encoding == "deflate":
                try:
                    raw_data = zlib.decompress(raw_data)
                except Exception:
                    pass

            if PY3:
                html = raw_data.decode("utf-8", errors="ignore")
            else:
                html = raw_data

            if "Just a moment..." in html or "challenge-platform" in html:
                self.last_error = "CLOUDFLARE_BLOCKED"
                return ""

            if use_cache:
                self.memory_cache[target_url] = html
            return html
        except Exception as e:
            log_debug("Fetch error: " + str(e))
            self.last_error = str(e)
            return ""

    def check_connection(self):
        html = self.fetch_html(self.domain_root + "/home/", use_cache=False)
        if self.last_error == "CLOUDFLARE_BLOCKED":
            return False, "النطاق محمي بـ Cloudflare"
        if html and len(html) > 300:
            return True, "تم الاتصال بنجاح بموقع عرب سيد"
        return False, self.last_error or "تعذر الاتصال بخادم عرب سيد"

    def get_items(self, path="/home/", page=1):
        if not path:
            path = "/home/"

        if path.startswith("YEAR_ALL:") or path.startswith("YEAR_MOVIES:") or path.startswith("YEAR_SERIES:"):
            return self.get_year_items(path, page)

        clean_path = path.strip()
        if page > 1:
            if "?" in clean_path:
                target_url = clean_path + ("&page=%d" % page)
            else:
                target_url = clean_path.rstrip("/") + ("/?page=%d" % page)
        else:
            target_url = clean_path

        html = self.fetch_html(target_url)
        if not html:
            return []

        return self.parse_items_from_html(html)

    def get_year_items(self, year_cmd, page=1):
        mode, val = year_cmd.split(":", 1)
        search_query = val.strip()

        if "-" in search_query:
            start_y, end_y = [int(x) for x in search_query.split("-", 1)]
            search_query = str(start_y)

        if page > 1:
            target_url = "/search/%s/?page=%d" % (quote(search_query), page)
        else:
            target_url = "/search/%s/" % quote(search_query)

        html = self.fetch_html(target_url)
        if not html:
            return []

        raw_items = self.parse_items_from_html(html)
        filtered = []
        for it in raw_items:
            is_series = it.get("is_series", False)
            if mode == "YEAR_MOVIES" and is_series:
                continue
            if mode == "YEAR_SERIES" and not is_series:
                continue
            filtered.append(it)

        # Series grouping to prevent flooding
        return self.group_series_items(filtered)

    def parse_items_from_html(self, html):
        items = []
        if not html:
            return items

        card_patterns = [
            r'<div[^>]*class=["\'][^"\']*item__contents[^"\']*["\'][^>]*>(.*?)</div>\s*</li>',
            r'(<a[^>]+class=["\'][^"\']*movie__block[^"\']*["\'][^>]*>.*?</a>)',
            r'<div[^>]*class=["\'][^"\']*(?:post__image|Movie--Block|BlockItem|post-item)[^"\']*["\'][^>]*>(.*?)</div>\s*</div>',
            r'<div[^>]*class=["\'][^"\']*post__image[^"\']*["\'][^>]*>(.*?)</div>',
            r'<li[^>]*class=["\'][^"\']*Movie--Block[^"\']*["\'][^>]*>(.*?)</li>'
        ]

        found_blocks = []
        for pat in card_patterns:
            matches = re.findall(pat, html, re.DOTALL | re.IGNORECASE)
            if matches:
                found_blocks = matches
                break

        if not found_blocks:
            found_blocks = re.findall(r'<a[^>]+href=["\'](https?://[^"\']*(?:arabseed|wine|in)[^"\']*)["\'][^>]*>(.*?)</a>', html, re.DOTALL)
            for href, inner in found_blocks:
                t = clean_arabic_title(inner)
                if len(t) > 3 and not any(skip in href.lower() for skip in ['/category/', '/tag/', '/author/', '/page/']):
                    is_series = any(w in t for w in ['مسلسل', 'الموسم', 'الحلقة', 'برنامج', 'حلقة'])
                    items.append({
                        "title": t,
                        "url": href,
                        "poster": extract_image_src(inner, self.domain_root),
                        "year": self.extract_year_from_text(t),
                        "quality": "HD",
                        "is_series": is_series
                    })
            return self.deduplicate_items(items)

        for block in found_blocks:
            item = self.parse_single_block(block)
            if item and item.get("title") and item.get("url"):
                items.append(item)

        return self.deduplicate_items(items)

    def parse_single_block(self, block):
        # 1. URL
        url_m = re.search(r'href=["\']([^"\']+)["\']', block)
        if not url_m:
            return None
        raw_url = url_m.group(1).strip()
        if any(skip in raw_url.lower() for skip in ['/category/', '/tag/', '/author/', '/page/', 'facebook.com', 'twitter.com', 'telegram.me']):
            return None
        full_url = self.build_full_url(raw_url)

        # 2. Title
        title = ""
        for pat in [
            r'class=["\'][^"\']*post__name[^"\']*["\'][^>]*>(.*?)</',
            r'class=["\'][^"\']*title[^"\']*["\'][^>]*>(.*?)</',
            r'title=["\']([^"\']+)["\']',
            r'<h[234][^>]*>(.*?)</h[234]>',
            r'<img[^>]+alt=["\']([^"\']+)["\']'
        ]:
            tm = re.search(pat, block, re.DOTALL | re.IGNORECASE)
            if tm:
                clean_t = clean_arabic_title(tm.group(1))
                if len(clean_t) > 2 and "مشاهدة" not in clean_t[:8]:
                    title = clean_t
                    break
        if not title:
            title = clean_arabic_title(block)
        if not title or len(title) < 2:
            return None

        # 3. Poster
        poster = extract_image_src(block, self.domain_root)

        # 4. Year & Quality
        year = self.extract_year_from_text(title + " " + block)
        qu_m = re.search(r'class=["\'][^"\']*(?:quality|resolution)[^"\']*["\'][^>]*>(.*?)<', block, re.IGNORECASE)
        quality = clean_arabic_title(qu_m.group(1)) if qu_m else "1080p FHD"
        if not quality or len(quality) > 10:
            quality = "1080p FHD"

        # 5. Is series
        is_series = any(w in title for w in ['مسلسل', 'الموسم', 'الحلقة', 'برنامج', 'انمي', 'كرتون']) or 'mslsl-' in full_url

        return {
            "title": title,
            "url": full_url,
            "poster": poster,
            "year": year,
            "quality": quality,
            "is_series": is_series
        }

    def deduplicate_items(self, items):
        seen = set()
        unique = []
        for it in items:
            u = it.get("url", "")
            if u and u not in seen:
                seen.add(u)
                unique.append(it)
        return unique

    def extract_year_from_text(self, text):
        m = re.findall(r'\b(20[0-2][0-9]|19[7-9][0-9])\b', text)
        if m:
            return m[-1]
        return "2024"

    def group_series_items(self, items):
        series_map = {}
        result = []

        for it in items:
            title = it["title"]
            if not it.get("is_series", False):
                result.append(it)
                continue

            cleaned_title = re.sub(r'الحلقة\s*\d+', '', title)
            cleaned_title = re.sub(r'الموسم\s*\d+', '', cleaned_title)
            cleaned_title = re.sub(r'\s{2,}', ' ', cleaned_title).strip()

            if cleaned_title not in series_map:
                it_copy = dict(it)
                it_copy["title"] = cleaned_title + " (مسلسل)"
                series_map[cleaned_title] = it_copy
                result.append(it_copy)

        return result

    def get_episodes(self, series_url):
        episodes = []
        if not series_url:
            return episodes

        html = self.fetch_html(series_url)
        if not html:
            return episodes

        blocks = re.findall(r'<div[^>]*class=["\'][^"\']*(?:ContainerEpisodesList|episodes-list|Episodes--List)[^"\']*["\'][^>]*>(.*?)</div>\s*</div>', html, re.DOTALL)
        content_to_search = blocks[0] if blocks else html

        links = re.findall(r'<a[^>]+href=["\'](https?://[^"\']+)["\'][^>]*>(.*?)</a>', content_to_search, re.DOTALL)
        for h, t in links:
            clean_t = clean_arabic_title(t)
            if 'الحلقة' in clean_t or 'حلقة' in clean_t or 'episode' in h.lower():
                episodes.append({
                    "title": clean_t if clean_t else "الحلقة",
                    "url": h
                })

        seen = set()
        dedup = []
        for ep in episodes:
            if ep["url"] not in seen:
                seen.add(ep["url"])
                dedup.append(ep)

        def ep_num(e):
            m = re.search(r'\d+', e["title"])
            return int(m.group(0)) if m else 9999
        dedup.sort(key=ep_num)

        return dedup

    def get_megamax_streams_data(self, iframe_url):
        """
        Unlocks MegaMax streams using Inertia partial reload.
        Returns array of qualities and video mirror links.
        """
        try:
            headers1 = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36",
                "Referer": "https://megamax.me/",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
            }
            req1 = urllib2.Request(iframe_url, headers=headers1)
            res1 = self.opener.open(req1, timeout=6)
            html1 = res1.read().decode("utf-8", errors="ignore") if PY3 else res1.read()

            v_m = re.search(r'"version"\s*:\s*"([a-f0-9]+)"', html1)
            version = v_m.group(1) if v_m else "a601a2d0d16b8ae7121ceb1fd46c1f5a"

            headers2 = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36",
                "Referer": iframe_url,
                "Origin": "https://megamax.me",
                "X-Inertia": "true",
                "X-Inertia-Version": version,
                "X-Inertia-Partial-Component": "files/mirror/video",
                "X-Inertia-Partial-Data": "streams",
                "Accept": "text/html, application/xhtml+xml"
            }
            req2 = urllib2.Request(iframe_url, headers=headers2)
            res2 = self.opener.open(req2, timeout=6)
            raw_res = res2.read().decode("utf-8", errors="ignore") if PY3 else res2.read()
            data = json.loads(raw_res)
            return data.get("props", {}).get("streams", {}).get("data", [])
        except Exception as e:
            log_debug("get_megamax_streams_data error: " + str(e))
            return []

    def get_servers(self, media_url):
        servers = []
        if not media_url:
            return servers

        log_debug("Fetching servers for: " + media_url)
        html = self.fetch_html(media_url)
        if not html:
            return servers

        watch_m = re.search(r'href=["\'](https?://[^"\']*/watch/)["\']', html)
        watch_url = watch_m.group(1) if watch_m else (media_url.rstrip("/") + "/watch/")

        dl_m = re.search(r'href=["\'](https?://[^"\']*/download/)["\']', html)
        dl_url = dl_m.group(1) if dl_m else (media_url.rstrip("/") + "/download/")

        w_html = self.fetch_html(watch_url, use_cache=False, custom_headers={"Referer": media_url})
        megamax_url = ""

        if w_html:
            csrf_m = re.search(r'csrf__token[\'"]?\s*:\s*[\'"]([a-zA-Z0-9]+)[\'"]', w_html)
            csrf = csrf_m.group(1) if csrf_m else ""

            # Check deferred iframe
            def_m = re.search(r'class=["\'][^"\']*arabseed-deferred-iframe[^"\']*["\'][^>]*data-src=["\']([^"\']+)["\']', w_html)
            if def_m:
                d_url = def_m.group(1)
                if "megamax.me" in d_url:
                    megamax_url = d_url
                else:
                    servers.append({
                        "name": "سيرفر عرب سيد الأساسي (1080p FHD)",
                        "url": d_url,
                        "quality": "1080p FHD",
                        "type": "direct_embed"
                    })

            # Check AJAX server buttons
            servers_items = re.findall(
                r'<li[^>]+data-post=["\'](\d+)["\'][^>]+data-server=["\'](\d+)["\'][^>]+data-qu=["\']([^"\']*)["\'][^>]*>.*?<span>(.*?)</span>',
                w_html, re.DOTALL
            )
            for post_id, s_idx, qu, name in servers_items[:4]:
                cname = re.sub(r'<[^>]+>', '', name).strip()
                resolved = self.fetch_ajax_server(watch_url, post_id, s_idx, qu, csrf)
                if resolved:
                    if "megamax.me" in resolved:
                        megamax_url = resolved
                    else:
                        servers.append({
                            "name": cname + " (" + (qu + "p" if qu else "1080p") + ")",
                            "url": resolved,
                            "quality": (qu + "p" if qu else "1080p"),
                            "type": "ajax_server"
                        })

        # If MegaMax is used on Arabseed (the main player host now):
        # Automatically expand its high-speed direct mirrors (VidMoly, Uqload, StreamRuby, MixDrop)
        if megamax_url:
            streams = self.get_megamax_streams_data(megamax_url)
            for stream_entry in streams:
                lbl = stream_entry.get("label", "1080p")
                clean_qu = "1080p" if "1080" in lbl or "source" in lbl else ("720p" if "720" in lbl else "480p")
                mirrors = stream_entry.get("mirrors", [])
                for m in mirrors:
                    driver = (m.get("driver") or "").lower()
                    link = m.get("link") or ""
                    if link.startswith("//"):
                        link = "https:" + link

                    if "vidmoly" in driver or "vidmoly" in link:
                        servers.append({
                            "name": "سيرفر VidMoly [%s] - (سريع ومباشر)" % clean_qu,
                            "url": link,
                            "quality": clean_qu,
                            "type": "vidmoly"
                        })
                    elif "uqload" in driver or "uqload" in link:
                        servers.append({
                            "name": "سيرفر Uqload [%s] - (سيرفر مباشر ومستقر)" % clean_qu,
                            "url": link,
                            "quality": clean_qu,
                            "type": "uqload"
                        })
                    elif "streamruby" in driver or "stmruby" in link:
                        servers.append({
                            "name": "سيرفر StreamRuby [%s] - (فائق السرعة)" % clean_qu,
                            "url": link,
                            "quality": clean_qu,
                            "type": "streamruby"
                        })
                    elif "mixdrop" in driver or "mixdrop" in link:
                        servers.append({
                            "name": "سيرفر MixDrop [%s] - (جودة عالية)" % clean_qu,
                            "url": link,
                            "quality": clean_qu,
                            "type": "mixdrop"
                        })
                    elif "voe" in driver or "voe" in link:
                        servers.append({
                            "name": "سيرفر VOE [%s]" % clean_qu,
                            "url": link,
                            "quality": clean_qu,
                            "type": "voe"
                        })

        # If still empty or as backup, add fallback direct download mirrors
        dl_html = self.fetch_html(dl_url, use_cache=False, custom_headers={"Referer": media_url})
        if dl_html:
            dl_links = re.findall(r'<a[^>]+href=["\'](https?://[^"\']+)["\'][^>]*>(.*?)</a>', dl_html)
            for h, t in dl_links:
                ct = re.sub(r'<[^>]+>', '', t).strip()
                low_h = h.lower()
                if any(k in low_h for k in ['morencius', 'earnvids', 'megaup', '1cloud', 'vikingfile', 'bowfile', 'forafile']):
                    servers.append({
                        "name": "سيرفر مباشر: " + (ct if ct else "تحميل ومشاهدة"),
                        "url": h,
                        "quality": "1080p",
                        "type": "dl_mirror"
                    })

        # If only megamax iframe was found without mirrors
        if not servers and megamax_url:
            servers.append({
                "name": "سيرفر عرب سيد الأساسي MegaMax",
                "url": megamax_url,
                "quality": "1080p FHD",
                "type": "megamax_direct"
            })

        return servers

    def fetch_ajax_server(self, watch_url, post_id, server_idx, quality, csrf_token):
        try:
            post_data = urlencode({
                "post_id": post_id,
                "quality": quality,
                "server": server_idx,
                "csrf_token": csrf_token
            })
            if PY3:
                post_data = post_data.encode("utf-8")
            else:
                post_data = str(post_data)

            ajax_url = self.domain_root + "/get__watch__server/"
            req = urllib2.Request(ajax_url, data=post_data, headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                "X-Requested-With": "XMLHttpRequest",
                "Referer": watch_url,
                "Origin": self.domain_root
            })
            res = self.opener.open(req, timeout=3)
            raw = res.read().decode("utf-8", errors="ignore") if PY3 else res.read()
            data = json.loads(raw)
            if data.get("type") == "success" and data.get("server"):
                return data.get("server")
        except Exception:
            pass
        return ""

    def unpack_dean_edwards(self, match_or_html):
        try:
            if hasattr(match_or_html, 'groups'):
                p, a, c, k = match_or_html.groups()
            else:
                m = re.search(r"eval\(function\(p,a,c,k,e,[rd]\).*?return p\}\('(.*?)',(\d+),(\d+),'(.*?)'\.split\('\|'\)", match_or_html, re.DOTALL)
                if not m:
                    return ""
                p, a, c, k = m.groups()
            a, c = int(a), int(c)
            k = k.split('|')
            chars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
            for i in range(c - 1, -1, -1):
                if i < len(k) and k[i]:
                    base_repr = ""
                    tmp = i
                    if tmp == 0:
                        base_repr = "0"
                    else:
                        while tmp > 0:
                            base_repr = chars[tmp % a] + base_repr
                            tmp //= a
                    p = re.sub(r'\b' + base_repr + r'\b', k[i], p)
            return p
        except Exception:
            return ""

    def resolve_stream_url(self, server_url):
        """
        Resolves the direct playable stream URL (.m3u8 or .mp4) with its referer.
        CRITICAL: If resolution fails, it returns ("", "") to prevent Enigma2 from
        attempting to play raw HTML webpages which freezes the receiver!
        """
        if not server_url:
            return "", ""

        log_debug("Resolving stream from: " + server_url)
        parsed = urlparse(server_url)
        referer = "%s://%s/" % (parsed.scheme or "https", parsed.netloc)
        low = server_url.lower()

        # 1. Direct stream
        if any(ext in low for ext in [".m3u8", ".mp4", ".mkv", ".ts"]):
            return server_url, referer

        # 2. MegaMax iframe: resolve its first working high-speed mirror
        if "megamax.me" in low:
            streams = self.get_megamax_streams_data(server_url)
            for s_entry in streams:
                for m in s_entry.get("mirrors", []):
                    m_link = m.get("link") or ""
                    if m_link.startswith("//"):
                        m_link = "https:" + m_link
                    resolved_stream, r_ref = self.resolve_stream_url(m_link)
                    if resolved_stream and (".m3u8" in resolved_stream or ".mp4" in resolved_stream):
                        return resolved_stream, r_ref

        # 3. Fetch embed HTML with proper headers
        try:
            req = urllib2.Request(server_url, headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36",
                "Referer": server_url,
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
            })
            res = self.opener.open(req, timeout=6)
            html = res.read().decode("utf-8", errors="ignore") if PY3 else res.read()
        except Exception as e:
            log_debug("Error fetching server page: " + str(e))
            return "", ""

        # 4. Direct M3U8 inside HTML
        m3u8s = re.findall(r'https?://[^\s"\'<>]+\.m3u8[^\s"\'<>]*', html)
        for m in m3u8s:
            if not m.endswith(".jpg") and not m.endswith(".png"):
                return m, server_url

        # 5. Dean Edwards packed script (VidMoly, Uqload, StreamRuby, EarnVids)
        if "eval(function(p,a,c,k,e," in html:
            unp = self.unpack_dean_edwards(html)
            if unp:
                unp_m3u8 = re.findall(r'https?://[^\s"\'<>]+\.m3u8[^\s"\'<>]*', unp)
                for u in unp_m3u8:
                    return u, server_url
                unp_mp4 = re.findall(r'https?://[^\s"\'<>]+\.mp4[^\s"\'<>]*', unp)
                for u in unp_mp4:
                    return u, server_url

        # 6. Direct MP4 in HTML5 video
        vid_m = re.search(r'<video[^>]+src=["\'](https?://[^"\']+)["\']', html, re.I)
        if vid_m and (".mp4" in vid_m.group(1) or ".m3u8" in vid_m.group(1)):
            return vid_m.group(1), server_url

        src_m = re.search(r'<source[^>]+src=["\'](https?://[^"\']+)["\']', html, re.I)
        if src_m and (".mp4" in src_m.group(1) or ".m3u8" in src_m.group(1)):
            return src_m.group(1), server_url

        # 7. Fallback search for any mp4
        mp4s = re.findall(r'https?://[^\s"\'<>]+\.mp4[^\s"\'<>]*', html)
        for mp4 in mp4s:
            if not mp4.endswith(".jpg") and not mp4.endswith(".png"):
                return mp4, server_url

        # Never return an HTML page as a stream!
        log_debug("No playable video stream found for: " + server_url)
        return "", ""
