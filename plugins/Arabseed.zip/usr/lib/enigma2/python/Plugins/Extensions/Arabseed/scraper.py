# -*- coding: utf-8 -*-
"""
===================================================================
 Arabseed Scraper Compatibility & Namespace Collision Shield
 Compatible with Python 2 & Python 3
-------------------------------------------------------------------
This file provides full backward compatibility for older versions
while ensuring that other Enigma2 plugins (like Akwam) will NEVER
suffer from import namespace collisions:
If another plugin accidentally resolves 'scraper' here due to Enigma2
sys.path ordering, we dynamically re-export Akwam's scraper so Akwam
continues to load smoothly without any errors.
===================================================================
"""

# 1. Collision Shield: If Akwam or another extension imports from 'scraper', delegate cleanly
try:
    from Plugins.Extensions.Akwam.scraper import *
except Exception:
    pass

# 2. Re-export all Arabseed scraper classes
try:
    from Plugins.Extensions.Arabseed.arabseed_scraper import *
except Exception:
    try:
        from arabseed_scraper import *
    except Exception:
        pass
