# -*- coding: utf-8 -*-
# Satellites.xml Auto-Sync Plugin for Enigma2
# Location: /usr/lib/enigma2/python/Plugins/Extensions/SatellitesXmlUpdater/plugin.py

import os
import sys
import ssl
import threading

try:
    import urllib.request as urllib2
except ImportError:
    import urllib2

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from Screens.MessageBox import MessageBox

def ar(text):
    return text

VERSION = "3.5.0"
API_URL = "https://ais-dev-lfz4b6q5kvbiazpeecb26b-559956860993.europe-west2.run.app/api/satellites.xml?preset=mena_europe_vip"
TARGET_PATH = "/etc/tuxbox/satellites.xml"

BUILTIN_SATELLITES_XML = """<?xml version="1.0" encoding="utf-8"?>
<satellites>
	<sat name="Nilesat 201/301 (7.0W)" flags="1" position="-70">
		<transponder frequency="11747000" symbol_rate="27500000" polarization="1" fec_inner="4" system="0" modulation="1"/>
		<transponder frequency="11766000" symbol_rate="27500000" polarization="0" fec_inner="4" system="0" modulation="1"/>
		<transponder frequency="11823000" symbol_rate="27500000" polarization="1" fec_inner="4" system="0" modulation="1"/>
		<transponder frequency="11900000" symbol_rate="27500000" polarization="1" fec_inner="4" system="0" modulation="1"/>
		<transponder frequency="12015000" symbol_rate="27500000" polarization="1" fec_inner="4" system="0" modulation="1"/>
		<transponder frequency="12054000" symbol_rate="27500000" polarization="1" fec_inner="4" system="0" modulation="1"/>
		<transponder frequency="12188000" symbol_rate="27500000" polarization="0" fec_inner="3" system="1" modulation="2"/>
		<transponder frequency="12284000" symbol_rate="27500000" polarization="1" fec_inner="4" system="0" modulation="1"/>
	</sat>
	<sat name="Eutelsat 8 West B (8.0W)" flags="1" position="-80">
		<transponder frequency="10971000" symbol_rate="27500000" polarization="0" fec_inner="5" system="0" modulation="1"/>
		<transponder frequency="11054000" symbol_rate="27500000" polarization="0" fec_inner="2" system="1" modulation="2"/>
		<transponder frequency="11096000" symbol_rate="27500000" polarization="0" fec_inner="4" system="0" modulation="1"/>
		<transponder frequency="11179000" symbol_rate="27500000" polarization="0" fec_inner="4" system="0" modulation="1"/>
		<transponder frequency="11555000" symbol_rate="27500000" polarization="1" fec_inner="4" system="0" modulation="1"/>
		<transponder frequency="12644000" symbol_rate="27500000" polarization="1" fec_inner="4" system="0" modulation="1"/>
	</sat>
	<sat name="Badr 4/5/6/7/8 (26.0E)" flags="1" position="260">
		<transponder frequency="11270000" symbol_rate="27500000" polarization="1" fec_inner="4" system="1" modulation="2"/>
		<transponder frequency="11919000" symbol_rate="27500000" polarization="0" fec_inner="3" system="0" modulation="1"/>
		<transponder frequency="11977000" symbol_rate="27500000" polarization="1" fec_inner="4" system="0" modulation="1"/>
		<transponder frequency="12015000" symbol_rate="27500000" polarization="1" fec_inner="4" system="0" modulation="1"/>
		<transponder frequency="12149000" symbol_rate="27500000" polarization="0" fec_inner="4" system="0" modulation="1"/>
		<transponder frequency="12245000" symbol_rate="27500000" polarization="1" fec_inner="4" system="1" modulation="2"/>
	</sat>
	<sat name="Hotbird 13F/13G (13.0E)" flags="1" position="130">
		<transponder frequency="10992000" symbol_rate="27500000" polarization="1" fec_inner="2" system="1" modulation="2"/>
		<transponder frequency="11034000" symbol_rate="27500000" polarization="1" fec_inner="3" system="1" modulation="2"/>
		<transponder frequency="11449000" symbol_rate="27500000" polarization="0" fec_inner="3" system="1" modulation="2"/>
		<transponder frequency="11727000" symbol_rate="29900000" polarization="1" fec_inner="3" system="1" modulation="2"/>
		<transponder frequency="12188000" symbol_rate="27500000" polarization="1" fec_inner="3" system="1" modulation="2"/>
		<transponder frequency="12597000" symbol_rate="27500000" polarization="1" fec_inner="3" system="1" modulation="2"/>
	</sat>
	<sat name="Astra 19.2E" flags="1" position="192">
		<transponder frequency="11229000" symbol_rate="22000000" polarization="1" fec_inner="2" system="1" modulation="2"/>
		<transponder frequency="11362000" symbol_rate="22000000" polarization="0" fec_inner="2" system="1" modulation="2"/>
		<transponder frequency="11836000" symbol_rate="27500000" polarization="0" fec_inner="3" system="0" modulation="1"/>
		<transponder frequency="12188000" symbol_rate="27500000" polarization="0" fec_inner="3" system="0" modulation="1"/>
	</sat>
	<sat name="Yahsat 52.5E" flags="1" position="525">
		<transponder frequency="11843000" symbol_rate="27500000" polarization="1" fec_inner="3" system="1" modulation="2"/>
		<transponder frequency="12015000" symbol_rate="27500000" polarization="0" fec_inner="3" system="1" modulation="2"/>
	</sat>
</satellites>
"""

class SatellitesXmlUpdaterScreen(Screen):
    skin = """
    <screen name="SatellitesXmlUpdaterScreen" position="center,center" size="1050,580" title="Satellites.xml Auto-Updater">
        <widget name="title_label" position="20,20" size="1010,60" font="Regular;38" halign="center" valign="center" transparent="1" foregroundColor="#f59e0b" />
        <widget name="status_label" position="20,95" size="1010,55" font="Regular;28" halign="center" valign="center" transparent="1" foregroundColor="#34d399" />
        <widget name="menu" position="30,165" size="990,290" itemHeight="65" font="Regular;30" scrollbarMode="showOnDemand" enableWrapAround="1" />
        <widget name="panel_label" position="30,475" size="990,65" font="Regular;30" halign="right" valign="center" transparent="0" backgroundColor="#1e293b" foregroundColor="#fbbf24" />
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.is_running = False
        
        self["title_label"] = Label(ar(u"\u062a\u062d\u062f\u064a\u062b \u0645\u0644\u0641 \u0627\u0644\u0623\u0642\u0645\u0627\u0631 \u0648\u0627\u0644\u062a\u0631\u062f\u062f\u0627\u062a (Satellites.xml)"))
        self["status_label"] = Label(ar(u"\u0627\u062e\u062a\u0631 \u0627\u0644\u062e\u064a\u0627\u0631 \u062b\u0645 \u0627\u0636\u063a\u0637 OK \u0641\u064a \u0627\u0644\u0631\u064a\u0645\u0648\u062a..."))
        self["panel_label"] = Label(ar(u"\u0647\u0630\u0627 \u0627\u0644\u0628\u0644\u062c\u0646 \u0645\u062a\u0627\u062d \u0641\u064a \u0628\u0646\u0644 MOHAMED STORE  "))
        
        opt1 = u"[ 1 ]  \u062a\u062d\u062f\u064a\u062b \u0641\u0648\u0631\u064a \u0644\u0623\u0647\u0645 \u0627\u0644\u0623\u0642\u0645\u0627\u0631 (Instant VIP - 0 \u062b\u0627\u0646\u064a\u0629)"
        opt2 = u"[ 2 ]  \u0645\u0632\u0627\u0645\u0646\u0629 \u0633\u062d\u0627\u0628\u064a\u0629 \u0634\u0627\u0645\u0644\u0629 \u0644\u0643\u0644 \u0627\u0644\u0623\u0642\u0645\u0627\u0631 (Online Sync)"
        opt3 = u"[ 3 ]  \u062a\u0641\u0639\u064a\u0644 \u0627\u0644\u062a\u062d\u062f\u064a\u062b \u0627\u0644\u064a\u0648\u0645\u064a \u0627\u0644\u062a\u0644\u0642\u0627\u0626\u064a (04:00 AM)"
        opt4 = u"[ 4 ]  \u062e\u0631\u0648\u062c \u0645\u0646 \u0627\u0644\u0628\u0644\u062c\u0646 (Exit)"
        
        menu_items = [
            (ar(opt1), self.apply_builtin),
            (ar(opt2), self.start_online_sync),
            (ar(opt3), self.setup_cron),
            (ar(opt4), self.close)
        ]
        self["menu"] = MenuList(menu_items)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "ok": self.ok_pressed,
            "green": self.apply_builtin,
            "yellow": self.start_online_sync,
            "cancel": self.close,
            "red": self.close
        }, -1)

    def ok_pressed(self):
        if self.is_running:
            return
        selected = self["menu"].getCurrent()
        if selected:
            selected[1]()

    def write_file(self, content_str, label="VIP"):
        try:
            if os.path.exists(TARGET_PATH):
                os.system("cp " + TARGET_PATH + " " + TARGET_PATH + ".bak >/dev/null 2>&1")
            with open(TARGET_PATH, "wb") as f:
                if isinstance(content_str, bytes):
                    f.write(content_str)
                else:
                    f.write(content_str.encode('utf-8'))
            os.chmod(TARGET_PATH, 0o644)
            os.system("(wget -T 2 -qO - http://127.0.0.1/web/servicelistreload?mode=0 >/dev/null 2>&1 || true) &")
            self["status_label"].setText(ar(u"\u062a\u0645 \u0628\u0646\u062c\u0627\u062d: \u062a\u0645 \u062a\u062d\u062f\u064a\u062b " + TARGET_PATH))
            msg_txt = u"\u062a\u0645 \u062a\u062d\u062f\u064a\u062b \u0645\u0644\u0641 \u0627\u0644\u062a\u0631\u062f\u062f\u0627\u062a satellites.xml \u0628\u0646\u062c\u0627\u062d!\n\u062a\u0645\u062a \u0625\u0639\u0627\u062f\u0629 \u062a\u062d\u0645\u064a\u0644 \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0642\u0646\u0648\u0627\u062a."
            self.session.open(MessageBox, ar(msg_txt), MessageBox.TYPE_INFO, timeout=4)
        except Exception as e:
            self["status_label"].setText(ar(u"\u062e\u0637\u0623: " + str(e)))
        finally:
            self.is_running = False

    def apply_builtin(self):
        if self.is_running:
            return
        self.is_running = True
        self["status_label"].setText(ar(u"\u062c\u0627\u0631\u064a \u062a\u0637\u0628\u064a\u0642 \u0627\u0644\u062a\u062d\u062f\u064a\u062b \u0627\u0644\u0641\u0648\u0631\u064a..."))
        self.write_file(BUILTIN_SATELLITES_XML, "VIP")

    def start_online_sync(self):
        if self.is_running:
            return
        self.is_running = True
        self["status_label"].setText(ar(u"\u062c\u0627\u0631\u064a \u0627\u0644\u0627\u062a\u0635\u0627\u0644 \u0628\u0627\u0644\u0633\u064a\u0631\u0641\u0631..."))
        t = threading.Thread(target=self._worker)
        t.daemon = True
        t.start()

    def _worker(self):
        try:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            req = urllib2.Request(API_URL, headers={'User-Agent': 'Enigma2-Satellites-Plugin'})
            res = urllib2.urlopen(req, context=ctx, timeout=3)
            data = res.read()
            if (b"<satellites>" in data) if isinstance(data, bytes) else ("<satellites>" in data):
                self.write_file(data, "Online")
                return
        except Exception:
            pass
        self.write_file(BUILTIN_SATELLITES_XML, "Fallback")

    def setup_cron(self):
        cmd = '(crontab -l 2>/dev/null | grep -v "satellites.xml"; echo "0 4 * * * wget --no-check-certificate -qO ' + TARGET_PATH + ' \'' + API_URL + '\' && wget -qO - http://127.0.0.1/web/servicelistreload?mode=0 >/dev/null 2>&1") | crontab -'
        os.system(cmd)
        self.session.open(MessageBox, ar(u"\u062a\u0645 \u062a\u0641\u0639\u064a\u0644 \u0627\u0644\u062a\u062d\u062f\u064a\u062b \u0627\u0644\u064a\u0648\u0645\u064a \u0628\u0646\u062c\u0627\u062d 04:00 \u0641\u062c\u0631\u0627\u064b!"), MessageBox.TYPE_INFO, timeout=4)

def main(session, **kwargs):
    session.open(SatellitesXmlUpdaterScreen)

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="Satellites.xml Updater",
            description="Instant satellites.xml updater",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="plugin.png",
            fnc=main
        ),
        PluginDescriptor(
            name="Satellites.xml Updater",
            description="Instant satellites.xml updater",
            where=PluginDescriptor.WHERE_EXTENSIONSMENU,
            icon="plugin.png",
            fnc=main
        )
    ]