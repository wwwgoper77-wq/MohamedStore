from __future__ import print_function
import os
from Screens.Screen import Screen
from Components.Sources.StaticText import StaticText
from Components.Sources.List import List
from Components.ActionMap import ActionMap

class YouTubeDownloadList(Screen):
    skin = """<screen position="center,center" size="720,370" title="Downloads">
        <widget source="list" render="Listbox" position="center,30" size="690,270" />
        <widget source="key_red" render="Label" position="center,328" size="140,30" />
    </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self['key_red'] = StaticText('Exit')
        self['list'] = List([])
        self['actions'] = ActionMap(['SetupActions', 'ColorActions'], {
            'cancel': self.close,
            'red': self.close
        }, -2)
