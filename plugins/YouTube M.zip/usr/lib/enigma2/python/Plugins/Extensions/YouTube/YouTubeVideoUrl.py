# -*- coding: UTF-8 -*-
from __future__ import print_function

from re import escape, findall, match, search, sub
from json import dumps, loads
from Components.config import config
from .compat import compat_parse_qs, compat_Request, compat_urlopen, compat_URLError, SUBURI
from .jsinterp import JSInterpreter

class YouTubeVideoUrl():
	def __init__(self):
		self.use_dash_mp4 = ()
		self._code_cache = {}
		self._player_cache = {}
		self.nsig_cache = (None, None)

	@staticmethod
	def try_get(src, getter):
		for x in getter:
			if isinstance(src, dict) and x in src:
				src = src[x]
			else: return None
		return src

	def _download_webpage(self, url, data=None, headers={}):
		if data: data = dumps(data).encode('utf8')
		if data or headers:
			url = compat_Request(url, data=data, headers=headers)
			url.get_method = lambda: 'POST'
		try:
			urlh = compat_urlopen(url, timeout=5)
		except compat_URLError as e:
			raise RuntimeError(e.reason)
		content_type = urlh.headers.get('Content-Type', '')
		webpage_bytes = urlh.read()
		try: content = webpage_bytes.decode('utf-8', 'replace')
		except Exception: content = str(webpage_bytes)
		return content

	def _extract_url(self, fmt, player_id):
		return fmt.get('url')

	def _extract_player_response(self, video_id, yt_auth, client, lang):
		player_id = None
		url = 'https://www.youtube.com/youtubei/v1/player?prettyPrint=false'
		data = {
			'videoId': video_id,
			'playbackContext': {'contentPlaybackContext': {'html5Preference': 'HTML5_PREF_WANTS'}},
			'context': {'client': {'hl': lang if lang else 'en'}}
		}
		headers = {'content-type': 'application/json', 'Origin': 'https://www.youtube.com', 'X-YouTube-Client-Name': client}
		if yt_auth: headers['Authorization'] = yt_auth

		if client == 3:
			VERSION = '21.08.266'
			USER_AGENT = 'com.google.android.youtube/%s (Linux; U; Android 11) gzip' % VERSION
			CLIENT_CONTEXT = {'clientName': 'ANDROID', 'androidSdkVersion': 30, 'osName': 'Android', 'osVersion': '11'}
			data['params'] = '2AMB'
		elif client == 5:
			VERSION = '20.03.02'
			USER_AGENT = 'com.google.ios.youtube/%s (iPhone16,2; U; CPU iOS 18_2_1 like Mac OS X;)' % VERSION
			CLIENT_CONTEXT = {'clientName': 'IOS', 'deviceMake': 'Apple', 'deviceModel': 'iPhone16,2', 'osName': 'iPhone', 'osVersion': '18.2.1.22C161'}
		else:
			VERSION = '7.20250129.15.00'
			USER_AGENT = 'Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version,gzip(gfe)'
			CLIENT_CONTEXT = {'clientName': 'TVHTML5'}

		data['context']['client']['clientVersion'] = VERSION
		data['context']['client'].update(CLIENT_CONTEXT)
		if USER_AGENT:
			data['context']['client']['userAgent'] = USER_AGENT
			headers['User-Agent'] = USER_AGENT
		headers['X-YouTube-Client-Version'] = VERSION
		try:
			return loads(self._download_webpage(url, data, headers)), player_id
		except Exception:
			return None, None

	def _real_extract(self, video_id, yt_auth):
		lang = config.plugins.YouTube.searchLanguage.value or 'ar'
		for client_id in (3, 5, 7):
			player_response, player_id = self._extract_player_response(video_id, yt_auth, client_id, lang)
			if not player_response: continue
			streaming_data = player_response.get('streamingData', {})
			formats = streaming_data.get('formats', []) + streaming_data.get('adaptiveFormats', [])
			for fmt in formats:
				url = fmt.get('url')
				if url and ('video/mp4' in fmt.get('mimeType', '') or 'mp4' in url):
					return str(url)
			for fmt in formats:
				url = fmt.get('url')
				if url: return str(url)
			hls = streaming_data.get('hlsManifestUrl')
			if hls: return str(hls)
		raise RuntimeError('Video URL could not be extracted for id: %s' % video_id)

	def extract(self, video_id, yt_auth=None):
		for _ in range(3):
			try: return self._real_extract(video_id, yt_auth)
			except Exception as ex: pass
		raise RuntimeError('No supported video formats found!')
