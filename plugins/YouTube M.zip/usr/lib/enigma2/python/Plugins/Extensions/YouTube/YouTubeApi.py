from __future__ import print_function

from json import dumps, load
from socket import error

from .compat import compat_quote, compat_urlopen, compat_Request, compat_HTTPError, compat_URLError
from .OAuth import OAuth, API_KEY


class YouTubeApi:
	def __init__(self, refresh_token):
		self.refresh_token = refresh_token
		if self.refresh_token:
			self.renew_access_token()
		else:
			self.access_token = None
			self.yt_auth = None
			self.key = '&key=%s' % API_KEY

	def renew_access_token(self):
		self.key = '&key=%s' % API_KEY
		self.access_token, self.yt_auth = OAuth().get_access_token(self.refresh_token)
		if self.access_token:
			self.key += '&access_token=%s' % self.access_token

	def is_auth(self):
		return bool(self.access_token)

	def get_yt_auth(self):
		return self.yt_auth

	def try_response(self, url_or_request, renew=True):
		response = {}
		status_code = 'Unknown'
		try:
			response = compat_urlopen(url_or_request, timeout=5)
		except Exception as e:
			pass
		else:
			if response:
				status_code = response.getcode()
		return response, status_code

	def get_response(self, url, max_results, page_token):
		url = 'https://www.googleapis.com/youtube/v3/{}{}{}{}'.format(
				url,
				max_results and '&maxResults=%s' % max_results,
				page_token and '&pageToken=%s' % page_token,
				self.key)
		response, status_code = self.try_response(url)
		if response and status_code == 200:
			try:
				return load(response)
			except Exception:
				pass
		return {}

	def subscriptions_list(self, max_results, page_token, subscript_order):
		url = 'subscriptions?part=snippet&mine=true&order={}'.format(subscript_order)
		return self.get_response(url, max_results, page_token)

	def playlists_list(self, max_results, page_token):
		url = 'playlists?part=snippet&mine=true'
		return self.get_response(url, max_results, page_token)

	def channels_list(self, max_results, page_token):
		url = 'channels?part=contentDetails&mine=true'
		return self.get_response(url, max_results, page_token)

	def search_list_full(self, safe_search, order, part, q, s_type, max_results, page_token, **kwargs):
		q = compat_quote(q) if q else '*'
		url = 'search?{}safeSearch={}{}&order={}&part={}&q={}&type={}'.format(
				kwargs.get('video_embeddable', '') and 'videoEmbeddable=%s&' % kwargs['video_embeddable'],
				safe_search,
				kwargs.get('event_type', '') and '&eventType=%s' % kwargs['event_type'],
				order, part.replace(',', '%2C'), q, s_type)
		return self.get_response(url, max_results, page_token)

	def search_list(self, order, part, channel_id, max_results, page_token):
		url = 'search?part={}&order={}&channelId={}'.format(part.replace(',', '%2C'), order, channel_id)
		return self.get_response(url, max_results, page_token)

	def videos_list(self, v_id):
		url = 'videos?part=id%2Csnippet%2Cstatistics%2CcontentDetails&id={}'.format(v_id.replace(',', '%2C'))
		return self.get_response(url, '', '')

	def playlist_items_list(self, order, max_results, playlist_id, page_token):
		url = 'playlistItems?part=snippet&order={}&playlistId={}'.format(order, playlist_id)
		return self.get_response(url, max_results, page_token)
