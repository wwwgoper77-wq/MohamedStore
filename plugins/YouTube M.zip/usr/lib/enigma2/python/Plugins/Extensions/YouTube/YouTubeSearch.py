from __future__ import print_function

import os
from os import path as os_path
from threading import Thread
from json import loads

from enigma import ePoint
from Screens.ChoiceBox import ChoiceBox
from Screens.Screen import Screen
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Components.config import config, ConfigText
from Components.config import KEY_DELETE, KEY_BACKSPACE, KEY_ASCII, KEY_TIMEOUT
from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.Pixmap import Pixmap
from Components.Sources.Boolean import Boolean
from Components.Sources.List import List
from Components.Sources.StaticText import StaticText
from Tools.Directories import resolveFilename, SCOPE_PLUGINS

from . import _, screenwidth
from .compat import compat_quote, compat_urlopen

DEFAULT_BUTTONS = 'skin_default/buttons'
if os_path.exists('/usr/share/enigma2/skin_default/vkey_icon.png'):
	DEFAULT_BUTTONS = 'skin_default'

def DreamOS():
	if os_path.exists('/var/lib/dpkg/status'):
		return DreamOS

class YouTubeVirtualKeyBoard(VirtualKeyBoard):
	def __init__(self, session, text):
		title = text if text else _('Search')
		VirtualKeyBoard.__init__(self, session, title=title, text=text)
		self.skinName = ['YouTubeVirtualKeyBoard', 'VirtualKeyBoard']
		self.searchValue = GoogleSuggestionsConfigText(default=text, update_suggestions=self.updateSuggestions)
		self.onClose.append(self.searchValue.stopSuggestions)
		if text:
			self.searchValue.value = ""
			self.tryGetSuggestions()

	def processSelect(self):
		VirtualKeyBoard.processSelect(self)
		self.tryGetSuggestions()

	def okClicked(self):
		VirtualKeyBoard.okClicked(self)
		self.tryGetSuggestions()

	def backSelected(self):
		VirtualKeyBoard.backSelected(self)
		self.tryGetSuggestions()

	def forwardSelected(self):
		VirtualKeyBoard.forwardSelected(self)
		self.tryGetSuggestions()

	def eraseAll(self):
		VirtualKeyBoard.eraseAll(self)
		self.tryGetSuggestions()

	def tryGetSuggestions(self):
		new_search_value = self['text'].getText()
		if self.searchValue.value != new_search_value:
			self.searchValue.value = new_search_value
			self.searchValue.getSuggestions()

	def updateSuggestions(self, suggestions):
		if 'prompt' in self:
			self['prompt'].text = ', '.join(x[0] for x in suggestions[1:]) if len(suggestions) > 1 else ''
		elif 'header' in self:
			self['header'].text = ', '.join(x[0] for x in suggestions[1:]) if len(suggestions) > 1 else ''

class YouTubeSearch(Screen, ConfigListScreen):
	def __init__(self, session, cur_list):
		Screen.__init__(self, session)
		self.session = session
		self.curList = cur_list
		self.title = _('Search')
		self['key_red'] = StaticText(_('Exit'))
		self['key_green'] = StaticText(_('OK'))
		self['key_yellow'] = StaticText(_('Keyboard'))
		self['HelpWindow'] = Pixmap()
		self['VKeyIcon'] = Boolean(False)
		self['searchactions'] = ActionMap(['SetupActions', 'ColorActions', 'MenuActions'], {
				'cancel': self.close,
				'save': self.ok,
				'ok': self.ok,
				'yellow': self.openKeyboard,
				'menu': self.openMenu}, -2)
		ConfigListScreen.__init__(self, [], session)
		self.searchValue = GoogleSuggestionsConfigText(default='', update_suggestions=self.updateSuggestions)
		self.setSearchEntry()
		self['list'] = List([])
		self.searchHistory = config.plugins.YouTube.searchHistoryDict[self.curList].value
		search_list = [('', None)]
		for entry in self.searchHistory:
			search_list.append((entry, None))
		self['list'].list = search_list
		self.onLayoutFinish.append(self.moveHelpWindow)
		self.onClose.append(self.searchValue.stopSuggestions)

	def moveHelpWindow(self):
		try:
			helpwindowpos = self["HelpWindow"].getPosition()
			self['config'].getCurrent()[1].help_window.instance.move(ePoint(helpwindowpos[0], helpwindowpos[1]))
		except Exception: pass

	def setSearchEntry(self):
		self['config'].list = [(_('Search'), self.searchValue)]

	def updateSuggestions(self, suggestions):
		if 'list' in self:
			self['list'].list = suggestions
			self['list'].index = 0

	def ok(self):
		selected = self['list'].getCurrent()[0]
		if selected and self.searchValue.value != selected:
			self['list'].index = 0
			self.searchValue.value = selected
			self.setSearchEntry()
			self['config'].getCurrent()[1].getSuggestions()
			self.moveHelpWindow()
		else:
			search_value = self.searchValue.value
			try: self['config'].getCurrent()[1].help_window.instance.hide()
			except Exception: pass
			if search_value != '' and config.plugins.YouTube.saveHistory.value:
				if search_value in self.searchHistory: self.searchHistory.remove(search_value)
				self.searchHistory.insert(0, search_value)
				if len(self.searchHistory) > 41: self.searchHistory.pop()
				config.plugins.YouTube.searchHistoryDict[self.curList].value = self.searchHistory
				config.plugins.YouTube.searchHistoryDict[self.curList].save()
			self.close(search_value)

	def openKeyboard(self):
		try: self['config'].getCurrent()[1].help_window.instance.hide()
		except Exception: pass
		from .YouTubeKeyboard import YouTubeKeyBoard
		self.session.openWithCallback(self.keyBoardCallback, YouTubeKeyBoard, text=self.searchValue.value, title=_('Search'))

	def keyBoardCallback(self, name):
		try:
			config = self['config'].getCurrent()[1]
			config.help_window.instance.show()
		except Exception: pass
		if name:
			self.searchValue.value = name
			try: config.getSuggestions()
			except Exception: pass

	def openMenu(self):
		self.close('')

class GoogleSuggestionsConfigText(ConfigText):
	def __init__(self, default, update_suggestions):
		ConfigText.__init__(self, default, fixed_size=False, visible_width=False)
		self.updateSuggestions = update_suggestions
		self.use_suggestions = False
		gl = config.plugins.YouTube.searchRegion.value
		hl = config.plugins.YouTube.searchLanguage.value
		self.url = 'https://www.google.com/complete/search?output=toolbar&client=firefox&json=true&ds=yt{}{}&q='.format(
				gl and '&gl=%s' % gl,
				hl and '&hl=%s' % hl)

	def getGoogleSuggestions(self):
		suggestions_list = None
		suggestions = [('', None)]
		query_value = self.value
		try:
			response = compat_urlopen(self.url + compat_quote(query_value), timeout=3)
			content_type = response.headers.get('Content-Type', '')
			charset = content_type.split('charset=', 1)[1] if 'charset=' in content_type else 'ISO-8859-1'
			suggestions_list = loads(response.read().decode(charset).encode('utf-8'))
			response.close()
		except Exception: pass
		if self.use_suggestions:
			if suggestions_list:
				suggestions.extend([(str(s), None) for s in suggestions_list[1] if s])
			self.updateSuggestions(suggestions)
			if query_value != self.value:
				self.getGoogleSuggestions()
			else:
				self.use_suggestions = False

	def getSuggestions(self):
		if self.value and not self.use_suggestions:
			self.use_suggestions = True
			Thread(target=self.getGoogleSuggestions).start()

	def stopSuggestions(self):
		self.use_suggestions = False

	def handleKey(self, key, callback=None):
		if callback: ConfigText.handleKey(self, key, callback)
		else: ConfigText.handleKey(self, key)
		if key in (KEY_DELETE, KEY_BACKSPACE, KEY_ASCII, KEY_TIMEOUT):
			self.getSuggestions()

	def onSelect(self, session):
		ConfigText.onSelect(self, session)
		self.getSuggestions()
