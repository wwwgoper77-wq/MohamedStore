# -*- coding: utf-8 -*-
from __future__ import print_function
import os
import time
from threading import Thread
from enigma import eTimer, getDesktop
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.ProgressBar import ProgressBar
from Components.Sources.StaticText import StaticText
from Tools.Notifications import AddNotification
from Screens.MessageBox import MessageBox

def _get_progress_skin():
    dsize = getDesktop(0).size()
    dw = dsize.width() or 1280
    f = (dw / 1280.0) if dw > 0 else 1.0
    def s(v): return int(round(v * f))
    W = s(860)
    H = s(340)

    return """
    <screen name="YouTubeDownloadProgress" position="center,center" size="%d,%d" flags="wfNoBorder" zPosition="60">
        <eLabel position="0,0" size="%d,%d" backgroundColor="#0f1218" zPosition="0" />
        <eLabel position="0,0" size="%d,%d" backgroundColor="#ff2d2d" zPosition="1" />
        
        <eLabel text="YouTube Download Manager" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#ff2d2d" backgroundColor="#0f1218" transparent="1" valign="center" zPosition="2" />
        <widget name="status_badge" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#00ff88" backgroundColor="#0f1218" transparent="1" valign="center" halign="right" zPosition="2" />

        <widget name="title" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#ffffff" backgroundColor="#181c24" transparent="0" valign="center" halign="center" zPosition="2" />
        <widget name="filepath" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#8e99a8" backgroundColor="#0f1218" transparent="1" valign="center" halign="center" zPosition="2" />

        <widget name="progress" position="%d,%d" size="%d,%d" zPosition="2" foregroundColor="#ff2d2d" backgroundColor="#232834" />

        <widget name="percent" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#ffcc00" backgroundColor="#0f1218" transparent="1" valign="center" halign="left" zPosition="2" />
        <widget name="stats" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#cbd5e1" backgroundColor="#0f1218" transparent="1" valign="center" halign="right" zPosition="2" />

        <eLabel position="%d,%d" size="%d,%d" backgroundColor="#1f242d" zPosition="1" />
        <widget source="key_red" render="Label" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#ffffff" backgroundColor="#ff2d2d" transparent="0" valign="center" halign="center" zPosition="3" />
        <widget source="key_blue" render="Label" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#ffffff" backgroundColor="#1e60d2" transparent="0" valign="center" halign="center" zPosition="3" />
        <widget source="key_green" render="Label" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#ffffff" backgroundColor="#228b22" transparent="0" valign="center" halign="center" zPosition="3" />
    </screen>
    """ % (
        W, H,
        W, H,
        W, s(5),
        s(30), s(16), s(450), s(32), s(22),
        W - s(300), s(16), s(270), s(32), s(18),
        s(30), s(58), W - s(60), s(46), s(19),
        s(30), s(110), W - s(60), s(24), s(15),
        s(30), s(146), W - s(60), s(16),
        s(30), s(174), s(140), s(32), s(22),
        s(180), s(174), W - s(210), s(32), s(18),
        0, H - s(62), W, s(62),
        s(30), H - s(50), s(180), s(38), s(18),
        W - s(210), H - s(50), s(180), s(38), s(18),
        s(230), H - s(50), s(220), s(38), s(18)
    )

class YouTubeDownloadProgress(Screen):
    skin = _get_progress_skin()

    def __init__(self, session, video_id, video_title, video_url):
        Screen.__init__(self, session)
        self.session = session
        self.video_id = video_id
        self.video_title = video_title
        self.video_url = video_url

        self["title"] = Label(video_title)
        self["status_badge"] = Label("جاري التنزيل...")
        self["filepath"] = Label("")
        self["progress"] = ProgressBar()
        self["percent"] = Label("0%")
        self["stats"] = Label("0.0 MB / 0.0 MB")
        self["key_red"] = StaticText("إلغاء [Red]")
        self["key_blue"] = StaticText("بالخلفية [Blue]")
        self["key_green"] = StaticText("متابعة [OK]")

        self.is_cancelled = False
        self.is_finished = False
        self.downloaded_bytes = 0
        self.total_bytes = 0
        self.start_time = time.time()
        self.filename = ""

        self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
            "cancel": self.runInBackground,
            "red": self.cancelDownload,
            "blue": self.runInBackground,
            "green": self.runInBackground,
            "ok": self.runInBackground
        }, -2)

        self.updateTimer = eTimer()
        try:
            self.updateTimer.callback.append(self.updateUI)
        except Exception:
            self.updateTimer_conn = self.updateTimer.timeout.connect(self.updateUI)
        self.updateTimer.start(300, False)

        self.onLayoutFinish.append(self.startDownloadThread)

    def startDownloadThread(self):
        dest_dir = '/media/hdd/movie'
        if not os.path.exists('/media/hdd'):
            dest_dir = '/media/usb/movie' if os.path.exists('/media/usb') else '/tmp'
        try:
            if not os.path.exists(dest_dir):
                os.makedirs(dest_dir)
        except Exception:
            dest_dir = '/tmp'

        clean_title = "".join(c for c in self.video_title if c.isalnum() or c in (' ', '_', '-', '.', '(', ')')).strip()[:80]
        if not clean_title:
            clean_title = str(self.video_id)
        self.filename = os.path.join(dest_dir, clean_title + '.mp4')
        self["filepath"].setText("المسار: %s" % self.filename)

        def _worker():
            from .compat import compat_urllib
            import socket
            old_to = socket.getdefaulttimeout()
            try:
                socket.setdefaulttimeout(25)
                req = compat_urllib.Request(self.video_url, headers={
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                })
                resp = compat_urllib.urlopen(req)
                cl = resp.headers.get('Content-Length')
                self.total_bytes = int(cl) if cl and cl.isdigit() else 0

                with open(self.filename, 'wb') as f:
                    while not self.is_cancelled:
                        chunk = resp.read(65536)
                        if not chunk:
                            break
                        f.write(chunk)
                        self.downloaded_bytes += len(chunk)

                if self.is_cancelled:
                    if os.path.exists(self.filename):
                        os.remove(self.filename)
                else:
                    self.is_finished = True
                    AddNotification(MessageBox, "YouTube:\nتم اكتمال تنزيل الفيديو بنجاح!\n%s" % clean_title, type=MessageBox.TYPE_INFO, timeout=7)
            except Exception as e:
                print('[YouTube Download Error]', e)
                AddNotification(MessageBox, "YouTube: خطأ أثناء التنزيل!\n%s" % str(e), type=MessageBox.TYPE_ERROR, timeout=7)
            finally:
                socket.setdefaulttimeout(old_to)

        t = Thread(target=_worker)
        t.daemon = True
        t.start()

    def updateUI(self):
        if self.is_finished:
            self.updateTimer.stop()
            self["progress"].setValue(100)
            self["percent"].setText("100%")
            self["status_badge"].setText("✔ اكتمل التنزيل!")
            self.close()
            return

        if self.total_bytes > 0:
            pct = int((float(self.downloaded_bytes) / float(self.total_bytes)) * 100)
            self["progress"].setValue(min(100, pct))
            self["percent"].setText("%d%%" % pct)
            elapsed = time.time() - self.start_time
            speed = (float(self.downloaded_bytes) / (1024 * 1024)) / max(1.0, elapsed)
            dl_mb = float(self.downloaded_bytes) / (1024 * 1024)
            tot_mb = float(self.total_bytes) / (1024 * 1024)
            self["stats"].setText("%.1f MB / %.1f MB  (%.2f MB/s)" % (dl_mb, tot_mb, speed))
        elif self.downloaded_bytes > 0:
            dl_mb = float(self.downloaded_bytes) / (1024 * 1024)
            self["stats"].setText("تم تحميل: %.1f MB" % dl_mb)

    def runInBackground(self):
        self.updateTimer.stop()
        self.close()

    def cancelDownload(self):
        self.is_cancelled = True
        self.updateTimer.stop()
        self.close()
