# coding: utf-8
from __future__ import unicode_literals

import operator
import re

from calendar import timegm
from datetime import timedelta
from datetime import datetime
from email import utils
from itertools import chain
from json import dumps
from json import loads

from .compat import compat_basestring
from .compat import compat_chain_map
from .compat import compat_chr
from .compat import compat_int
from .compat import compat_integer_types
from .compat import compat_map
from .compat import compat_numeric_types
from .compat import compat_str
from .compat import compat_zip_longest

def js_to_json(code):
	COMMENT_RE = r'/\*(?:(?!\*/).)*?\*/|//[^\n]*\n'
	SKIP_RE = r'\s*(?:{comment})?\s*'.format(comment=COMMENT_RE)

	def fix_kv(m):
		v = m.group(0)
		if v in ('true', 'false', 'null'):
			return v
		elif v in ('undefined', 'void 0'):
			return 'null'
		elif v.startswith('/*') or v.startswith('//') or v.startswith('!') or v == ',':
			return ''

		if v[0] in ("'", '"'):
			v = re.sub(r'(?s)\\.|"', lambda m: {
				'"': '\\"',
				"\\'": "'",
				'\\\n': '',
				'\\x': '\\u00',
			}.get(m.group(0), m.group(0)), v[1:-1])
			return '"%s"' % v

		raise ValueError('Unknown value:', v)

	pattern = r'(?sx)"(?:[^"\\]*(?:\\\\|\\['"'"'"nurtbfx/\n]))*[^"\\]*"|' + 		r"'(?:[^'\\]*(?:\\\\|\\['"'"'"nurtbfx/\n]))*[^'\\]*'|" + 		r'{comment}|,(?={skip}[\]}}])|' + 		r'(?:(?<![0-9])[eE]|[a-df-zA-DF-Z_])[.a-zA-Z_0-9]*|' + 		r'\b(?:0[xX][0-9a-fA-F]+|0+[0-7]+)(?:{skip}:)?|' + 		r'[0-9]+(?={skip}:)|!+'
	return re.sub(pattern.format(comment=COMMENT_RE, skip=SKIP_RE), fix_kv, code)

class JSUndefined(): pass
class JSBreak(Exception): pass
class JSContinue(Exception): pass
class JSThrow(Exception): pass

class LocalNameSpace(compat_chain_map):
	def __getitem__(self, key):
		try: return super(LocalNameSpace, self).__getitem__(key)
		except KeyError: return JSUndefined
	def __setitem__(self, key, value):
		for scope in self.maps:
			if key in scope:
				scope[key] = value
				return
		self.maps[0][key] = value

class JSInterpreter(object):
	def __init__(self, code, objects=None):
		self.code, self._functions = code, {}
		self._objects = {} if objects is None else objects
	def extract_function_code(self, funcname):
		func_m = re.search(r'(?xs)function\s+' + re.escape(funcname) + r'\s*\((?P<args>[^)]*)\)\s*(?P<code>{.+})', self.code)
		if func_m is None: return [], ""
		return [x.strip() for x in func_m.group('args').split(',') if x.strip()], func_m.group('code')
	def extract_function_from_code(self, argnames, code, *global_stack):
		return lambda args: ""
