# -*- coding: utf-8 -*-
"""
YouTubeEasyPlayer - مشغل فيديو خفيف، فائق السرعة، مع تحجيم تلقائي ديناميكي كامل وخاصية التنزيل للهارد
"""

from __future__ import print_function
import os
from threading import Thread
from enigma import eServiceReference, eTimer, iPlayableService, getDesktop
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.ProgressBar import ProgressBar

def _get_easy_player_skin():
    dsize = getDesktop(0).size()
    dw = dsize.width() or 1280
    f = (dw / 1280.0) if dw > 0 else 1.0
    def s(v): return int(round(v * f))
    
    W = min(s(1020), dw - s(40))
    H = s(96)
    e_offset = s(116)
    
    p_title_w = s(680)
    p_stat_w = s(220)
    p_prog_w = W - s(40)
    
    f_title = s(20)
    f_stat = s(18)
    f_time = s(17)
    f_hints = s(15)
    
    return """
    <screen name="YouTubeEasyPlayer" position="center,e-%d" size="%d,%d" flags="wfNoBorder" zPosition="50">
        <eLabel position="0,0" size="%d,%d" backgroundColor="#12151c" zPosition="0" />
        <eLabel position="0,0" size="%d,%d" backgroundColor="#ff2d2d" zPosition="1" />
        
        <widget name="title" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#ffffff" backgroundColor="#12151c" transparent="1" valign="center" halign="left" zPosition="2" />
        <widget name="status" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#ff2d2d" backgroundColor="#12151c" transparent="1" valign="center" halign="right" zPosition="2" />
        
        <widget name="progress" position="%d,%d" size="%d,%d" zPosition="2" foregroundColor="#ff2d2d" backgroundColor="#2c3342" />
        
        <widget name="time_elapsed" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#ffffff" backgroundColor="#12151c" transparent="1" valign="center" halign="left" zPosition="2" />
        <widget name="help_hints" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#8892a4" backgroundColor="#12151c" transparent="1" valign="center" halign="center" zPosition="2" />
        <widget name="time_total" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#a0aab8" backgroundColor="#12151c" transparent="1" valign="center" halign="right" zPosition="2" />
    </screen>
    """ % (
        e_offset, W, H,
        W, H,
        W, s(3),
        s(20), s(8), p_title_w, s(28), f_title,
        W - p_stat_w - s(20), s(8), p_stat_w, s(28), f_stat,
        s(20), s(42), p_prog_w, s(8),
        s(20), s(58), s(110), s(26), f_time,
        s(135), s(58), W - s(270), s(26), f_hints,
        W - s(130), s(58), s(110), s(26), f_time
    )

class YouTubeEasyPlayer(Screen):
    def __init__(self, session, service, current):
        self.skin = _get_easy_player_skin()
        Screen.__init__(self, session)
        self.session = session
        self.service = service
        self.current = current
        self.video_title = current[3] if len(current) > 3 else "YouTube Video"

        self["title"] = Label(self.video_title)
        self["status"] = Label("▶ تشغيل")
        self["progress"] = ProgressBar()
        self["time_elapsed"] = Label("00:00")
        self["time_total"] = Label("00:00")
        self["help_hints"] = Label("[OK] تشغيل/إيقاف  •  [◀ ▶] 10 ثوانٍ  •  [REC/أزرق] تنزيل للهارد  •  [EXIT] خروج")

        self.is_paused = False
        self.is_osd_visible = True
        self.last_pos = -1

        self["actions"] = ActionMap(["WizardActions", "ColorActions", "DirectionActions", "InfobarSeekActions", "NumberActions", "InfobarActions"], {
            "ok": self.togglePlayPause,
            "playpause": self.togglePlayPause,
            "back": self.exitPlayer,
            "red": self.exitPlayer,
            "cancel": self.exitPlayer,
            "left": self.seekBackward10,
            "right": self.seekForward10,
            "up": self.seekForward60,
            "down": self.seekBackward60,
            "blue": self.downloadToHdd,
            "record": self.downloadToHdd,
            "1": lambda: self.seekRelative(-15),
            "3": lambda: self.seekRelative(15),
            "4": lambda: self.seekRelative(-60),
            "6": lambda: self.seekRelative(60),
            "7": lambda: self.seekRelative(-300),
            "9": lambda: self.seekRelative(300),
            "info": self.toggleOSD,
        }, -1)

        self.progressTimer = eTimer()
        try:
            self.progressTimer.callback.append(self.updateProgress)
        except Exception:
            self.progressTimer_conn = self.progressTimer.timeout.connect(self.updateProgress)
        self.progressTimer.start(1000, False)

        self.hideTimer = eTimer()
        try:
            self.hideTimer.callback.append(self.hideOSD)
        except Exception:
            self.hideTimer_conn = self.hideTimer.timeout.connect(self.hideOSD)
        self.hideTimer.start(3500, True)

        self.onLayoutFinish.append(self.startPlayback)
        self.onClose.append(self.cleanup)

    def startPlayback(self):
        self.session.nav.playService(self.service)

    def togglePlayPause(self):
        service = self.session.nav.getCurrentService()
        pauseable = service and service.pause()
        if pauseable:
            if self.is_paused:
                pauseable.unpause()
                self.is_paused = False
                self["status"].setText("▶ تشغيل")
                self.showOSD(autohide=True)
            else:
                pauseable.pause()
                self.is_paused = True
                self["status"].setText("⏸ إيقاف مؤقت")
                self.showOSD(autohide=False)

    def seekRelative(self, seconds):
        service = self.session.nav.getCurrentService()
        seek = service and service.seek()
        if seek:
            pts_offset = seconds * 90000
            seek.seekRelative(1 if seconds >= 0 else -1, abs(pts_offset))
            self["status"].setText(("+%d ث" if seconds > 0 else "-%d ث") % abs(seconds))
            self.showOSD(autohide=True)
            self.updateProgress(force=True)

    def seekForward10(self): self.seekRelative(10)
    def seekBackward10(self): self.seekRelative(-10)
    def seekForward60(self): self.seekRelative(60)
    def seekBackward60(self): self.seekRelative(-60)

    # التنزيل المباشر مع شريط التقدم الفعلي
    def downloadToHdd(self):
        video_id = self.current[0] if len(self.current) > 0 else ""
        if not video_id: return
        video_title = self.video_title

        try:
            from .YouTubeVideoUrl import YouTubeVideoUrl
            ytdl = YouTubeVideoUrl()
            video_url = ytdl.extract(video_id)
        except Exception:
            video_url = None

        if not video_url:
            self["status"].setText("✖ خطأ في الرابط")
            self.showOSD(autohide=True)
            return

        from .YouTubeDownloadProgress import YouTubeDownloadProgress
        self.session.open(YouTubeDownloadProgress, video_id=video_id, video_title=video_title, video_url=video_url)

    def toggleOSD(self):
        if self.is_osd_visible: self.hideOSD()
        else: self.showOSD(autohide=True)

    def showOSD(self, autohide=True):
        self.show()
        self.is_osd_visible = True
        self.hideTimer.stop()
        self.updateProgress(force=True)
        if autohide and not self.is_paused:
            self.hideTimer.start(3500, True)

    def hideOSD(self):
        if not self.is_paused:
            self.hide()
            self.is_osd_visible = False

    def updateProgress(self, force=False):
        if not self.is_osd_visible and not force: return
        service = self.session.nav.getCurrentService()
        seek = service and service.seek()
        if seek:
            pos = seek.getPlayPosition()
            length = seek.getLength()
            if pos[0] == 0 and length[0] == 0:
                pos_sec = pos[1] // 90000
                len_sec = length[1] // 90000
                if len_sec > 0 and (pos_sec != self.last_pos or force):
                    self.last_pos = pos_sec
                    pct = int((pos_sec * 100) / float(len_sec))
                    self["progress"].setValue(pct)
                    self["time_elapsed"].setText(self.formatTime(pos_sec))
                    self["time_total"].setText(self.formatTime(len_sec))

    @staticmethod
    def formatTime(seconds):
        m, s = divmod(seconds, 60)
        h, m = divmod(m, 60)
        if h > 0: return "%d:%02d:%02d" % (h, m, s)
        return "%02d:%02d" % (m, s)

    def exitPlayer(self):
        self.session.nav.stopService()
        self.close()

    def cleanup(self):
        try:
            self.progressTimer.stop()
            self.hideTimer.stop()
        except Exception: pass
