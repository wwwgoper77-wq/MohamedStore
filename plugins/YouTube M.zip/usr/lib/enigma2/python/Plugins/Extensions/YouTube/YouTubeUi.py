# -*- coding: utf-8 -*-
from __future__ import print_function

import os
from copy import copy
from threading import Thread

from enigma import eServiceReference, eTimer, iPlayableService
from Components.ActionMap import ActionMap
from Components.config import config, ConfigDirectory, ConfigSelection, \
	ConfigSet, ConfigSubDict, ConfigSubsection, ConfigText, ConfigYesNo
from Components.ConfigList import ConfigListScreen
from Components.Converter.TemplatedMultiContent import TemplatedMultiContent
from Components.Label import Label
from Components.Language import language
from Components.Pixmap import Pixmap
from Components.PluginComponent import plugins
from Components.ScrollLabel import ScrollLabel
from Components.ServiceEventTracker import ServiceEventTracker
from Components.Sources.List import List
from Components.Sources.StaticText import StaticText
from Components.Task import job_manager
from Plugins.Plugin import PluginDescriptor
from Screens.ChoiceBox import ChoiceBox
from Screens.InfoBar import InfoBar, MoviePlayer
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Tools.BoundFunction import boundFunction
from Tools.Directories import resolveFilename, SCOPE_HDD, SCOPE_PLUGINS
from Tools.LoadPixmap import LoadPixmap

from .compat import compat_urlretrieve, compat_urllib, SUBURI
from . import _, screenwidth, ngettext
from .YouTubeEasyPlayer import YouTubeEasyPlayer
from .YouTubeKeyboard import YouTubeKeyBoard

ERROR_WARNING = _('There was an error!')
YT_TITLE = _('What do you want to do?')

try:
	from Tools.CountryCodes import ISO3166
except ImportError:
	ISO3166 = [(x[1][0], x[1][2]) for x in language.getLanguageList() if x[1][2] != 'EN']

def DreamOS():
	if os.path.exists('/var/lib/dpkg/status'):
		return DreamOS

def default_language():
	lang = language.getLanguage().split('_')
	if len(lang) > 1:
		if lang[1] == 'EN':
			lang[1] = ''
		return lang
	return ['', '']

config.plugins.YouTube = ConfigSubsection()
config.plugins.YouTube.update = ConfigYesNo(default=False)
config.plugins.YouTube.saveHistory = ConfigYesNo(default=True)
config.plugins.YouTube.searchResult = ConfigSelection(default='24', choices=[('4', '4'), ('8', '8'), ('16', '16'), ('24', '24'), ('50', '50')])
config.plugins.YouTube.searchRegion = ConfigSelection(default=default_language()[1], choices=[('', _('All'))] + [(x[1], x[0]) for x in ISO3166])
config.plugins.YouTube.searchLanguage = ConfigSelection(default=default_language()[0], choices=[('', _('All'))] + [(x[1][1], x[1][0]) for x in language.getLanguageList()])
config.plugins.YouTube.searchOrder = ConfigSelection(default='relevance', choices=[('relevance', _('Relevance')), ('date', _('Created date')), ('rating', _('Rating')), ('title', _('Title')), ('viewCount', _('View count'))])
config.plugins.YouTube.subscriptOrder = ConfigSelection(default='relevance', choices=[('relevance', _('By relevance')), ('unread', _('By activity')), ('alphabetical', _('Alphabetically'))])
config.plugins.YouTube.safeSearch = ConfigSelection(default='moderate', choices=[('moderate', _('Moderate')), ('none', _('No')), ('strict', _('Yes'))])
config.plugins.YouTube.maxResolution = ConfigSelection(default='22', choices=[('38', '4096x3072'), ('37', '1920x1080'), ('22', '1280x720'), ('35', '854x480'), ('18', '640x360'), ('5', '400x240'), ('17', '176x144')])
config.plugins.YouTube.onMovieEof = ConfigSelection(default='quit', choices=[('quit', _('Return to list')), ('ask', _('Ask user')), ('playnext', _('Play next')), ('repeat', _('Repeat')), ('playprev', _('Play previous'))])
config.plugins.YouTube.onMovieStop = ConfigSelection(default='quit', choices=[('quit', _('Return to list')), ('ask', _('Ask user'))])
config.plugins.YouTube.VirtualKeyBoard = ConfigSelection(default='YouTube', choices=[('YouTube', _('YouTube VirtualKeyBoard')), ('Image', _('Image VirtualKeyBoard'))])
config.plugins.YouTube.login = ConfigYesNo(default=False)
config.plugins.YouTube.downloadDir = ConfigDirectory(default=resolveFilename(SCOPE_HDD))
config.plugins.YouTube.useDashMP4 = ConfigYesNo(default=False)
config.plugins.YouTube.mergeFiles = ConfigYesNo(default=False)

if DreamOS():
    config.plugins.YouTube.player = ConfigSelection(default='4097', choices=[('4097', _('Default (4097)')), ('8193', _('DreamOS GstPlayer (8193)'))])
else:
    config.plugins.YouTube.player = ConfigSelection(default='4097', choices=[('4097', _('Default')), ('5002', _('ExtePlayer')), ('5001', _('GstPlayer'))])

config.plugins.YouTube.searchHistoryDict = ConfigSubDict()
config.plugins.YouTube.searchHistoryDict['Searchvideo'] = ConfigSet(choices=[])
config.plugins.YouTube.searchHistoryDict['Searchchannel'] = ConfigSet(choices=[])
config.plugins.YouTube.searchHistoryDict['Searchplaylist'] = ConfigSet(choices=[])
config.plugins.YouTube.searchHistoryDict['Searchbroadcasts'] = ConfigSet(choices=[])
config.plugins.YouTube.refreshToken = ConfigText()
config.plugins.YouTube.lastPosition = ConfigText(default='[]')

FLAGS = ', flags=BT_SCALE'
try:
	TemplatedMultiContent('{"template": [MultiContentEntryPixmapAlphaTest(flags=BT_SCALE)], "fonts": [gFont("Regular",20)], "itemHeight": 72}')
except Exception:
	FLAGS = ''

def _yt_factor():
	if screenwidth == 'svg':
		return 1.0
	if isinstance(screenwidth, int) and screenwidth > 0:
		return screenwidth / 1280.0
	return 1.0

def _yf(value):
	return int(round(value * _yt_factor()))

def _ytmain_skin():
	C_BG = '#0d0f13'
	C_ACCENT = '#ff2d2d'
	C_BRAND = '#d4af37'
	C_TEXT = '#ffffff'
	C_BAR = '#1b1f27'

	W = _yf(960)
	H = _yf(700)
	margin = _yf(15)
	list_x = margin
	list_w = W - 2 * margin
	brand_y = _yf(12)
	brand_h = _yf(28)
	sb_x = margin
	sb_y = _yf(48)
	sb_h = _yf(46)
	sb_w = list_w
	list_y = sb_y + sb_h + _yf(8)
	btn_h = _yf(96)
	list_h = H - list_y - btn_h

	th_w = _yf(240)
	th_h = _yf(135)
	th_x = _yf(12)
	th_y = _yf(8)
	title_x = th_x + th_w + _yf(16)
	title_y = _yf(10)
	title_w = list_w - title_x - _yf(16)
	title_h = _yf(52)
	chan_y = title_y + title_h + _yf(4)
	chan_h = _yf(24)
	meta_y = chan_y + chan_h + _yf(8)
	meta_h = _yf(24)
	item_h = _yf(150)
	f_title = _yf(22)
	f_meta = _yf(17)

	template = ('<convert type="TemplatedMultiContent" >'
		'{"template": ['
		'MultiContentEntryPixmapAlphaTest(pos=(%d,%d), size=(%d,%d), png=2%s),'
		'MultiContentEntryText(pos=(%d,%d), size=(%d,%d), font=0, flags=RT_HALIGN_LEFT|RT_VALIGN_TOP, text=3),'
		'MultiContentEntryText(pos=(%d,%d), size=(%d,%d), font=1, flags=RT_HALIGN_LEFT, text=4),'
		'MultiContentEntryText(pos=(%d,%d), size=(%d,%d), font=1, flags=RT_HALIGN_LEFT, text=5)'
		'], "fonts": [gFont("Regular",%d), gFont("Regular",%d)], "itemHeight": %d}'
		'</convert>') % (
			th_x, th_y, th_w, th_h, FLAGS,
			title_x, title_y, title_w, title_h,
			title_x, chan_y, _yf(350), chan_h,
			title_x, meta_y, _yf(450), meta_h,
			f_title, f_meta, item_h)

	bar_y = H - btn_h + _yf(8)
	btn_w = _yf(135)
	btn_bh = _yf(44)
	gap = _yf(12)
	total_btns_w = 4 * btn_w + 3 * gap
	red_x = (W - total_btns_w) // 2
	green_x = red_x + btn_w + gap
	yellow_x = green_x + btn_w + gap
	blue_x = yellow_x + btn_w + gap
	f_btn = _yf(20)

	p = []
	p.append('<screen position="center,center" size="%d,%d" title=" " flags="wfNoBorder">' % (W, H))
	p.append('<eLabel position="0,0" size="%d,%d" backgroundColor="%s" zPosition="0" />' % (W, H, C_BG))
	p.append('<eLabel position="0,0" size="%d,%d" backgroundColor="%s" zPosition="1" />' % (W, _yf(6), C_ACCENT))
	p.append('<eLabel text="YouTube" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" halign="left" valign="center" zPosition="2" />' % (margin, brand_y, _yf(160), brand_h, _yf(24), C_ACCENT, C_BG))
	p.append('<eLabel text="هذا البلجن متاح في بنل MohamedStore" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" halign="right" valign="center" zPosition="2" />' % (W - margin - _yf(520), brand_y, _yf(520), brand_h, _yf(19), C_BRAND, C_BG))
	p.append('<eLabel position="%d,%d" size="%d,%d" backgroundColor="%s" zPosition="2" />' % (sb_x, sb_y, sb_w, sb_h, C_BRAND))
	p.append('<eLabel position="%d,%d" size="%d,%d" backgroundColor="%s" zPosition="3" />' % (sb_x + _yf(2), sb_y + _yf(2), sb_w - _yf(4), sb_h - _yf(4), C_BAR))
	p.append('<eLabel text="Q" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" halign="center" valign="center" zPosition="4" />' % (sb_x + _yf(10), sb_y + _yf(2), _yf(34), sb_h - _yf(4), _yf(22), C_ACCENT, C_BAR))
	p.append('<widget source="searchbar" render="Label" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" valign="center" halign="left" zPosition="4" />' % (sb_x + _yf(50), sb_y + _yf(2), sb_w - _yf(140), sb_h - _yf(4), _yf(21), C_TEXT, C_BAR))
	p.append('<widget source="key_yellow" render="Label" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" valign="center" halign="right" zPosition="4" />' % (sb_x + sb_w - _yf(96), sb_y + _yf(2), _yf(86), sb_h - _yf(4), _yf(20), C_BRAND, C_BAR))
	p.append('<widget source="list" render="Listbox" position="%d,%d" size="%d,%d" scrollbarMode="showOnDemand" transparent="1" zPosition="2" >%s</widget>' % (list_x, list_y, list_w, list_h, template))
	p.append('<widget source="key_red" render="Label" position="%d,%d" zPosition="4" size="%d,%d" valign="center" halign="center" font="Regular;%d" backgroundColor="#ff2d2d" transparent="0" />' % (red_x, bar_y, btn_w, btn_bh, f_btn))
	p.append('<widget source="key_green" render="Label" position="%d,%d" zPosition="4" size="%d,%d" valign="center" halign="center" font="Regular;%d" backgroundColor="#228b22" transparent="0" />' % (green_x, bar_y, btn_w, btn_bh, f_btn))
	p.append('<widget source="key_yellow" render="Label" position="%d,%d" zPosition="4" size="%d,%d" valign="center" halign="center" font="Regular;%d" backgroundColor="#d4af37" transparent="0" />' % (yellow_x, bar_y, btn_w, btn_bh, f_btn))
	p.append('<widget source="key_blue" render="Label" position="%d,%d" zPosition="4" size="%d,%d" valign="center" halign="center" font="Regular;%d" backgroundColor="#1e60d2" transparent="0" />' % (blue_x, bar_y, btn_w, btn_bh, f_btn))
	p.append('<widget name="thumbnail" position="0,0" size="%d,%d" />' % (th_w, th_h))
	p.append('</screen>')
	return ' '.join(p)

class YouTubeMain(Screen):
	skin = _ytmain_skin()
	SEARCH_HINT = _(u'ابحث في يوتيوب…    /    Search YouTube…')
	KEY_YELLOW = _(u'بحث  Search')
	KEY_BLUE = _(u'تنزيل للهارد')

	def __init__(self, session):
		Screen.__init__(self, session)
		self.skinName = ['YouTubeMainMSV4']
		self.skin = _ytmain_skin()
		self['key_red'] = StaticText('')
		self['key_green'] = StaticText('')
		self['key_yellow'] = StaticText('')
		self['key_blue'] = StaticText('')
		self['searchbar'] = StaticText(self.SEARCH_HINT)
		self.top_mode = 'home'
		self['actions'] = ActionMap(['WizardActions', 'ColorActions', 'MovieSelectionActions', 'InfobarActions'], {
				'back': self.cancel,
				'ok': self.ok,
				'red': self.cancel,
				'green': self.ok,
				'yellow': self.openSearch,
				'blue': self.downloadSelectedVideo,
				'record': self.downloadSelectedVideo,
				'up': self.selectPrevious,
				'down': self.selectNext,
				'contextMenu': self.openMenu}, -2)
		self.title = _('YouTube starting. Please wait...')
		self['list'] = List([])
		self['thumbnail'] = Pixmap()
		self['thumbnail'].hide()
		self.splitTaimer = eTimer()
		try:
			self.splitTaimer.timeout.callback.append(self.splitTaimerStop)
		except Exception:
			self.splitTaimer_conn = self.splitTaimer.timeout.connect(self.splitTaimerStop)
		self.active_downloads = 0
		self.is_auth = False
		self.picloads = {}
		self.search_result = config.plugins.YouTube.searchResult.value
		self.thumbnails = {'default': ''}
		self.use_picload = True
		self.ytapi = None
		self.yts = [{}]
		self.onLayoutFinish.append(self.layoutFinish)
		self.onClose.append(self.cleanVariables)

	def layoutFinish(self):
		if self.use_picload:
			try:
				from Components.AVSwitch import AVSwitch
				self.sc = AVSwitch().getFramebufferScale()
			except Exception:
				self.sc = (1, 1)
		try:
			self.thumb_size = (self['thumbnail'].instance.size().width(), self['thumbnail'].instance.size().height())
		except Exception:
			self.thumb_size = (_yf(240), _yf(135))
		from .YouTubeVideoUrl import YouTubeVideoUrl
		self.ytdl = YouTubeVideoUrl()
		self.createAuth()
		self.loadHome()

	def cleanVariables(self):
		del self.splitTaimer
		del self.picloads
		del self.thumbnails
		del self.ytapi
		del self.ytdl

	def createAuth(self):
		refresh_token = config.plugins.YouTube.refreshToken.value
		if not self.ytapi or (not self.is_auth and refresh_token and config.plugins.YouTube.login.value):
			from .YouTubeApi import YouTubeApi
			self.ytapi = YouTubeApi(refresh_token)
			self.is_auth = self.ytapi.is_auth()

	def _mkframe(self, entry_id, title, list_type):
		return {
			'list': list_type,
			'title': title,
			'index': 0,
			'entry_list': [(entry_id, '', None, title, '', '', None, None, None, '', None, '')]
		}

	def loadHome(self):
		self.top_mode = 'home'
		self['searchbar'].text = self.SEARCH_HINT
		parent = self._mkframe('most_viewed', _('YouTube'), 'feeds')
		self.yts = [{}, parent]
		self.screenCallback(_('YouTube'), 'feeds')

	def openSearch(self):
		self.session.openWithCallback(self.searchKbCallback, YouTubeKeyBoard, text='', title=_('Search YouTube'))

	def searchKbCallback(self, text=None):
		if text: self.doSearch(text)

	def doSearch(self, text):
		if not text: return
		self.top_mode = 'search'
		self.search_result = config.plugins.YouTube.searchResult.value
		self['searchbar'].text = u'%s  «%s»' % (_('Search'), text)
		parent = self._mkframe('Searchvideo', _('Search'), 'search')
		self.yts = [{}, parent]
		self.screenCallback(text, 'search')

	def screenCallback(self, text, action):
		self.yts[0]['title'] = text
		self.yts[0]['list'] = action
		self.title = _('Downloading... Please wait...')
		self['list'].list = []
		self.splitTaimer.start(0, True)

	def splitTaimerStop(self):
		if self.yts[0]['list'] in ('playVideo', 'downloadVideo'):
			self.useVideoUrl()
		else:
			entry_list = self.createEntryList()
			self.showButtons()
			if not entry_list:
				self.session.open(MessageBox, _('There was an error in creating entry list!'), MessageBox.TYPE_INFO, timeout=6)
				self.yts.pop(0)
				self.setEntryList()
			else:
				self.yts[0]['entry_list'] = entry_list
				self.setEntryList()

	def setEntryList(self):
		self.title = self.yts[0].get('title', '')
		self['list'].list = self.yts[0].get('entry_list', [])
		self['list'].index = self.yts[0].get('index', 0)
		self._thumb_queue = [entry[0] for entry in self.yts[0].get('entry_list', []) if not entry[2]]
		self._startThumbTimer()

	def _startThumbTimer(self):
		if not hasattr(self, 'thumbTimer'):
			self.thumbTimer = eTimer()
			try: self.thumbTimer.timeout.callback.append(self._processThumbQueue)
			except Exception: self.thumbTimer_conn = self.thumbTimer.timeout.connect(self._processThumbQueue)
		if getattr(self, '_thumb_queue', None):
			self.thumbTimer.start(60, True)

	def _processThumbQueue(self):
		if not getattr(self, '_thumb_queue', None): return
		entry_id = self._thumb_queue.pop(0)
		entry = None
		for e in self.yts[0].get('entry_list', []):
			if e[0] == entry_id:
				entry = e
				break
		if entry is not None and not entry[2]:
			self._loadThumb(entry)
		if self._thumb_queue:
			self.thumbTimer.start(60, True)

	def _loadThumb(self, entry):
		entry_id = entry[0]
		if entry_id in self.thumbnails:
			self.updateThumbnails(entry_id)
			return
		url = entry[1]
		if not url: return
		def _bgFetch():
			import socket
			old_to = socket.getdefaulttimeout()
			try:
				socket.setdefaulttimeout(4)
				compat_urlretrieve(url, '/tmp/%s.jpg' % str(entry_id))
			except Exception: pass
			else: self.decodeThumbnail(entry_id, '/tmp/%s.jpg' % str(entry_id))
			finally: socket.setdefaulttimeout(old_to)
		t = Thread(target=_bgFetch)
		t.daemon = True
		t.start()

	def decodeThumbnail(self, entry_id, image=None):
		if not image or not os.path.exists(image): return
		try:
			pixmap = LoadPixmap(image)
			if pixmap:
				self.thumbnails[entry_id] = pixmap
				self.updateThumbnails(entry_id, True)
			os.remove(image)
		except Exception as e:
			print('[YouTube] Decode error:', e)

	def updateThumbnails(self, entry_id, delete=False):
		for idx, entry in enumerate(self.yts[0].get('entry_list', [])):
			if entry[0] == entry_id and entry_id in self.thumbnails:
				thumbnail = self.thumbnails[entry_id]
				self.yts[0]['entry_list'][idx] = (
					entry[0], entry[1], copy(thumbnail), entry[3], entry[4], entry[5],
					entry[6], entry[7], entry[8], entry[9], entry[10], entry[11]
				)
				break
		self['list'].updateList(self.yts[0].get('entry_list', []))

	def showButtons(self):
		self['key_red'].text = _('Exit')
		self['key_green'].text = _('Open')
		self['key_yellow'].text = self.KEY_YELLOW
		self['key_blue'].text = self.KEY_BLUE

	def selectNext(self):
		if self['list'].index + 1 < self['list'].count(): self['list'].selectNext()
		else: self['list'].index = 0

	def selectPrevious(self):
		if self['list'].index > 0: self['list'].selectPrevious()
		else: self['list'].index = max(0, self['list'].count() - 1)

	def cancel(self):
		if len(self.yts) <= 2:
			if self.top_mode == 'search': self.loadHome()
			else: self.close()
		else:
			self.yts.pop(0)
			self.setEntryList()

	def ok(self):
		current = self['list'].getCurrent()
		if current and current[0]:
			if current[0] == '__next_page__':
				next_token = current[5]
				self.loadMoreResults(next_token)
				return
			self.yts[0]['index'] = self['list'].index
			self.yts.insert(0, {})
			if self.yts[1]['list'] == 'videolist':
				self.screenCallback('', 'playVideo')
			else:
				self.screenCallback(current[3], self.yts[1]['list'])

	def loadMoreResults(self, next_token):
		if not next_token: return
		self.title = _(u'جاري تحميل المزيد من الفيديوهات...')
		current_list = list(self.yts[0].get('entry_list', []))
		if current_list and current_list[-1][0] == '__next_page__': current_list.pop()
		def _fetchMore():
			try:
				q = self.yts[0].get('title', '') if self.top_mode == 'search' else ''
				order = config.plugins.YouTube.searchOrder.value if self.top_mode == 'search' else 'viewCount'
				search_response = self.ytapi.search_list_full(
					safe_search=config.plugins.YouTube.safeSearch.value,
					order=order,
					part='id,snippet',
					q=q,
					relevance_language=config.plugins.YouTube.searchLanguage.value,
					s_type='video',
					region_code=config.plugins.YouTube.searchRegion.value,
					max_results=self.search_result,
					page_token=next_token
				)
				videos = [res['id']['videoId'] for res in search_response.get('items', []) if 'videoId' in res.get('id', {})]
				if not videos: return
				new_next = search_response.get('nextPageToken', '')
				v_res = self.ytapi.videos_list(v_id=','.join(videos[:50]))
				new_items = []
				for res in v_res.get('items', []):
					title = res['snippet'].get('title', '')
					dur_raw = res['contentDetails'].get('duration', '')
					duration = self._convertDate(dur_raw)
					views = res['statistics'].get('viewCount', '')
					try:
						v_int = int(views)
						if v_int >= 1000000: views = '%.1fM views' % (v_int / 1000000.0)
						elif v_int >= 1000: views = '%.1fK views' % (v_int / 1000.0)
						else: views = '%d views' % v_int
					except Exception: views += ' views'
					channel = res['snippet'].get('channelTitle', '')
					published = res['snippet'].get('publishedAt', '')[:10]
					thumb = res['snippet']['thumbnails'].get('medium', {}).get('url', '')
					new_items.append((res.get('id'), thumb, None, title, channel, '%s  |  %s  |  %s' % (duration, views, published), None, channel, '', thumb, '', published))
				if new_next:
					next_title = _(u'»» المزيد من النتائج...  Next Page »»')
					next_meta = _(u'اضغط [OK] لعرض المزيد من نتائج البحث')
					new_items.append(('__next_page__', '', None, next_title, next_meta, new_next, None, '', '', '', '', ''))
				combined = current_list + new_items
				self.yts[0]['entry_list'] = combined
				self['list'].list = combined
				self._thumb_queue = [entry[0] for entry in new_items if entry[0] != '__next_page__' and not entry[2]]
				self._startThumbTimer()
				self.title = self.yts[0].get('title', '')
			except Exception as e:
				print('[YouTube LoadMore Error]', e)
		t = Thread(target=_fetchMore)
		t.daemon = True
		t.start()

	def useVideoUrl(self):
		current = self.yts[1]['entry_list'][self.yts[1]['index']]
		video_id = current[0]
		video_url = None
		try:
			video_url = self.ytdl.extract(video_id, self.ytapi.get_yt_auth())
		except Exception as e:
			print('[YouTube] Error in extract info:', e)
		if not video_url:
			self.session.open(MessageBox, _('There was an error in extract video url!\nVideo Id: %s') % str(video_id), MessageBox.TYPE_INFO, timeout=8)
			self.yts.pop(0)
			self.setEntryList()
		else:
			if hasattr(self, 'thumbTimer'): self.thumbTimer.stop()
			service = eServiceReference(int(config.plugins.YouTube.player.value), 0, video_url)
			service.setName(current[3])
			self.session.openWithCallback(self.playCallback, YouTubeEasyPlayer, service=service, current=current)

	def playCallback(self, action=None):
		self.yts.pop(0)
		self.setEntryList()

	# خاصية تنزيل الفيديو المباشر إلى الهارد ديسك مع شريط التقدم الفعلي
	def downloadSelectedVideo(self):
		current = self['list'].getCurrent()
		if not current or not current[0] or current[0] == '__next_page__':
			return
		video_id = current[0]
		video_title = current[3] if len(current) > 3 else "Video"

		auth = self.ytapi.get_yt_auth() if self.ytapi else None
		try:
			video_url = self.ytdl.extract(video_id, auth)
		except Exception as e:
			video_url = None

		if not video_url:
			self.session.open(MessageBox, _('There was an error in extract video url!'), MessageBox.TYPE_INFO, timeout=5)
			return

		# تشغيل شاشة شريط التقدم الفعلي المتحرك
		from .YouTubeDownloadProgress import YouTubeDownloadProgress
		self.session.open(YouTubeDownloadProgress, video_id=video_id, video_title=video_title, video_url=video_url)

	@staticmethod
	def _convertDate(duration):
		if not duration or duration == 'P0D': return 'Live'
		time = ':' + duration.replace('P', '').replace('W', '-').replace('D', ' ').replace('T', '').replace('H', ':').replace('M', ':').replace('S', '')
		if 'S' not in duration: time += '00'
		elif time[-2] == ':': time = time[:-1] + '0' + time[-1]
		if 'M' not in duration: time = time[:-2] + '00' + time[-3:]
		elif time[-5] == ':': time = time[:-4] + '0' + time[-4:]
		return time[1:]

	def createEntryList(self):
		current = self.yts[1]['entry_list'][self.yts[1]['index']][0]
		order = 'viewCount'
		q = ''
		if self.yts[0]['list'] == 'search':
			order = config.plugins.YouTube.searchOrder.value
			q = self.yts[0]['title']
		search_response = self.ytapi.search_list_full(
			safe_search=config.plugins.YouTube.safeSearch.value,
			order=order,
			part='id,snippet',
			q=q,
			relevance_language=config.plugins.YouTube.searchLanguage.value,
			s_type='video',
			region_code=config.plugins.YouTube.searchRegion.value,
			max_results=self.search_result,
			page_token=''
		)
		videos = [res['id']['videoId'] for res in search_response.get('items', []) if 'videoId' in res.get('id', {})]
		if not videos: return None
		self.yts[0]['list'] = 'videolist'
		next_token = search_response.get('nextPageToken', '')
		v_res = self.ytapi.videos_list(v_id=','.join(videos[:50]))
		video_list = []
		for res in v_res.get('items', []):
			title = res['snippet'].get('title', '')
			dur_raw = res['contentDetails'].get('duration', '')
			duration = self._convertDate(dur_raw)
			views = res['statistics'].get('viewCount', '')
			try:
				v_int = int(views)
				if v_int >= 1000000: views = '%.1fM views' % (v_int / 1000000.0)
				elif v_int >= 1000: views = '%.1fK views' % (v_int / 1000.0)
				else: views = '%d views' % v_int
			except Exception: views += ' views'
			channel = res['snippet'].get('channelTitle', '')
			published = res['snippet'].get('publishedAt', '')[:10]
			thumb = res['snippet']['thumbnails'].get('medium', {}).get('url', '')
			video_list.append((res.get('id'), thumb, None, title, channel, '%s  |  %s  |  %s' % (duration, views, published), None, channel, '', thumb, '', published))
		if next_token:
			next_title = _(u'»» المزيد من النتائج...  Next Page »»')
			next_meta = _(u'اضغط [OK] لعرض المزيد من نتائج البحث')
			video_list.append(('__next_page__', '', None, next_title, next_meta, next_token, None, '', '', '', '', ''))
		return video_list

	def openMenu(self): pass
