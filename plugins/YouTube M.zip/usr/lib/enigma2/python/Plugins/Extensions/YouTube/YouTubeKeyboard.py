# -*- coding: utf-8 -*-
from __future__ import print_function

from enigma import ePoint, eSize
from Screens.Screen import Screen
from Components.Label import Label
from Components.ActionMap import ActionMap
from Components.Sources.StaticText import StaticText

from . import _, screenwidth

ACT_LANG = u'\x01'
ACT_SHIFT = u'\x02'
ACT_SPACE = u'\x03'
ACT_DEL = u'\x04'
ACT_CLEAR = u'\x05'
ACT_OK = u'\x06'

EN_LOWER = [
	[u'1', u'2', u'3', u'4', u'5', u'6', u'7', u'8', u'9', u'0', u'-', u'_'],
	[u'q', u'w', u'e', u'r', u't', u'y', u'u', u'i', u'o', u'p', u'@', u'.'],
	[u'a', u's', u'd', u'f', u'g', u'h', u'j', u'k', u'l', u',', u'!', u'?'],
	[u'z', u'x', u'c', u'v', u'b', u'n', u'm', u'(', u')', u':', u';', u'/'],
]

EN_UPPER = [
	[u'1', u'2', u'3', u'4', u'5', u'6', u'7', u'8', u'9', u'0', u'=', u'+'],
	[u'Q', u'W', u'E', u'R', u'T', u'Y', u'U', u'I', u'O', u'P', u'#', u'*'],
	[u'A', u'S', u'D', u'F', u'G', u'H', u'J', u'K', u'L', u'"', u"'", u'&'],
	[u'Z', u'X', u'C', u'V', u'B', u'N', u'M', u'<', u'>', u'{', u'}', u'|'],
]

AR_LAYOUT = [
	[u'\u0661', u'\u0662', u'\u0663', u'\u0664', u'\u0665', u'\u0666', u'\u0667', u'\u0668', u'\u0669', u'\u0660', u'-', u'_'],
	[u'\u0636', u'\u0635', u'\u062b', u'\u0642', u'\u0641', u'\u063a', u'\u0639', u'\u0647', u'\u062e', u'\u062d', u'\u062c', u'\u062f'],
	[u'\u0634', u'\u0633', u'\u064a', u'\u0628', u'\u0644', u'\u0627', u'\u062a', u'\u0646', u'\u0645', u'\u0643', u'\u0637', u'\u0626'],
	[u'\u0621', u'\u0624', u'\u0631', u'\u0644\u0627', u'\u0649', u'\u0629', u'\u0648', u'\u0632', u'\u0638', u'\u0630', u'\u0622', u'\u0623'],
]

FUNCTION_ROW = [
	(u'ENG / \u0639\u0631\u0628\u064a', ACT_LANG),
	(u'\u2191 Shift', ACT_SHIFT),
	(u'\u2423 Space', ACT_SPACE),
	(u'\u232b Del', ACT_DEL),
	(u'Clear', ACT_CLEAR),
	(u'\u2714 OK', ACT_OK),
]

LETTER_ROWS = 4
LETTER_COLS = 12
FUNC_COLS = 6

def _f(value):
	if screenwidth == 'svg':
		factor = 1.0
	elif isinstance(screenwidth, int) and screenwidth > 0:
		factor = screenwidth / 1280.0
	else:
		factor = 1.0
	return int(round(value * factor))

class YouTubeKeyBoard(Screen):
	C_BG = '#101216'
	C_PANEL = '#1b1e24'
	C_KEY = '#2b2f37'
	C_FUNC = '#3a2326'
	C_SEL = '#ff2d2d'
	C_TEXT = '#ffffff'
	C_ACCENT = '#ff2d2d'
	C_BRAND = '#d4af37'

	def __init__(self, session, text='', title=None):
		Screen.__init__(self, session)
		self.session = session
		self.lang = 'en'
		self.shift = False
		self.text = text or ''
		self.sel = (1, 0)
		self.keyPos = {}

		scr_w = _f(1180)
		pad = _f(24)
		area_x = pad
		area_w = scr_w - 2 * pad
		hdr_y = _f(18)
		hdr_h = _f(40)
		inp_y = hdr_y + hdr_h + _f(8)
		inp_h = _f(56)
		gap = _f(8)
		cell_w = (area_w - (LETTER_COLS - 1) * gap) // LETTER_COLS
		cell_h = _f(70)
		grid_y = inp_y + inp_h + _f(18)
		func_y = grid_y + LETTER_ROWS * (cell_h + gap) + _f(10)
		func_h = _f(72)
		func_w = (area_w - (FUNC_COLS - 1) * gap) // FUNC_COLS
		brand_y = func_y + func_h + _f(10)
		brand_h = _f(30)
		scr_h = brand_y + brand_h + _f(16)

		font_key = _f(26)
		font_func = _f(22)
		font_hdr = _f(26)
		font_inp = _f(30)
		font_brand = _f(20)

		parts = []
		parts.append('<screen position="center,center" size="%d,%d" title=" " flags="wfNoBorder">' % (scr_w, scr_h))
		parts.append('<eLabel position="0,0" size="%d,%d" backgroundColor="%s" zPosition="0" />' % (scr_w, scr_h, self.C_BG))
		parts.append('<eLabel position="0,0" size="%d,%d" backgroundColor="%s" zPosition="1" />' % (scr_w, _f(6), self.C_ACCENT))
		parts.append('<widget name="headline" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" halign="left" valign="center" zPosition="2" />' % (area_x, hdr_y, area_w, hdr_h, font_hdr, self.C_TEXT, self.C_BG))
		parts.append('<eLabel position="%d,%d" size="%d,%d" backgroundColor="%s" zPosition="1" />' % (area_x, inp_y, area_w, inp_h, self.C_PANEL))
		parts.append('<widget name="textinput" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" halign="left" valign="center" zPosition="2" />' % (area_x + _f(14), inp_y, area_w - _f(28), inp_h, font_inp, self.C_TEXT, self.C_PANEL))
		parts.append('<widget name="sel" position="%d,%d" size="%d,%d" backgroundColor="%s" zPosition="3" />' % (area_x, grid_y, cell_w, cell_h, self.C_SEL))

		for r in range(LETTER_ROWS):
			y = grid_y + r * (cell_h + gap)
			for c in range(LETTER_COLS):
				x = area_x + c * (cell_w + gap)
				self.keyPos[(r, c)] = (x, y, cell_w, cell_h)
				parts.append('<widget name="k_%d_%d" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="0" halign="center" valign="center" zPosition="4" />' % (r, c, x + _f(4), y + _f(4), cell_w - _f(8), cell_h - _f(8), font_key, self.C_TEXT, self.C_KEY))

		fr = LETTER_ROWS
		for c in range(FUNC_COLS):
			x = area_x + c * (func_w + gap)
			self.keyPos[(fr, c)] = (x, func_y, func_w, func_h)
			parts.append('<widget name="k_%d_%d" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="0" halign="center" valign="center" zPosition="4" />' % (fr, c, x + _f(4), func_y + _f(4), func_w - _f(8), func_h - _f(8), font_func, self.C_TEXT, self.C_FUNC))

		parts.append('<widget name="brand" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" halign="center" valign="center" zPosition="2" />' % (area_x, brand_y, area_w, brand_h, font_brand, self.C_BRAND, self.C_BG))
		parts.append('</screen>')
		self.skin = '\n'.join(parts)

		self['headline'] = Label(title or _('Search'))
		self['textinput'] = Label(self.text)
		self['sel'] = Label('')
		self['brand'] = Label(u'MohamedStore')
		for r in range(LETTER_ROWS):
			for c in range(LETTER_COLS):
				self['k_%d_%d' % (r, c)] = Label('')
		fr = LETTER_ROWS
		for c in range(FUNC_COLS):
			self['k_%d_%d' % (fr, c)] = Label('')

		self['actions'] = ActionMap(
			['WizardActions', 'DirectionActions', 'ColorActions', 'InputActions', 'KeyboardInputActions'],
			{
				'ok': self.keyOk,
				'back': self.cancel,
				'left': self.keyLeft,
				'right': self.keyRight,
				'up': self.keyUp,
				'down': self.keyDown,
				'red': self.cancel,
				'green': self.confirm,
				'yellow': self.toggleLang,
				'blue': self.backspace,
			}, -2)

		self.onLayoutFinish.append(self.firstDraw)

	def currentLetters(self):
		if self.lang == 'ar': return AR_LAYOUT
		return EN_UPPER if self.shift else EN_LOWER

	def firstDraw(self):
		self.refreshLabels()
		self.moveSelection()

	def refreshLabels(self):
		letters = self.currentLetters()
		for r in range(LETTER_ROWS):
			for c in range(LETTER_COLS):
				self['k_%d_%d' % (r, c)].setText(letters[r][c])
		fr = LETTER_ROWS
		for c in range(FUNC_COLS):
			self['k_%d_%d' % (fr, c)].setText(FUNCTION_ROW[c][0])
		self['textinput'].setText(self.text)

	def colsForRow(self, r):
		return FUNC_COLS if r == LETTER_ROWS else LETTER_COLS

	def moveSelection(self):
		r, c = self.sel
		if (r, c) not in self.keyPos: return
		x, y, w, h = self.keyPos[(r, c)]
		inst = self['sel'].instance
		if inst:
			inst.move(ePoint(x, y))
			inst.resize(eSize(w, h))

	def keyLeft(self):
		r, c = self.sel
		c = (c - 1) % self.colsForRow(r)
		self.sel = (r, c)
		self.moveSelection()

	def keyRight(self):
		r, c = self.sel
		c = (c + 1) % self.colsForRow(r)
		self.sel = (r, c)
		self.moveSelection()

	def keyUp(self):
		r, c = self.sel
		r = (r - 1) % (LETTER_ROWS + 1)
		c = min(c, self.colsForRow(r) - 1)
		self.sel = (r, c)
		self.moveSelection()

	def keyDown(self):
		r, c = self.sel
		r = (r + 1) % (LETTER_ROWS + 1)
		c = min(c, self.colsForRow(r) - 1)
		self.sel = (r, c)
		self.moveSelection()

	def keyOk(self):
		r, c = self.sel
		if r == LETTER_ROWS:
			self.doAction(FUNCTION_ROW[c][1])
			return
		ch = self.currentLetters()[r][c]
		if ch:
			self.text += ch
			self['textinput'].setText(self.text)

	def doAction(self, token):
		if token == ACT_LANG: self.toggleLang()
		elif token == ACT_SHIFT: self.toggleShift()
		elif token == ACT_SPACE:
			self.text += ' '
			self['textinput'].setText(self.text)
		elif token == ACT_DEL: self.backspace()
		elif token == ACT_CLEAR:
			self.text = ''
			self['textinput'].setText(self.text)
		elif token == ACT_OK: self.confirm()

	def toggleLang(self):
		self.lang = 'ar' if self.lang == 'en' else 'en'
		self.shift = False
		self.refreshLabels()

	def toggleShift(self):
		if self.lang == 'en':
			self.shift = not self.shift
			self.refreshLabels()

	def backspace(self):
		if self.text:
			self.text = self.text[:-1]
			self['textinput'].setText(self.text)

	def confirm(self): self.close(self.text)
	def cancel(self): self.close(None)
