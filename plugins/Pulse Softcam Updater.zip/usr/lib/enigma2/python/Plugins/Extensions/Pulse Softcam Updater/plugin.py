# -*- coding: utf-8 -*-
from Plugins.Plugin import PluginDescriptor
from Screens.MessageBox import MessageBox
from Components.Language import language
import os

# Проверка на езика на системата
system_lang = language.getLanguage()

if system_lang == "bg_BG":
    MSG_SUCCESS = "SoftCam е обновен успешно!"
    MSG_ERROR = "Грешка: Не е намерена папка за инсталация!"
    PLUGIN_NAME = "GamingPulse Softcam Updater"
    PLUGIN_DESC = "Сваля най-новите ключове за OSCam"
else:
    MSG_SUCCESS = "SoftCam updated successfully!"
    MSG_ERROR = "Error: No installation path found!"
    PLUGIN_NAME = "Pulse Softcam Updater"
    PLUGIN_DESC = "Downloads the latest keys for OSCam"

POSSIBLE_PATHS = [
    "/etc/tuxbox/config/oscam-11936-802",
    "/etc/tuxbox/config",
    "/etc/tuxbox/config/oscam",
    "/usr/keys",
    "/var/keys"
]

URL = "https://raw.githubusercontent.com/MOHAMED19OS/SoftCam_Emu/main/SoftCam.Key"

def main(session, **kwargs):
    updated_count = 0
    
    for path in POSSIBLE_PATHS:
        if os.path.exists(path):
            target = os.path.join(path, "SoftCam.Key")
            if os.path.exists(target):
                os.remove(target)
            
            cmd = "wget --no-cache --no-cookies -qO %s %s" % (target, URL)
            res = os.system(cmd)
            if res == 0:
                updated_count += 1
    
    os.system("sync")
    
    if updated_count > 0:
        # Рестартираме OSCam (тихо)
        os.system("/etc/init.d/softcam.oscam-11936-802 restart > /dev/null 2>&1")
        os.system("/etc/init.d/softcam restart > /dev/null 2>&1")
        session.open(MessageBox, MSG_SUCCESS, MessageBox.TYPE_INFO, timeout=3)
    else:
        session.open(MessageBox, MSG_ERROR, MessageBox.TYPE_ERROR, timeout=3)

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name=PLUGIN_NAME,
            description=PLUGIN_DESC,
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="plugin.png",
            fnc=main
        )
    ]