# -*- coding: utf-8 -*-
# ==============================================================================
# Global Enigma2 Converter & Renderer Interceptor (skin_hook.py)
# Compatible with:
#   - Vu+ (VTi, BlackHole, OpenBH, OpenATV, OpenPLi)
#   - Octagon (SF8008, SF4008 - OpenATV, Egami, Define/Enigma2)
#   - Dreambox (DreamOS OE2.5 / OE2.6 DM900, DM920, Dream One/Two & OE2.0)
# هذا البلجن متاح في بنل MohamedStore
# ==============================================================================

import os
from Components.Converter.EventName import EventName
from Components.Converter.ServiceName import ServiceName
from Screens.EventView import EventViewSimple
from enigma import eTimer

_ORIGINAL_EVENT_GET_TEXT = None
_ORIGINAL_SERVICE_GET_TEXT = None
_ACTIVE_CONVERTERS = []
_REFRESH_TIMER = None
_REFRESH_TIMER_CONN = None


def detect_stb_hardware():
    """
    Detects Vu+, Octagon, or Dreambox receiver model across OE-Alliance and DreamOS.
    """
    try:
        if os.path.exists("/proc/stb/info/vumodel"):
            with open("/proc/stb/info/vumodel", "r") as f:
                return "Vu+ " + f.read().strip().upper()
        if os.path.exists("/proc/stb/info/boxtype"):
            with open("/proc/stb/info/boxtype", "r") as f:
                box = f.read().strip()
                if "sf" in box.lower() or "octagon" in box.lower():
                    return "Octagon " + box.upper()
                return box.upper()
        if os.path.exists("/proc/stb/info/model"):
            with open("/proc/stb/info/model", "r") as f:
                model = f.read().strip()
                if "dm" in model.lower() or "dream" in model.lower():
                    return "Dreambox " + model.upper()
                return model.upper()
    except Exception:
        pass
    return "Vu+ / Octagon / Dreambox"


def _schedule_ui_refresh():
    global _REFRESH_TIMER
    if _REFRESH_TIMER is not None:
        try:
            _REFRESH_TIMER.start(250, True)
        except Exception:
            pass


def _perform_converter_refresh():
    dead = []
    for conv in _ACTIVE_CONVERTERS:
        try:
            conv.changed((conv.CHANGED_POLL,))
        except Exception:
            dead.append(conv)
    for d in dead:
        try:
            _ACTIVE_CONVERTERS.remove(d)
        except ValueError:
            pass


def force_refresh_current_screens():
    _perform_converter_refresh()


def install_global_enigma2_hooks(session, engine, cfg):
    """
    Intercepts Components.Converter.EventName and Components.Converter.ServiceName
    across Vu+, Octagon, and Dreambox (both OE2.0 and DreamOS OE2.5/2.6).
    """
    global _ORIGINAL_EVENT_GET_TEXT, _ORIGINAL_SERVICE_GET_TEXT, _REFRESH_TIMER, _REFRESH_TIMER_CONN

    if _REFRESH_TIMER is None:
        _REFRESH_TIMER = eTimer()
        # Dreambox DreamOS (OE2.5 / OE2.6) uses .timeout.connect()
        # Vu+ & Octagon (OE-Alliance / OpenPLi / BlackHole / VTi) use .callback.append()
        if hasattr(_REFRESH_TIMER, "callback"):
            _REFRESH_TIMER.callback.append(_perform_converter_refresh)
        elif hasattr(_REFRESH_TIMER, "timeout"):
            _REFRESH_TIMER_CONN = _REFRESH_TIMER.timeout.connect(_perform_converter_refresh)

    # 1. Hook EventName Converter (Live Event Now/Next, EPG Short & Extended Descriptions)
    if _ORIGINAL_EVENT_GET_TEXT is None:
        _ORIGINAL_EVENT_GET_TEXT = EventName.getText

        def hooked_event_get_text(self):
            orig_text = _ORIGINAL_EVENT_GET_TEXT(self)
            if not cfg.enabled.value or not orig_text:
                return orig_text

            if self not in _ACTIVE_CONVERTERS:
                _ACTIVE_CONVERTERS.append(self)

            return engine.translate_or_queue(
                orig_text,
                on_complete_callback=lambda src, tr: _schedule_ui_refresh(),
                is_channel_name=False
            )

        EventName.getText = hooked_event_get_text
        EventName.text = property(EventName.getText)

    # 2. Hook ServiceName Converter (Channel Name in InfoBar, Bouquet List & OSD)
    if _ORIGINAL_SERVICE_GET_TEXT is None:
        _ORIGINAL_SERVICE_GET_TEXT = ServiceName.getText

        def hooked_service_get_text(self):
            orig_name = _ORIGINAL_SERVICE_GET_TEXT(self)
            if not cfg.enabled.value or not cfg.trans_channel_name.value or not orig_name:
                return orig_name

            # Only translate when converter is requesting NAME (not provider or orbital pos)
            if getattr(self, "type", None) == self.NAME:
                if self not in _ACTIVE_CONVERTERS:
                    _ACTIVE_CONVERTERS.append(self)
                return engine.translate_or_queue(
                    orig_name,
                    on_complete_callback=lambda src, tr: _schedule_ui_refresh(),
                    is_channel_name=True
                )
            return orig_name

        ServiceName.getText = hooked_service_get_text
        ServiceName.text = property(ServiceName.getText)

    # 3. Hook EventView Window (Full EPG Details Popup)
    orig_set_event = EventViewSimple.setEvent

    def hooked_set_event(self, event):
        orig_set_event(self, event)
        if not cfg.enabled.value or not cfg.trans_epg_views.value or event is None:
            return
        try:
            if "epg_description" in self:
                raw_desc = self["epg_description"].getText()
                translated_desc = engine.translate_or_queue(
                    raw_desc,
                    on_complete_callback=lambda s, t: self["epg_description"].setText(t)
                )
                self["epg_description"].setText(translated_desc)
        except Exception as err:
            print("[EPGTranslator] EventView hook warning:", str(err))

    EventViewSimple.setEvent = hooked_set_event
