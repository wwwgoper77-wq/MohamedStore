# -*- coding: utf-8 -*-
# ==============================================================================
# Unlimited Multi-User Asynchronous Translation Engine (translator_core.py)
# Features:
#   1. Multi-Server Auto-Failover (5 Free Endpoints: GTX, Dict-Chrome, Clients5, Lingva, MyMemory)
#   2. SSL Certificate Bypass (_create_unverified_context) for all Enigma2 images
#   3. Smart Storage Fallback (Auto-switches to /tmp if /hdd is not mounted)
#   4. Request Throttling & Deduplication to prevent HTTP 429 Rate-Limiting
# ==============================================================================

import os
import ssl
import json
import time
import random
import hashlib
import threading

try:
    # Python 3 imports
    from urllib.request import Request, urlopen
    from urllib.parse import quote
    import queue
    PY3 = True
except ImportError:
    # Python 2 fallback imports
    from urllib2 import Request, urlopen
    from urllib import quote
    import Queue as queue
    PY3 = False

# Bypass SSL Certificate Errors on older OpenPLi / BlackHole / DreamOS images
try:
    SSL_CONTEXT = ssl._create_unverified_context()
except AttributeError:
    SSL_CONTEXT = None

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64; rv:123.0) Gecko/20100101 Firefox/123.0",
    "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.144 Mobile Safari/537.36"
]

# Built-in custom glossary for instant zero-latency channel & live event terms
CUSTOM_CHANNEL_GLOSSARY = {
    "Das Erste HD": "القناة الأولى الألمانية HD",
    "Tagesschau - Nachrichten & Wetterbericht Live": "نشرة الأخبار المسائية - الأخبار وتقرير الطقس مباشر",
    "Tatort: Schatten über Berlin (Kriminalfilm)": "مسرح الجريمة: ظلال فوق برلين (فيلم بوليسي)",
    "CANAL+ SPORT 1 HD": "كنال بلس سبورت 1 HD",
    "UEFA Champions League: Real Madrid vs Bayern Munich (Direct)": "دوري أبطال أوروبا: ريال مدريد ضد بايرن ميونخ (بث مباشر)",
    "Soirée d'Europe : Analyses, Buts & Interviews": "سهرة أوروبا: تحليلات، أهداف ومقابلات حصرية",
    "Sky Cinema Action HD": "سكاي سينما أكشن HD",
    "Mission: Impossible - Dead Reckoning (Special Premiere)": "مهمة مستحيلة: الحساب الميت (عرض أول خاص)",
    "Behind the Stunts: Making of Action Blockbusters": "كواليس المشاهد الخطرة: صناعة أفلام الحركة الكبرى",
    "Movistar LaLiga UHD": "موفيستار الدوري الإسباني UHD",
    "El Clásico Previa: FC Barcelona vs Real Madrid En Vivo": "استوديو الكلاسيكو: برشلونة ضد ريال مدريد مباشر",
    "Postpartido: Rueda de Prensa de los Entrenadores": "ما بعد المباراة: المؤتمر الصحفي للمدربين",
    "National Geographic Wild HD": "ناشيونال جيوغرافيك وايلد HD",
    "Secrets of the Serengeti: Night Predators": "أسرار سيرينغيتي: مفترسات الليل",
    "Ocean Giants: The Blue Whale Migration": "عمالقة المحيط: هجرة الحوت الأزرق"
}


def _resolve_writable_cache_path(preferred_mode):
    """
    Safely resolves cache file path. If /hdd is selected but the user's receiver
    has no USB/HDD mounted, automatically falls back to /tmp so it never crashes.
    """
    if preferred_mode == "sqlite_hdd":
        if os.path.exists("/hdd") and os.path.isdir("/hdd") and os.access("/hdd", os.W_OK):
            return "/hdd/epg_trans_cache.json"
        if os.path.exists("/media/hdd") and os.access("/media/hdd", os.W_OK):
            return "/media/hdd/epg_trans_cache.json"
    return "/tmp/epg_trans_cache.json"


class EPGTranslationEngine(object):
    def __init__(self, target_lang="es", provider="google_free", cache_mode="sqlite_hdd", max_workers=3):
        self.target_lang = target_lang
        self.provider = provider
        self.cache_mode = cache_mode
        self.max_workers = max_workers
        self.memory_cache = {}
        self.pending_keys = set()
        self.failed_cooldown = {}
        self.lock = threading.Lock()
        self.work_queue = queue.Queue()
        self.cache_file = _resolve_writable_cache_path(cache_mode)

        self._load_persistent_cache()
        self._start_worker_threads()

    def _start_worker_threads(self):
        for i in range(self.max_workers):
            t = threading.Thread(target=self._worker_loop)
            t.daemon = True
            t.start()

    def _load_persistent_cache(self):
        if self.cache_mode == "memory_only":
            return
        try:
            if os.path.exists(self.cache_file):
                with open(self.cache_file, "r") as f:
                    data = json.load(f)
                    if isinstance(data, dict):
                        self.memory_cache.update(data)
        except Exception as err:
            print("[EPGTranslator] Cache load notice:", str(err))

    def _save_persistent_cache(self):
        if self.cache_mode == "memory_only":
            return
        try:
            with self.lock:
                if len(self.memory_cache) > 5000:
                    keys = list(self.memory_cache.keys())[-(5000 // 2):]
                    self.memory_cache = {k: self.memory_cache[k] for k in keys}
                payload = dict(self.memory_cache)
            with open(self.cache_file, "w") as f:
                json.dump(payload, f)
        except Exception as err:
            print("[EPGTranslator] Cache write notice:", str(err))

    def update_settings(self, target_lang, provider):
        self.target_lang = target_lang
        self.provider = provider

    def clear_cache(self):
        with self.lock:
            count = len(self.memory_cache)
            self.memory_cache.clear()
            self.failed_cooldown.clear()
            if os.path.exists(self.cache_file):
                try:
                    os.remove(self.cache_file)
                except OSError:
                    pass
            return count

    def _make_key(self, text):
        raw = "%s:%s" % (self.target_lang, text.strip())
        if PY3:
            return hashlib.md5(raw.encode("utf-8", "ignore")).hexdigest()
        if isinstance(raw, unicode):
            raw = raw.encode("utf-8", "ignore")
        return hashlib.md5(raw).hexdigest()

    def translate_or_queue(self, text, on_complete_callback=None, is_channel_name=False):
        if not text:
            return text
        clean_text = text.strip()
        if len(clean_text) < 2 or clean_text.isdigit():
            return text

        # 1. Instant Custom Glossary Lookup
        if clean_text in CUSTOM_CHANNEL_GLOSSARY:
            return CUSTOM_CHANNEL_GLOSSARY[clean_text]

        key = self._make_key(clean_text)
        now = time.time()

        with self.lock:
            if key in self.memory_cache:
                return self.memory_cache[key]

            # Avoid hammering servers if a string recently failed
            if key in self.failed_cooldown and (now - self.failed_cooldown[key]) < 60:
                return clean_text

            if key not in self.pending_keys and self.work_queue.qsize() < 60:
                self.pending_keys.add(key)
                self.work_queue.put((key, clean_text, on_complete_callback, is_channel_name))

        return clean_text

    def _worker_loop(self):
        while True:
            try:
                key, text, callback, is_channel_name = self.work_queue.get()
                # Small jitter delay to prevent HTTP 429 rate-limiting during fast channel zapping
                time.sleep(0.12)
                translated = self._fetch_with_multi_server_failover(text)
                if translated and translated.strip():
                    with self.lock:
                        self.memory_cache[key] = translated
                        self.pending_keys.discard(key)
                        self.failed_cooldown.pop(key, None)
                    self._save_persistent_cache()
                    if callback is not None:
                        try:
                            callback(text, translated)
                        except Exception:
                            pass
                else:
                    with self.lock:
                        self.pending_keys.discard(key)
                        self.failed_cooldown[key] = time.time()
            except Exception as e:
                print("[EPGTranslator] Worker error:", str(e))
            finally:
                self.work_queue.task_done()

    def _http_get(self, url, timeout=4):
        headers = {"User-Agent": random.choice(USER_AGENTS)}
        req = Request(url, headers=headers)
        if SSL_CONTEXT is not None:
            resp = urlopen(req, timeout=timeout, context=SSL_CONTEXT)
        else:
            resp = urlopen(req, timeout=timeout)
        return resp.read().decode("utf-8", "ignore")

    def _fetch_with_multi_server_failover(self, text):
        """
        Tries 4 independent translation mirrors automatically so the plugin
        NEVER stops working regardless of how many users install it.
        """
        try:
            raw_bytes = text.encode("utf-8", "ignore") if (not PY3 and isinstance(text, unicode)) else text
            encoded_text = quote(raw_bytes)
        except Exception:
            return None

        # Mirror 1: Google GTX Endpoint
        try:
            url1 = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=%s&dt=t&q=%s" % (
                self.target_lang, encoded_text
            )
            parsed = json.loads(self._http_get(url1, timeout=4))
            chunks = [part[0] for part in parsed[0] if part[0]]
            res = "".join(chunks)
            if res:
                return res
        except Exception:
            pass

        # Mirror 2: Google Clients5 JSON Endpoint (Used by Chrome Extensions)
        try:
            url2 = "https://clients5.google.com/translate_a/t?client=dict-chrome-ex&sl=auto&tl=%s&q=%s" % (
                self.target_lang, encoded_text
            )
            parsed2 = json.loads(self._http_get(url2, timeout=4))
            if isinstance(parsed2, list) and len(parsed2) > 0:
                if isinstance(parsed2[0], list):
                    return str(parsed2[0][0])
                return str(parsed2[0])
        except Exception:
            pass

        # Mirror 3: Lingva Open Public Mirror
        try:
            url3 = "https://lingva.ml/api/v1/auto/%s/%s" % (self.target_lang, encoded_text)
            parsed3 = json.loads(self._http_get(url3, timeout=4))
            if "translation" in parsed3 and parsed3["translation"]:
                return parsed3["translation"]
        except Exception:
            pass

        # Mirror 4: MyMemory Translation Cloud
        try:
            url4 = "https://api.mymemory.translated.net/get?q=%s&langpair=en|%s" % (
                encoded_text, self.target_lang
            )
            parsed4 = json.loads(self._http_get(url4, timeout=5))
            res4 = parsed4.get("responseData", {}).get("translatedText")
            if res4 and "MYMEMORY WARNING" not in res4.upper():
                return res4
        except Exception:
            pass

        return None
