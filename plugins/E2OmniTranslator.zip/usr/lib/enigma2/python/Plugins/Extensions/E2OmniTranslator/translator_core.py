# -*- coding: utf-8 -*-
# ==============================================================================
# Asynchronous Non-Blocking Translation Engine & Custom Channel Glossary
# Supports Python 2.7 and Python 3.8/3.11/3.12 without freezing Enigma2 GUI
# ==============================================================================

import os
import json
import time
import hashlib
import threading

try:
    # Python 3 imports
    from urllib.request import Request, urlopen
    from urllib.parse import quote
    import queue
    PY3 = True
except ImportError:
    # Python 2 fallback imports
    from urllib2 import Request, urlopen
    from urllib import quote
    import Queue as queue
    PY3 = False

# Built-in custom glossary for instant zero-latency channel & live event terms
CUSTOM_CHANNEL_GLOSSARY = {
    "Das Erste HD": "القناة الأولى الألمانية HD",
    "Tagesschau - Nachrichten & Wetterbericht Live": "نشرة الأخبار المسائية - الأخبار وتقرير الطقس مباشر",
    "Tatort: Schatten über Berlin (Kriminalfilm)": "مسرح الجريمة: ظلال فوق برلين (فيلم بوليسي)",
    "CANAL+ SPORT 1 HD": "كنال بلس سبورت 1 HD",
    "UEFA Champions League: Real Madrid vs Bayern Munich (Direct)": "دوري أبطال أوروبا: ريال مدريد ضد بايرن ميونخ (بث مباشر)",
    "Soirée d'Europe : Analyses, Buts & Interviews": "سهرة أوروبا: تحليلات، أهداف ومقابلات حصرية",
    "Sky Cinema Action HD": "سكاي سينما أكشن HD",
    "Mission: Impossible - Dead Reckoning (Special Premiere)": "مهمة مستحيلة: الحساب الميت (عرض أول خاص)",
    "Behind the Stunts: Making of Action Blockbusters": "كواليس المشاهد الخطرة: صناعة أفلام الحركة الكبرى",
    "Movistar LaLiga UHD": "موفيستار الدوري الإسباني UHD",
    "El Clásico Previa: FC Barcelona vs Real Madrid En Vivo": "استوديو الكلاسيكو: برشلونة ضد ريال مدريد مباشر",
    "Postpartido: Rueda de Prensa de los Entrenadores": "ما بعد المباراة: المؤتمر الصحفي للمدربين",
    "National Geographic Wild HD": "ناشيونال جيوغرافيك وايلد HD",
    "Secrets of the Serengeti: Night Predators": "أسرار سيرينغيتي: مفترسات الليل",
    "Ocean Giants: The Blue Whale Migration": "عمالقة المحيط: هجرة الحوت الأزرق"
}


class EPGTranslationEngine(object):
    def __init__(self, target_lang="ru", provider="google_free", cache_mode="sqlite_hdd", max_workers=3):
        self.target_lang = target_lang
        self.provider = provider
        self.cache_mode = cache_mode
        self.max_workers = max_workers
        self.memory_cache = {}
        self.pending_keys = set()
        self.lock = threading.Lock()
        self.work_queue = queue.Queue()
        self.cache_file = "/tmp/epg_trans_cache.json" if cache_mode == "json_tmp" else "/hdd/epg_trans_cache.json"

        self._load_persistent_cache()
        self._start_worker_threads()

    def _start_worker_threads(self):
        for i in range(self.max_workers):
            t = threading.Thread(target=self._worker_loop)
            t.daemon = True
            t.start()

    def _load_persistent_cache(self):
        if self.cache_mode == "memory_only":
            return
        try:
            if os.path.exists(self.cache_file):
                with open(self.cache_file, "r") as f:
                    data = json.load(f)
                    if isinstance(data, dict):
                        self.memory_cache.update(data)
        except Exception as err:
            print("[EPGTranslator] Cache load warning:", str(err))

    def _save_persistent_cache(self):
        if self.cache_mode == "memory_only":
            return
        try:
            with self.lock:
                if len(self.memory_cache) > 5000:
                    # Trim oldest entries when exceeding cache limit
                    keys = list(self.memory_cache.keys())[-(5000 // 2):]
                    self.memory_cache = {k: self.memory_cache[k] for k in keys}
                with open(self.cache_file, "w") as f:
                    json.dump(self.memory_cache, f)
        except Exception as err:
            print("[EPGTranslator] Cache write warning:", str(err))

    def update_settings(self, target_lang, provider):
        self.target_lang = target_lang
        self.provider = provider

    def clear_cache(self):
        with self.lock:
            count = len(self.memory_cache)
            self.memory_cache.clear()
            if os.path.exists(self.cache_file):
                try:
                    os.remove(self.cache_file)
                except OSError:
                    pass
            return count

    def _make_key(self, text):
        raw = "%s:%s" % (self.target_lang, text.strip())
        if PY3:
            return hashlib.md5(raw.encode("utf-8", "ignore")).hexdigest()
        return hashlib.md5(raw).hexdigest()

    def translate_or_queue(self, text, on_complete_callback=None, is_channel_name=False):
        if not text or not text.strip():
            return text

        clean_text = text.strip()

        # 1. Check Custom Channel & Sports Glossary first
        if clean_text in CUSTOM_CHANNEL_GLOSSARY:
            return CUSTOM_CHANNEL_GLOSSARY[clean_text]

        key = self._make_key(clean_text)
        with self.lock:
            if key in self.memory_cache:
                return self.memory_cache[key]

            if key not in self.pending_keys:
                self.pending_keys.add(key)
                self.work_queue.put((key, clean_text, on_complete_callback, is_channel_name))

        return clean_text

    def _worker_loop(self):
        while True:
            try:
                key, text, callback, is_channel_name = self.work_queue.get()
                translated = self._fetch_remote_translation(text)
                if translated:
                    with self.lock:
                        self.memory_cache[key] = translated
                        self.pending_keys.discard(key)
                    self._save_persistent_cache()
                    if callback is not None:
                        try:
                            callback(text, translated)
                        except Exception:
                            pass
                else:
                    with self.lock:
                        self.pending_keys.discard(key)
            except Exception as e:
                print("[EPGTranslator] Worker error:", str(e))
            finally:
                self.work_queue.task_done()

    def _fetch_remote_translation(self, text):
        try:
            encoded_text = quote(text.encode("utf-8") if not PY3 and isinstance(text, unicode) else text)
            if self.provider == "google_free":
                url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=%s&dt=t&q=%s" % (
                    self.target_lang, encoded_text
                )
                req = Request(url, headers={"User-Agent": "Mozilla/5.0 (Enigma2 STB; Linux)"})
                resp = urlopen(req, timeout=4)
                raw_json = resp.read().decode("utf-8", "ignore")
                parsed = json.loads(raw_json)
                chunks = [part[0] for part in parsed[0] if part[0]]
                return "".join(chunks)

            elif self.provider == "mymemory":
                url = "https://api.mymemory.translated.net/get?q=%s&langpair=autodetect|%s" % (
                    encoded_text, self.target_lang
                )
                req = Request(url, headers={"User-Agent": "Mozilla/5.0 (Enigma2 STB)"})
                resp = urlopen(req, timeout=5)
                parsed = json.loads(resp.read().decode("utf-8", "ignore"))
                return parsed.get("responseData", {}).get("translatedText", text)

        except Exception as err:
            print("[EPGTranslator] API error:", str(err))
        return None
