# -*- coding: utf-8 -*-
# ==============================================================================
# E2OmniTranslator - Universal Enigma2 EPG, Channel Name & Live Event Translator
# Hardware Support:
#   - Vu+ (Solo 4K, Ultimo 4K, Uno 4K SE, Duo 4K SE, Zero 4K, Zero, Duo2)
#   - Octagon (SF8008 4K Twin/Combo/Supreme, SF4008 4K, SX88)
#   - Dreambox (DM900 UHD, DM920 UHD, Dream One, Dream Two, DM800/DM8000)
# Images: OpenATV, OpenPLi, Egami, BlackHole, OpenBH, VTi, Pure2, DreamOS (OE2.0/2.5/2.6)
# هذا البلجن متاح في بنل MohamedStore
# ==============================================================================

from __future__ import print_function, absolute_import
import os
import sys
import json
import base64
import threading
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.ConfigList import ConfigListScreen
from Components.config import (
    config, ConfigSubsection, ConfigYesNo, ConfigSelection,
    ConfigNumber, getConfigListEntry
)
from enigma import eTimer, eEPGCache, getDesktop

from .translator_core import EPGTranslationEngine
from .skin_hook import install_global_enigma2_hooks, force_refresh_current_screens, detect_stb_hardware

PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))
NAMED_ICON_FILE = os.path.join(PLUGIN_DIR, "E2OmniTranslator.png")
DEFAULT_ICON_FILE = os.path.join(PLUGIN_DIR, "plugin.png")
PANEL_CREDIT = "هذا البلجن متاح في بنل MohamedStore"

# Embedded Base64 PNG Icon with Plugin Name (E2OmniTranslator.png) & MohamedStore
EMBEDDED_ICON_B64 = "iVBORw0KGgoAAAANSUhEUgAAAGQAAAAoCAYAAAAIeF9DAAAAAXNSR0IArs4c6QAAEWRJREFUaEPtWgl4FtW5fkP2PQSQzaBIFa9YCUR2FNSItKjsYZGALWoBy1KSIGBiQllEkoAKCFSrslxDEJGltooYCBGTAFfsbfFBFkkJsoQQskL2/37nnDkzZ+afPyTe4L1P2+HhycycM+ec+d7vfb/vfP+4Vbzr78C/j/83FnBjgKzYG6AtyM20MDc38zWgXPNTtd3NuLJp4wPr3cWJ8bR2ZmkXi6Fx6T7zGmUG83ot8+n9nMajUTT3M7zQ4o8Oq3+KazE//XVql63akvTHjedEizG3fq1am5pjI6/CAoizkfkdW0OZGkwGEvaxBzM1o7XexgzHX1T21f4Kg9J/k6ElMOyvHFsD1nIt5+b9xATckNygOiLSYNp93dAqYrK3akztOaf+xnjC/s7jsLc18JTt4m/MY1cRF1mkAuKGeUPKVMya/TwloxVSM9podtaMroBneLZkkD1gAikBkMEzAZTOJCeWmg2g+y8/UfjSgKHNDDGAEffVcVQmmueVcxlME+2xj14lhvzUgHzBAFEYohpQYYQuaKrnc8JIaWuIIQazOEHofQUzhMECBnZCzcUyVOeXIvDRzoB3C5TvOwvve1uhrrgSVScLtZ7OhgwcfBf8+3dCyWcncf3oD/ALb4+goV1Rc74YdWVVcA/w5gysyD2HypNX+DhuXu4IHnIP3EN8UZVXhKrvr9JzHXD92Hn4RYShdP8p1JVWIvaxosYzZPtRD0zb7M0nmP/LatzZysGvW/o58MKgGkzsU4vUz7yw42t39O5cj/WTqxBqkyukEBgMEKvk6BJjMrgiUeLVTFInbinAaICZJFCNcZrnt5zyADw7BqE4/e9oM6svHHX1KFydg6Dh96ImvwTlB/MQTOdFH/wN9WWVGuMc8OsdhtBnuqPkkxMIGX0/yj4/jaAhd6Pw/aNAPVBzqRRtpvVFeXYetZ1CLRmZHR6tfNEhYQhK951EyPBuHCi/nrej4sg5+PfqhPMvf4Kq04WIIYY0WrIYIHlX3RD7RA2fhF2z45H/qEPiTi+0C3bgZ7fVI6pXLVpYQwfvKQ4JiJQZEzANGFRIkeSHygBFohSAVCZZY4fv/bchdEo493Dve1qhhb8XCjcc4SBw5uQVo2XU/Sh85ygqT1yBo6aOr53d8+oUgkvJB9Fx6RDOCNQ7cOm1A/r7dVw6FCWfn0TZ/tP6PY9QX7SPj8TltYcQNKgLfLu1hZu3B5+3rqSS7mfRPAVWhgTyAVzFEFcMCQt14MVHqnHuWgtEPViL9w55Ip+Ac8UQxg4WQ/RgbQriFo/nl2YGmIF0bnOWNPZW5uDqFkgO9PLDaOHjgYqv8uEb0R5X1x/hDKknAzloWP8+YSj74gxK//QdaoklbKbgUd3gc28bXE7JQoffR6K2oALuLX3wQ/xeoYv0nwFSygA5cEbPxiQgBQRI6JjucG/tR3JJEnftBnzuacOZU5pxkoJ6EyXLjiFjCAS2lpV7PdGxpQNPh9firf2e+PXA2gYlS2ZQ9kHcOVibsibuOkZ2pQdxK0M4mDKrMYI2W3Dr3zwI/wFhuJC4H60mdYdHO0r76f6VNbmou16N1s/2xOVVhyim3NAB9ewQhPZJj/GYUHO+FFc25KLd/EE8btQUlOPC4n1oHzeYGPIdMeSMnmW5k2SFrXiKwPNF9dki3Pj2MurKK3E17RjaznwIN45fJEBO2TGEZVmlisAYp3YMYa0MEHbkF7lh0W4v7DzmgVERtVgxphohFF+sh8EQc3C+abDmxjUYYWRXlnGs6S8niIt0VIZ5PR3W2NSErIu/nyUrM+9TZLYl0ueGsjQLQxqWLFuUfsRNEUMo7dVT0psY1FbSjGes2Zh5X2PZL1jSUlf7Aes+RU1TNc6JN9fGE4Z2vb9oaDxlIGLINTWoM0BcM+RH2N72Ec6Q/RRDrPsIC0AuszBXG0DbjaTq8c4bQteGVpltL3li5MbtLwyGqsCZ9z3s9W0Z4pz9SLtKr7TaWfdRYWRThqVcKLt2wRAzM2yzLr1kogmaIlumDSBbksIkmfZaN143ky7V401ljkZInurpjQXACijbFMZFXpM79UAkfx6kGcosCTzdbEqpgq9O03zN8w1p0doam10ppQ+7nbn9/kU6jWUnbcm2pBH1HbbutBapsym1mGOHxhe+AdXNbIpddrHD6iBOkiUBMbIWJd/XvfDHBGMDIGupw2RQXbbMHi/wVVJcfmkGXBhXdZwmSE0TgrIZiJsDZwaiYeBMDGFgsP+65mgGSJg/C7/77VR4eXmatOpAVi5S33gHG9YsRYd2t/G2A1mHMXzcNH4+fsyTSF02HwEBfvy6uqYGr6/diGUpf9DsqwLbiOxJ2cF/tXcjggIDcPzEGUQO7mNaF7u4eLkQM2KWIyv7a81+roqH1uxLGEwc9kE6J+MDPvdv5izCwS+P6H35E1q2Nm70L8lmUxAXn0x9DrvMrpwZ4iRZwVqZ29gRxxMgc2dOxdYP9+DFua+YANvz4dvo37cnVq1+D+3btcHkiSOx6YOd+DL7KFa+ugDnL1xGn0fG8md2p7+Ffn16ECibCJQNTsA3tpQi8kaFCeQ4USOHIPn3s/H1X09gVHScUh43B10mJk3xWLsiYE5GGoIZILOTkHlIA8RUjncgd/82BAVRn1mvIDOL9XFeh+YpJkC5ZD2uxRB7hrghYf5MzhABSKK5msqG05j08rwXqd+z2Lr9E9wR1kEz/vtYlryBL2fQwN7Y8MYilJSW43JBISLCu6GsvIIDWV5+HWfy8tH9/q58gVvS92D7zn1YtyqeXwcG+iPA3w8XL13B9JhleC1pNvdSdv5l9jEOyAoFkKiRkVixaDZ/ljH7bN4F7Pk0E7OmTYCXp2D6lvRPsH3X51i38mWnOabNWczXlbIkRmd45pdHMXzCTORKhhAgA/v1xJwXJ+tjbkrbxd990MBefEz2XjELl2PC2Ccx+KHe2r0KzF3wKtnzT3qxUyYTsRTQlaBOkrWPgrqlmprwEkkWMUSVrOrqGqxa8y6WrHiLA8SNvXoJWrdqidfXvI+nhz2me8jBQ1R447i5ISdjG4LJcwoKi7jxN2/djUskL7NnRJPRzmNewkqsf52xEFj3zjZMfy6KgxFH9wcQuyaNG8YN2atnNx2QLA0QlSFjR0RyxpSVXeeg8fFSF+LkmX9g1KS5EJLnj3V/pDmmanPEpxLbeyB63JO0rj3oFNYe/Xp3xxtvbUHviJ+TA92HWJIgBgBjyNq30zDj+Qk4dToPT4+bobHCn1iRiOQlceL9Z76CsSOHknKM4Mrx4Y6/kJ0W8/W8MDOe2JPLzyWDbBgS7FRNjVcZEkMMsVRj2XCHM3fg3nvuwomT36PP4DHIPbBdAyQRWV8JQJhs5WSk64B0uTOMv2CXzmEckOzDf8WIibORs+8/TcYqLatAv8cnY2HMVPLwidi2Y68OyAwydlbON8SQxzkjpGRJhvxw4QoGPPGsLmEfb0nFwwMi+GoY2yQgfI7IaCygOWZPfwbpH33K+0SPf0pbOzhIM+OWEkPSRAwhhjBn27V1jc6IC5cKCJAkAiRWd8jkJfM0cBKQSfFkTWoixo8dxmV+yYq1Gh5C0swM4UGdYohmPFn8S3iJJEuPIYlOgB0++DEHgy9mZgIt8gh2b1uvSdZGLE1ez8FgNLZKlhMgE2Yh5wsWNMl7NYYIQMhYc58jY5kBYd6flS0A0RkyKZa8UlwzQPoPmSJizOI5gjFzl+C1RXOc5ugbOQkL5xIgMyZxQGbNexUP9e+JDa8ncvlix+a03ehFbGHen/7Rn/H8lLEoJdk1WGFlSAKSl76kA8ISobUrGSBPCkBeY4AY2WBcZLE1hlgYQujEM0BYDNnOYkiSCbA1qUk8kAvPIDBY1kHSNH70MJ5hlZaXYxr3pCPkSSyoh5MEbCIJeIDHkNj4FGLI7TpDRhJDsm0Y0p8YwryXM+RjYkgPIVkGQyiGLJqlMSQWUSOIMRIQYsiC3/2Kx4+cw/+NlSRBTL7YYWbIJI0hAhAmWRHdmUyl4C5a4xxicfpHf+GAMMli7Bj5dCSyc79BypvvYcObSXxMk2SRTcaO/AUmT2gGyZLprwzq1rSXyRM7GDvUY1PaTsyMWUxprwDFnPZShpX6B+xKW2MLyIgJJFlfNF6yeFC3SpaJIQXEEJIs+pdNcaPr3XfypRZdK6WY6IF3Nu7AuFFPgLHQypDtO/fyeCbZceLUWfR9ZDzJ7lbu8dNmJ2LF4jh6/87amCU8uKtBvJzYM3fBckyMesoc1OcvQxoFdWsW58yQfSFOQd2ppNHgjr3pG0n7jxxEpBIVAva+6j7F8hu7qVZjTS/Zs0a1VTpOQyUVux218QOXzXh8+KbWtGR/bTy+MAcVFxuQLKfiH7eLtjvmp+ads6sShrnmZAGM176UcXhzY2pcxlp4ZYWXLHR/06uwjQFA2MLYDIpLc3HRXNVV212VZho/njo/S3njHi8WtSwW0JP3saBuMYhWSzIXA80eK17cUlJpFGCufzO3LTZqgMnioWlenQlNr+qay+cKGE0uKgpPl/t/Y9NvVAQaYiDPsqyA2FddpUdaPfgmHm9lUkMG1dhnzfIaquoKP3D9vZUArAk1LeUHK/ms6sGugHP1vZfdTt86niqpIoYoDEmhGCLTXRUYo9ioANPY3yW0GNAoKVLihV48lOzTx9HYqJTzjdKECw9VDC2k7WYlFbPGO3m8FTiXkuc8jt0PWRJQE0Mmbr4Dh773kbJrSJfJILJZSpaIJQIw5zYDXKNNar05WKuSZx5H769Los08GhP0Jeh2UGOBAMvc1dLOL5XyufOA2h3zcwbA+gPGXKZbOrRazDOPM+CuSnwQnSdiCAPk2KWW6uP/Eudtg+uRNK4USelBuFzS4v/0nXu0K771gKRMKcHIPpVI3hWA9Z/5Y1tMEbp1qsX8zUHYc9RgJLMEaztX6I7YjbRBbcaDraFT6zpEpYbivrBabJ51DSH+9XxN7BjT7waeWRX6rwXIf53xRNK2IG4MHy8HB2RQtyoOVmWNG7+OHnQdt7eqQ9uQepwtcOdGWv1cMSK61KC4ogUS0wOxYFQ5fDwd3KBsTNZm7cuuZ/8xBG9MLUbn28RHbqwvA0SCw4Dv0q4Wgb4O3oe1Z/zdG3HDy3l/BtbPqF2ub82f/fFc5HU+78e5Ps3uNGzOn4wh4Z21rx2zfTEsohKhAQ7s/cYbQ8Kr8Py6EPz60QruwfJgwL09vZj36dyWPinaGcivt2T6YtKgG1i+I4CDx47NmX6YTyB9Rn0fvq8KswiINwmIfDL4A3fUIvrNlkiKEp82MUCmPVHBjS4BYteMIYtIspZHl/KxO5JTsHvf/eCJrh1rdMdgIGYe9+bzsXV/my++3myuI5wkK+1WxxDmkV07im+32HG1rAXubl+Ho6c9SbrEy/a+uxovDKlAbZ0bzlxyx7sZ/hwAaXjGAsYi5qWjyVDM6AxEdrC+DICD33pjymABEjuOk7H8vB18/LgRZbpksbanHqzkxr9IX1t+eswHQ3tU4n0aZ/rQCm5odrAx8wo8EORLn8cSkExO2TrYIRltldz/LTA/GUOY9zPv+kXPKqwmo0aTl7tiCOsnAWGgtW9Zx6VOMqQhQFSGHM/3xINkQGZglSEyTklPl8xyxZA2QSL2WJ+7NQy5Rgz5h8yy7qQsS3hHcx5Ss5k+P08a/MrWQCwcXe7k/TKGqIAw0KIGsE85ySur3bDriI8uS1aGsCyJZUsyHli9WkqUZAeLQywWMGAYW46f8+BOw2IGO2QMkcmA+pxMUJrTTmwsC0NuDSDNveh/5vHC2xJDJt9ihvwzG7C53y28nUWy9JKpLFHxGcUe3Lwb15bCK62yRG63PGP/bm3VSylagz6+/ohlXnUoraJuuaWt0vhjbzDr7t2ml15UVKvIaj8XYzjdvtlcxs5dGllnSHOj/e/xfrwF/gclZEJH8NuNHQAAAABJRU5ErkJggg=="


def _ensure_plugin_icons_exist():
    """
    Ensures both E2OmniTranslator.png (named after the plugin) and plugin.png
    exist inside the plugin directory so the icon always shows on all skins.
    """
    if not EMBEDDED_ICON_B64:
        return
    try:
        raw_png = base64.b64decode(EMBEDDED_ICON_B64)
        for target_path in (NAMED_ICON_FILE, DEFAULT_ICON_FILE):
            if not os.path.exists(target_path):
                with open(target_path, "wb") as f:
                    f.write(raw_png)
    except Exception as err:
        print("[E2OmniTranslator] Icon write notice:", str(err))


_ensure_plugin_icons_exist()

# Initialize Enigma2 Configuration Subsystem
config.plugins.epgtranslator = ConfigSubsection()
config.plugins.epgtranslator.enabled = ConfigYesNo(default=True)
config.plugins.epgtranslator.target_lang = ConfigSelection(default="es", choices=[
    ("ar", "العربية (Arabic)"),
    ("en", "English"),
    ("fr", "Français"),
    ("de", "Deutsch"),
    ("es", "Español"),
    ("tr", "Türkçe"),
    ("it", "Italiano"),
    ("ru", "Русский")
])
config.plugins.epgtranslator.provider = ConfigSelection(default="google_free", choices=[
    ("google_free", "Google Translate Fast API (Free)"),
    ("mymemory", "MyMemory Translation Cloud"),
    ("libretranslate", "LibreTranslate Open Server")
])
config.plugins.epgtranslator.trans_channel_name = ConfigYesNo(default=True)
config.plugins.epgtranslator.trans_infobar = ConfigYesNo(default=True)
config.plugins.epgtranslator.trans_channellist = ConfigYesNo(default=True)
config.plugins.epgtranslator.trans_epg_views = ConfigYesNo(default=True)
config.plugins.epgtranslator.cache_mode = ConfigSelection(default="sqlite_hdd", choices=[
    ("sqlite_hdd", "SQLite Database (/hdd/epg_trans_cache.db)"),
    ("json_tmp", "Fast RAM Disk (/tmp/epg_trans_cache.json)"),
    ("memory_only", "RAM Memory Only")
])

GLOBAL_ENGINE = EPGTranslationEngine(
    target_lang=config.plugins.epgtranslator.target_lang.value,
    provider=config.plugins.epgtranslator.provider.value,
    cache_mode=config.plugins.epgtranslator.cache_mode.value,
    max_workers=3
)


class EPGTranslatorSetupScreen(ConfigListScreen, Screen):
    skin = """
    <screen name="EPGTranslatorSetupScreen" position="center,center" size="880,620" title="E2OmniTranslator - Vu+ / Octagon / Dreambox">
        <ePixmap pixmap="E2OmniTranslator.png" position="25,12" size="100,40" alphatest="on" />
        <widget name="header_title" position="140,14" size="715,36" font="Regular;22" halign="center" valign="center" foregroundColor="#ffffff" />
        <widget name="config" position="25,65" size="830,360" itemHeight="36" scrollbarMode="showOnDemand" />
        <widget name="status_label" position="25,435" size="830,40" font="Regular;19" halign="center" valign="center" foregroundColor="#34d399" />
        <widget name="footer_credit" position="25,485" size="830,48" font="Regular;24" halign="center" valign="center" foregroundColor="#fbbf24" backgroundColor="#111827" />
        <ePixmap pixmap="skin_default/buttons/red.png" position="55,555" size="150,40" alphatest="on" />
        <ePixmap pixmap="skin_default/buttons/green.png" position="260,555" size="150,40" alphatest="on" />
        <ePixmap pixmap="skin_default/buttons/yellow.png" position="465,555" size="150,40" alphatest="on" />
        <ePixmap pixmap="skin_default/buttons/blue.png" position="670,555" size="150,40" alphatest="on" />
        <widget name="key_red" position="55,555" zPosition="1" size="150,40" font="Regular;20" halign="center" valign="center" backgroundColor="#9f1313" transparent="1" />
        <widget name="key_green" position="260,555" zPosition="1" size="150,40" font="Regular;20" halign="center" valign="center" backgroundColor="#1f771f" transparent="1" />
        <widget name="key_yellow" position="465,555" zPosition="1" size="150,40" font="Regular;20" halign="center" valign="center" backgroundColor="#a08500" transparent="1" />
        <widget name="key_blue" position="670,555" zPosition="1" size="150,40" font="Regular;20" halign="center" valign="center" backgroundColor="#18188b" transparent="1" />
    </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.list = []
        ConfigListScreen.__init__(self, self.list, session=self.session)
        stb_info = detect_stb_hardware()
        self["header_title"] = Label("E2OmniTranslator - ترجمة دليل القنوات والحدث المباشر (%s)" % stb_info)
        self["status_label"] = Label("الترجمة الفورية نشطة على أجهزة Vu+ و Octagon و Dreambox | زر الاختصار: YELLOW")
        self["footer_credit"] = Label("هذا البلجن متاح في بنل MohamedStore")
        self["key_red"] = Label("إلغاء")
        self["key_green"] = Label("حفظ وتفعيل")
        self["key_yellow"] = Label("مسح الكاش")
        self["key_blue"] = Label("ترجمة الآن")

        self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
            "ok": self.keySave,
            "cancel": self.keyCancel,
            "green": self.keySave,
            "red": self.keyCancel,
            "yellow": self.clearTranslationCache,
            "blue": self.forceRetranslateNow
        }, -2)

        self.createSetupList()

    def createSetupList(self):
        self.list = [
            getConfigListEntry("تفعيل الترجمة التلقائية في كل مكان", config.plugins.epgtranslator.enabled),
            getConfigListEntry("لغة الترجمة الهدف (Target Language)", config.plugins.epgtranslator.target_lang),
            getConfigListEntry("محرك الترجمة السحابي", config.plugins.epgtranslator.provider),
            getConfigListEntry("ترجمة اسم القناة (Channel Name)", config.plugins.epgtranslator.trans_channel_name),
            getConfigListEntry("ترجمة شريط المعلومات والحدث المباشر (InfoBar Now/Next)", config.plugins.epgtranslator.trans_infobar),
            getConfigListEntry("ترجمة قائمة القنوات والباقات (Channel Selection)", config.plugins.epgtranslator.trans_channellist),
            getConfigListEntry("ترجمة نافذة تفاصيل الحدث والدليل الرسومي (EventView & EPG)", config.plugins.epgtranslator.trans_epg_views),
            getConfigListEntry("نظام التخزين المؤقت (Cache Storage)", config.plugins.epgtranslator.cache_mode),
        ]
        self["config"].list = self.list
        self["config"].l.setList(self.list)

    def clearTranslationCache(self):
        cleared_count = GLOBAL_ENGINE.clear_cache()
        self["status_label"].setText("تم تفريغ الذاكرة المؤقتة بنجاح (%d عنصر ممسوح)" % cleared_count)

    def forceRetranslateNow(self):
        force_refresh_current_screens()
        self["status_label"].setText("تم تحديث وترجمة الحدث المباشر ودليل القنوات الفوري!")

    def keySave(self):
        for x in self["config"].list:
            x[1].save()
        GLOBAL_ENGINE.update_settings(
            target_lang=config.plugins.epgtranslator.target_lang.value,
            provider=config.plugins.epgtranslator.provider.value
        )
        force_refresh_current_screens()
        self.close()

    def keyCancel(self):
        for x in self["config"].list:
            x[1].cancel()
        self.close()


def sessionstart(reason, **kwargs):
    if reason == 0 and "session" in kwargs:
        session = kwargs["session"]
        install_global_enigma2_hooks(session, GLOBAL_ENGINE, config.plugins.epgtranslator)


def main(session, **kwargs):
    session.open(EPGTranslatorSetupScreen)


def Plugins(**kwargs):
    icon_to_use = "E2OmniTranslator.png" if os.path.exists(NAMED_ICON_FILE) else "plugin.png"
    return [
        PluginDescriptor(
            name="E2OmniTranslator",
            description="هذا البلجن متاح في بنل MohamedStore",
            where=[PluginDescriptor.WHERE_SESSIONSTART],
            fnc=sessionstart
        ),
        PluginDescriptor(
            name="E2OmniTranslator",
            description="هذا البلجن متاح في بنل MohamedStore",
            icon=icon_to_use,
            where=[PluginDescriptor.WHERE_PLUGINMENU, PluginDescriptor.WHERE_EXTENSIONSMENU],
            fnc=main
        )
    ]
