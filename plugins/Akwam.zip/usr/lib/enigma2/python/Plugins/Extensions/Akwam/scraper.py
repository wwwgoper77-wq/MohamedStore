# -*- coding: utf-8 -*-
"""
===================================================================
 Akwam Scraper Engine for Enigma2 - FAST STREAM & MEDIA EXTRACTOR
 Target Domain: https://as.akwam.tube/l2/ & https://ak.sv (and official mirrors)
 Features:
   - Full support for new Akwam site (as.akwam.tube) and classic mirrors
   - Standalone Years filter: Merges all movies and series for 2026, 2025, 2024, etc.
   - Intelligent Series Grouping: Aggregates TV show episodes into unified Series cards
   - High speed HTML parsing with Cloudflare / SSL bypass
   - Movies & Series listing with accurate poster extraction (data-src / WebP)
   - Multi-server video stream resolution (MP4Plus, AnaFast, Vidoba, VidSpeed, OK, Direct MP4, CDN)
   - Compatible with Python 2.7 and Python 3.x (OpenATV, OpenPLi, Egami, Pure2, BlackHole)
===================================================================
"""

import sys
import re
import os
import zlib
import gzip
import json

PY3 = sys.version_info[0] == 3
if PY3:
    import urllib.request as urllib2
    from urllib.parse import urljoin, quote, unquote, urlparse
    from io import BytesIO
else:
    import urllib2
    from urlparse import urljoin, urlparse
    from urllib import quote, unquote
    from StringIO import StringIO as BytesIO

LOG_FILE = "/tmp/akwam.log"

def log_debug(msg):
    try:
        with open(LOG_FILE, "a") as f:
            f.write("[Akwam] " + str(msg) + "\n")
    except Exception:
        pass
    print("[Akwam] " + str(msg))

def safe_url(url):
    if not url:
        return ""
    if PY3:
        import urllib.parse
        return urllib.parse.quote(str(url), safe=":/%?&=+#@!$,;'*()")
    else:
        import urllib
        try:
            if isinstance(url, unicode):
                url = url.encode("utf-8")
        except NameError:
            pass
        return urllib.quote(str(url), safe=":/%?&=+#@!$,;'*()")

def baseN_decode(s, b):
    chars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
    val = 0
    for c in s:
        idx = chars.find(c)
        if idx != -1 and idx < b:
            val = val * b + idx
    return val

ssl_context = None
try:
    import ssl
    ssl_context = ssl._create_unverified_context()
except Exception:
    ssl_context = None

def extract_poster_url(inner_html, base_url="https://as.akwam.tube"):
    if not inner_html:
        return ""
    patterns = [
        r'data-src=["\']([^"\']+)["\']',
        r'data-lazy-src=["\']([^"\']+)["\']',
        r'data-original=["\']([^"\']+)["\']',
        r'data-img=["\']([^"\']+)["\']',
        r'srcset=["\']([^"\'\s]+)',
        r'<img[^>]+src=["\']([^"\']+)["\']',
        r'url\(["\']?([^"\'\)]+)["\']?\)'
    ]
    for p in patterns:
        matches = re.findall(p, inner_html, re.IGNORECASE)
        for m in matches:
            m = m.strip()
            if m and not m.startswith("data:image") and not m.endswith(".svg") and "placeholder" not in m.lower() and "no-thumbnail" not in m.lower():
                if m.startswith("//"):
                    return "https:" + m
                elif not m.startswith("http"):
                    return urljoin(base_url, m)
                return m

    m = re.search(r'<img[^>]+src=["\']([^"\']+)["\']', inner_html, re.IGNORECASE)
    if m:
        val = m.group(1).strip()
        if val and not val.startswith("data:image") and not val.endswith(".svg"):
            if val.startswith("//"):
                return "https:" + val
            elif not val.startswith("http"):
                return urljoin(base_url, val)
            return val
    return ""

class AkwamScraper:
    def __init__(self, base_url="https://as.akwam.tube/l2/"):
        raw_url = (base_url or "https://as.akwam.tube/l2/").strip()
        if not raw_url.startswith("http"):
            raw_url = "https://" + raw_url
        self.raw_input_url = raw_url
        
        parsed = urlparse(raw_url)
        self.domain_root = "%s://%s" % (parsed.scheme, parsed.netloc)
        self.base_url = raw_url.rstrip("/")
        
        # Determine whether this is as.akwam.tube / WordPress theme or classic ak.sv
        self.is_tube_site = "tube" in self.domain_root.lower() or "as.akwam" in self.domain_root.lower()
        
        self.last_error = ""
        self.memory_cache = {}
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
            "Accept-Language": "ar,en-US;q=0.9,en;q=0.8",
            "Accept-Encoding": "gzip, deflate",
            "Connection": "keep-alive"
        }

    def build_full_url(self, path):
        if not path:
            return self.base_url
        if path.startswith("http://") or path.startswith("https://"):
            return path
        if not path.startswith("/"):
            path = "/" + path
        return self.domain_root + path

    def fetch_html(self, url, use_cache=True, custom_headers=None):
        target_url = self.build_full_url(url)
        target_url = safe_url(target_url)

        if use_cache and target_url in self.memory_cache:
            return self.memory_cache[target_url]

        log_debug("Fetching URL: " + target_url)
        self.last_error = ""
        req_headers = dict(self.headers)
        if custom_headers:
            req_headers.update(custom_headers)

        # 1. Try requests if available
        try:
            import requests
            r = requests.get(target_url, headers=req_headers, verify=False, timeout=10)
            text = r.text
            if "Just a moment..." in text or "challenge-platform" in text:
                self.last_error = "CLOUDFLARE_BLOCKED"
                return ""
            if use_cache:
                self.memory_cache[target_url] = text
            return text
        except ImportError:
            pass
        except Exception as e:
            log_debug("Requests fallback: " + str(e))

        # 2. Standard urllib fallback
        try:
            req = urllib2.Request(target_url, headers=req_headers)
            if ssl_context:
                res = urllib2.urlopen(req, timeout=10, context=ssl_context)
            else:
                res = urllib2.urlopen(req, timeout=10)

            raw_data = res.read()
            encoding = res.headers.get("Content-Encoding", "").lower()
            if encoding == "gzip" or raw_data[:2] == b"\x1f\x8b":
                try:
                    raw_data = gzip.GzipFile(fileobj=BytesIO(raw_data)).read()
                except Exception:
                    pass
            elif encoding == "deflate":
                try:
                    raw_data = zlib.decompress(raw_data)
                except Exception:
                    pass

            if PY3:
                html = raw_data.decode("utf-8", errors="ignore")
            else:
                html = raw_data

            if "Just a moment..." in html or "challenge-platform" in html:
                self.last_error = "CLOUDFLARE_BLOCKED"
                return ""

            if use_cache:
                self.memory_cache[target_url] = html
            return html
        except Exception as e:
            log_debug("Fetch error: " + str(e))
            self.last_error = str(e)
            return ""

    def check_connection(self):
        html = self.fetch_html(self.base_url, use_cache=False)
        if self.last_error == "CLOUDFLARE_BLOCKED":
            return False, "النطاق محمي بـ Cloudflare"
        if html and len(html) > 300:
            return True, "تم الاتصال بنجاح بموقع أكوام"
        return False, self.last_error or "تعذر الاتصال بخادم أكوام"

    def get_items(self, path="/", page=1):
        """
        Unified items fetcher supporting standard lists, categories, searches,
        and specialized Year Filtering (YEAR_ALL, YEAR_MOVIES, YEAR_SERIES).
        """
        if not path:
            path = "/"

        # Handle Years Filtering Mode
        if path.startswith("YEAR_ALL:") or path.startswith("YEAR_MOVIES:") or path.startswith("YEAR_SERIES:"):
            return self.get_year_items(path, page)

        # Standard URL formatting
        if self.is_tube_site:
            clean_path = path.rstrip("/")
            if page > 1:
                if "/page/" in clean_path:
                    clean_path = re.sub(r'/page/\d+', '', clean_path)

                if "?" in clean_path:
                    # search query: /?s=batman -> /page/2/?s=batman
                    parts = clean_path.split("?", 1)
                    target_url = parts[0].rstrip("/") + ("/page/%d/?" % page) + parts[1]
                else:
                    # e.g. /list/movies/page/2/ or /all/tag/page/2/
                    target_url = clean_path + ("/page/%d/" % page)
            else:
                target_url = clean_path
                if not target_url.endswith("/") and "?" not in target_url:
                    target_url += "/"
        else:
            # Classic ak.sv / akwam pagination
            if page > 1:
                if "?" in path:
                    target_url = path + "&page=" + str(page)
                else:
                    target_url = path.rstrip("/") + "?page=" + str(page)
            else:
                target_url = path

        html = self.fetch_html(target_url)
        if not html:
            return []

        return self.parse_items_from_html(html)

    def get_year_items(self, year_cmd, page=1):
        """
        Extracts ALL movies and series for the requested year:
        - YEAR_ALL:2026 -> Merges all movies and series for 2026
        - YEAR_MOVIES:2026 -> Returns movies for 2026
        - YEAR_SERIES:2026 -> Returns series for 2026
        Groups series episodes into clean Series objects so they don't flood the list.
        """
        parts = year_cmd.split(":")
        mode = parts[0] # YEAR_ALL, YEAR_MOVIES, YEAR_SERIES
        year_val = parts[1] if len(parts) > 1 else "2026"

        log_debug("Fetching year items for [%s] mode [%s] page [%d]" % (year_val, mode, page))

        if not self.is_tube_site:
            # Classic ak.sv support
            results = []
            if mode in ("YEAR_ALL", "YEAR_MOVIES"):
                m_path = "/movies?year=%s&page=%d" % (year_val, page)
                m_html = self.fetch_html(m_path)
                results.extend(self.parse_items_from_html(m_html))
            if mode in ("YEAR_ALL", "YEAR_SERIES"):
                s_path = "/series?year=%s&page=%d" % (year_val, page)
                s_html = self.fetch_html(s_path)
                results.extend(self.parse_items_from_html(s_html))
            return results

        # -------------------------------------------------------------
        # as.akwam.tube Engine
        # -------------------------------------------------------------
        all_items = []
        seen_urls = set()

        # Step 1: Query movies tag (/all/افلام-{year}/)
        if mode in ("YEAR_ALL", "YEAR_MOVIES"):
            tag_path = "/all/%s/" % quote(("افلام-" + year_val).encode("utf-8") if not PY3 and isinstance(year_val, unicode) else ("افلام-" + str(year_val)))
            if page > 1:
                tag_path = tag_path.rstrip("/") + ("/page/%d/" % page)

            tag_html = self.fetch_html(tag_path, use_cache=True)
            if tag_html and "video-grid" in tag_html:
                movies_tag_items = self.parse_items_from_html(tag_html)
                for item in movies_tag_items:
                    item["is_series"] = False
                    if item["url"] not in seen_urls:
                        seen_urls.add(item["url"])
                        all_items.append(item)

        # Step 2: Query search endpoint for the year
        # E.g. /?s=2026 or /page/2/?s=2026
        # Needed for series, programs, and when movies are not under a tag
        search_path = "/?s=" + quote(str(year_val))
        if page > 1:
            search_path = "/page/%d/?s=%s" % (page, quote(str(year_val)))

        search_html = self.fetch_html(search_path, use_cache=True)
        if search_html and "video-grid" in search_html:
            raw_search_items = self.parse_items_from_html(search_html)

            # Smart series aggregation: group multiple episodes of the same show
            series_groups = {}
            for item in raw_search_items:
                title = item["title"]
                href = item["url"]

                is_ep = any(x in title for x in ["الحلقة", "حلقة", "الموسم", "برنامج", "الجزء"]) or "sezon" in href or "episode" in href
                if is_ep:
                    # Clean base title
                    # e.g. "مشاهدة مسلسل وطن ع وتر 2026 الحلقة 30" -> "مسلسل وطن ع وتر 2026"
                    base_name = re.sub(r'^(?:مشاهدة\s+)?(.*?)(?:\s*(?:الحلقة|حلقة|الموسم|الجزء|قسم)\s*.*)$', r'\1', title).strip()
                    base_name = re.sub(r'\s+', ' ', base_name).strip()
                    if not base_name:
                        base_name = title

                    if base_name not in series_groups:
                        series_groups[base_name] = {
                            "title": base_name + " (جميع الحلقات)",
                            "url": href,
                            "poster": item.get("poster", ""),
                            "year": year_val,
                            "quality": "FHD",
                            "duration": item.get("duration", ""),
                            "is_series": True,
                            "episodes_count": 1
                        }
                    else:
                        series_groups[base_name]["episodes_count"] += 1
                else:
                    # It is an individual movie
                    if item["url"] not in seen_urls:
                        seen_urls.add(item["url"])
                        item["is_series"] = False
                        all_items.append(item)

            # Add aggregated series
            for s_name, s_data in series_groups.items():
                if s_data["url"] not in seen_urls:
                    seen_urls.add(s_data["url"])
                    all_items.append(s_data)

        # Filter strictly if user requested Movies only or Series only
        if mode == "YEAR_MOVIES":
            return [it for it in all_items if not it.get("is_series", False)]
        elif mode == "YEAR_SERIES":
            return [it for it in all_items if it.get("is_series", False)]

        return all_items

    def parse_items_from_html(self, html):
        """
        Robust parser extracting all video items from HTML.
        Handles video-grid li tags, classic entry-box, and thumb/data structures.
        """
        if not html:
            return []

        items = []
        seen_urls = set()

        # -------------------------------------------------------------
        # 1. New Akwam Site: <li class="video-grid">...</li>
        # -------------------------------------------------------------
        li_matches = re.findall(r'<li[^>]*class=["\'][^"\']*video-grid[^"\']*["\'][^>]*>(.*?)</li>', html, re.DOTALL | re.IGNORECASE)
        if li_matches:
            for grid_html in li_matches:
                a_m = re.search(r'<a[^>]*href=["\'](https?://[^"\']*/ar/video/[^"\']+)["\']', grid_html)
                if not a_m:
                    continue
                href = a_m.group(1).strip()
                if href in seen_urls:
                    continue

                # Title
                title = ""
                t_m = re.search(r'<h[234][^>]*class=["\'][^"\']*title[^\"\']*["\'][^>]*>(.*?)</h[234]>', grid_html, re.DOTALL)
                if t_m:
                    title = re.sub(r'<[^>]+>', ' ', t_m.group(1)).strip()
                if not title:
                    alt_m = re.search(r'alt=["\']([^"\']+)["\']', grid_html)
                    if alt_m:
                        title = alt_m.group(1).strip()
                if not title or title in ("تسجيل الدخول", "إنشاء حساب"):
                    continue

                clean_title = re.sub(r'\s+', ' ', title).strip()

                # Poster
                poster = extract_poster_url(grid_html, self.domain_root)

                # Duration
                dur_m = re.search(r'class=["\'][^"\']*duration[^"\']*["\'][^>]*>([^<]+)<', grid_html)
                duration = dur_m.group(1).strip() if dur_m else ""

                # Year
                year_m = re.search(r'\(?\b(20\d\d|19\d\d)\b\)?', clean_title)
                year = year_m.group(1) if year_m else "2024"

                # Series or Movie
                is_series = any(x in clean_title for x in ["مسلسل", "الموسم", "الحلقة", "حلقة", "برنامج"]) or "-series-" in href or "sezon" in href

                quality = "FHD 1080p"
                if "HD" in clean_title:
                    quality = "HD 720p"

                seen_urls.add(href)
                items.append({
                    "title": clean_title,
                    "url": href,
                    "poster": poster,
                    "year": year,
                    "quality": quality,
                    "duration": duration,
                    "is_series": is_series
                })

        # -------------------------------------------------------------
        # 2. Classic Akwam (ak.sv / akwam.to entry-box style)
        # -------------------------------------------------------------
        if not items:
            blocks = re.findall(
                r'<div[^>]*class=["\'][^"\']*(?:entry-box|col-lg-auto|col-md-3|col-sm-4|movie-box|widget-body)[^"\']*["\'][^>]*>(.*?)</div>\s*</div>',
                html, re.DOTALL | re.IGNORECASE
            )
            if not blocks:
                blocks = re.findall(r'<div[^>]*class=["\'][^"\']*entry-box[^"\']*["\'][^>]*>(.*?)</div>', html, re.DOTALL | re.IGNORECASE)

            for inner in blocks:
                a_m = re.search(r'<a[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', inner, re.DOTALL)
                if not a_m:
                    continue
                href = a_m.group(1)
                if not href.startswith("http"):
                    href = urljoin(self.domain_root, href)
                if href in seen_urls:
                    continue

                title_m = re.search(r'<h[234][^>]*>(.*?)</h[234]>', inner, re.DOTALL)
                title = ""
                if title_m:
                    title = re.sub(r'<[^>]+>', ' ', title_m.group(1)).strip()
                if not title:
                    t_attr = re.search(r'title=["\']([^"\']+)["\']', inner)
                    if t_attr:
                        title = t_attr.group(1).strip()
                if not title or title in ("تسجيل الدخول", "إنشاء حساب"):
                    continue

                clean_title = re.sub(r'\s+', ' ', title).strip()
                poster = extract_poster_url(inner, self.domain_root)

                q_m = re.search(r'class=["\'][^"\']*(?:badge|quality)[^"\']*["\'][^>]*>([^<]*)<', inner, re.IGNORECASE)
                quality = q_m.group(1).strip() if q_m else "1080p FHD"

                year_m = re.search(r'\(?\b(20\d\d|19\d\d)\b\)?', clean_title + " " + inner)
                year = year_m.group(1) if year_m else "2024"

                is_series = any(x in clean_title for x in ["مسلسل", "الموسم", "الحلقة", "برنامج"]) or "/series/" in href or "/show/" in href

                seen_urls.add(href)
                items.append({
                    "title": clean_title,
                    "url": href,
                    "poster": poster,
                    "year": year,
                    "quality": quality,
                    "duration": "",
                    "is_series": is_series
                })

        return items

    def get_episodes(self, series_url):
        """
        Extracts all episodes for a TV series or program.
        Works with both series overview pages and individual episode pages.
        """
        html = self.fetch_html(series_url)
        if not html:
            return []
        episodes = []
        seen_urls = set()

        # On as.akwam.tube, video pages link to all related episodes (e.g. "حلقة 1", "حلقة 2" ... "حلقة 30")
        ep_matches = re.findall(
            r'<a[^>]*href=["\'](https?://[^"\']*(?:/ar/video/|/episode/|/watch/)[^"\']*)["\'][^>]*>(.*?)</a>',
            html, re.DOTALL | re.IGNORECASE
        )
        for href, inner in ep_matches:
            if href in seen_urls:
                continue
            clean_text = re.sub(r'<[^>]+>', ' ', inner).strip()

            num_m = re.search(r'(?:الحلقة|Episode|حلقة)\s*(\d+|الأخيرة|[0-9]+)', clean_text, re.IGNORECASE)
            if num_m:
                ep_title = "الحلقة " + str(num_m.group(1)).strip()
            else:
                num_url = re.search(r'episode[_-]?(\d+)', href, re.I)
                if num_url:
                    ep_title = "الحلقة " + num_url.group(1)
                elif "الحلقة" in clean_text or "حلقة" in clean_text:
                    ep_title = clean_text[:40]
                else:
                    continue

            seen_urls.add(href)
            episodes.append({"title": ep_title, "url": href})

        # Sort episodes numerically if possible
        def ep_sort_key(ep):
            digits = re.search(r'\d+', ep["title"])
            return int(digits.group(0)) if digits else 9999

        try:
            episodes.sort(key=ep_sort_key)
        except Exception:
            pass

        return episodes

    def get_servers(self, media_url):
        servers = []
        if not media_url:
            return servers

        log_debug("Fetching servers for: " + media_url)
        html = self.fetch_html(media_url)
        if not html:
            return servers

        # -------------------------------------------------------------
        # 1. New Akwam Site (as.akwam.tube): Embed & AlbaPlayer Servers
        # -------------------------------------------------------------
        embed_urls = re.findall(r'https?://as\.akwam\.tube/embed/\d+/', html)
        if not embed_urls:
            embed_id_m = re.search(r'/ar/video/.*?-(\d+)/', media_url)
            if embed_id_m:
                embed_urls = ["https://as.akwam.tube/embed/%s/" % embed_id_m.group(1)]

        for emb_url in set(embed_urls):
            log_debug("Processing embed URL: " + emb_url)
            emb_html = self.fetch_html(emb_url, use_cache=False, custom_headers={"Referer": media_url})
            if not emb_html:
                continue

            # Check iframes inside embed (AlbaPlayer e.g. w.froozla.pro, w.aflamy.pro)
            iframe_m = re.search(r'<iframe[^>]*src=["\'](https?://[^"\']*/albaplayer/[^"\']*)["\']', emb_html, re.I)
            if iframe_m:
                alba_url = iframe_m.group(1)
                log_debug("Found AlbaPlayer URL: " + alba_url)
                alba_html = self.fetch_html(alba_url, use_cache=False, custom_headers={"Referer": emb_url})
                if alba_html:
                    # Check servers in AlbaPlayer menu:
                    server_links = re.findall(
                        r'<a[^>]*class=["\'][^"\']*aplr-link[^"\']*["\'][^>]*href=["\'](https?://[^"\']+)["\'][^>]*>([^<]+)</a>',
                        alba_html, re.I
                    )
                    for s_link, s_name in server_links:
                        s_name = s_name.strip()
                        if not s_name or "icon" in s_name.lower() or "refresh" in s_name.lower():
                            continue
                        servers.append({
                            "name": "سيرفر " + s_name + " (سريع ومباشر)",
                            "url": s_link,
                            "quality": "1080p FHD",
                            "type": "alba"
                        })

                    direct_iframe = re.search(r'<iframe[^>]*src=["\'](https?://[^"\']+)["\']', alba_html, re.I)
                    if direct_iframe and not servers:
                        s_iframe = direct_iframe.group(1)
                        servers.append({
                            "name": "سيرفر المشاهدة السريع (Direct Stream)",
                            "url": s_iframe,
                            "quality": "Auto",
                            "type": "direct_iframe"
                        })

            all_iframes = re.findall(r'<iframe[^>]*src=["\'](https?://[^"\']+)["\']', emb_html, re.I)
            for ifr in all_iframes:
                if not any(s["url"] == ifr for s in servers):
                    servers.append({
                        "name": "مشغل الفيديو المباشر",
                        "url": ifr,
                        "quality": "HD",
                        "type": "iframe"
                    })

        # -------------------------------------------------------------
        # 2. Classic Akwam (ak.sv / akwam.to): Direct download links
        # -------------------------------------------------------------
        watch_url = media_url if "/watch" in media_url else (media_url.rstrip("/") + "/watch")
        watch_html = self.fetch_html(watch_url, use_cache=True)
        combined_html = (html or "") + "\n" + (watch_html or "")

        link_matches = re.findall(
            r'href=["\'](https?://[^"\']*/download/[^"\']+)["\']',
            combined_html, re.IGNORECASE
        )
        seen_links = []
        for l in link_matches:
            if l in seen_links:
                continue
            seen_links.append(l)

            quality = "Direct"
            ctx = ""
            idx = combined_html.find(l)
            if idx != -1:
                ctx = combined_html[max(0, idx - 400): idx + 400]
            q_m = re.search(r'(1080|720|480|360)\s*p?', ctx, re.I)
            if q_m:
                quality = q_m.group(1) + "p"

            size_m = re.search(r'([0-9.]+\s*(?:GB|MB))', ctx, re.I)
            size_txt = (" - " + size_m.group(1)) if size_m else ""

            servers.append({
                "name": "سيرفر أكوام المباشر " + quality + size_txt,
                "url": l,
                "quality": quality,
                "type": "akwam_direct"
            })

        return servers

    def resolve_stream_url(self, server_url):
        if not server_url:
            return "", ""

        log_debug("Resolving stream from: " + server_url)
        parsed = urlparse(server_url)
        referer = "%s://%s/" % (parsed.scheme or "https", parsed.netloc)
        low = server_url.lower()

        # If already direct stream
        if any(ext in low for ext in [".m3u8", ".mp4", ".mkv", ".ts", "/hls/"]):
            return server_url, referer

        # Case A: AlbaPlayer Server Link (?serv=1, ?serv=2, etc.)
        if "/albaplayer/" in low:
            alba_html = self.fetch_html(server_url, use_cache=False, custom_headers={"Referer": self.domain_root + "/"})
            if alba_html:
                sub_iframe = re.search(r'<iframe[^>]*src=["\'](https?://[^"\']+)["\']', alba_html, re.I)
                if sub_iframe:
                    target_player = sub_iframe.group(1)
                    log_debug("Alba sub-iframe found: " + target_player)
                    return self.resolve_embedded_host(target_player)

        # Case B: Embedded Hosts (MP4Plus, AnaFast, Vidoba, VidSpeed, OK, VOE)
        return self.resolve_embedded_host(server_url)

    def resolve_embedded_host(self, host_url):
        log_debug("Resolving host URL: " + host_url)
        parsed = urlparse(host_url)
        referer = "%s://%s/" % (parsed.scheme or "https", parsed.netloc)
        low = host_url.lower()

        html = self.fetch_html(host_url, use_cache=False, custom_headers={"Referer": referer})
        if not html:
            return "", referer

        # Direct .mp4 from video CDN (aflm-s6... or cdnz...)
        mp4_direct = re.findall(r'["\'](https?://[^"\'\s]+\.(?:mp4|mkv|ts)[^"\'\s]*)["\']', html, re.I)
        for m in mp4_direct:
            if not m.endswith(".jpg") and not m.endswith(".png"):
                log_debug("Found direct MP4 link: " + m)
                return m, referer

        # Direct m3u8
        m3u8_direct = re.findall(r'["\'](https?://[^"\'\s]+\.m3u8[^"\'\s]*)["\']', html, re.I)
        if m3u8_direct:
            log_debug("Found direct M3U8 link: " + m3u8_direct[0])
            return m3u8_direct[0], referer

        # VOE
        voe_hls = re.search(r'["\']hls["\']\s*:\s*["\']([^"\']+)["\']', html)
        if voe_hls:
            return voe_hls.group(1), referer

        # Classic packed JS unpack
        packed = re.search(r'(eval\(function\(p,a,c,k,e,d\).+?{}\)\))', html, re.DOTALL)
        if packed:
            try:
                unpacked = self.unpack_js(packed.group(1))
                m_unp = re.findall(r'["\'](https?://[^"\'\s]+\.(?:m3u8|mp4)[^"\'\s]*)["\']', unpacked, re.I)
                if m_unp:
                    return m_unp[0], referer
            except Exception as e:
                log_debug("Unpack error: " + str(e))

        # Classic Akwam /download/ chain
        if "/download/" in low or "/link/" in low:
            akwam_direct = self.resolve_akwam_direct(host_url)
            if akwam_direct:
                return akwam_direct, self.domain_root + "/"

        return "", referer

    def resolve_akwam_direct(self, link_url):
        try:
            current = link_url
            hdrs = {"Referer": self.domain_root + "/"}

            if "/link/" in current.lower():
                page = self.fetch_html(current, use_cache=False, custom_headers=hdrs)
                if not page:
                    return ""
                dl = re.search(r'href=["\'](https?://[^"\']*/download/[^"\']+)["\']', page, re.I)
                if not dl:
                    dl = re.search(r'(https?://[^"\'\s]*/download/[^"\'\s]+)', page, re.I)
                if not dl:
                    return ""
                current = dl.group(1)

            page2 = self.fetch_html(current, use_cache=False, custom_headers=hdrs)
            if not page2:
                return ""

            direct = re.search(r'href=["\'](https?://[^"\']+\.(?:mp4|mkv|avi|ts)[^"\']*)["\']', page2, re.I)
            if direct:
                return direct.group(1)

            direct2 = re.search(r'(https?://[a-z0-9.\-]+/download/[^"\'\s]+\.(?:mp4|mkv|avi|ts)[^"\'\s]*)', page2, re.I)
            if direct2:
                return direct2.group(1)

            return ""
        except Exception as e:
            log_debug("resolve_akwam_direct error: " + str(e))
            return ""

    def unpack_js(self, packed_str):
        m = re.search(r"}\('(.*)',\s*(\d+),\s*(\d+),\s*'(.*?)'\.split\('\|'\)", packed_str, re.DOTALL)
        if not m:
            return ""
        payload, radix, count, symtab = m.groups()
        radix = int(radix)
        symbols = symtab.split('|')

        def lookup(match):
            word = match.group(0)
            val = baseN_decode(word, radix)
            return symbols[val] if val < len(symbols) and symbols[val] else word

        return re.sub(r'\b\w+\b', lookup, payload)
