# -*- coding: utf-8 -*-
"""Ultra Stalker UI-only localization.

Translations are loaded lazily per selected interface language.  English needs
no language pack at runtime.  Arabic, German, French and Turkish are shipped as
reviewed built-in JSON packs, while the other reviewed interface packs keep the
same external-pack format.  Provider-originated names/content are never passed
through this translator.
"""
import gettext
import json
import os
import threading

from .language_catalog import interface_language_name, normalize_interface_code, pack_path

CONFIG_FILE = "/etc/enigma2/ultrastalker/settings.json"
LOCALE_DIR = os.path.join(os.path.dirname(__file__), "locale")
_PACK_DIR = os.path.join(os.path.dirname(__file__), "locale_packs")
_BUILTIN_CODES = frozenset(("en", "ar", "de", "fr", "tr"))

_LOCK = threading.RLock()
_LANG_OVERRIDE = None
_CACHE_SIGNATURE = None
_CACHE_LANGUAGE = "en"
_AR_GETTEXT = None
_EXTERNAL_PACKS = {}


def _settings_signature():
    try:
        st = os.stat(CONFIG_FILE)
        return (getattr(st, "st_mtime_ns", int(st.st_mtime * 1000000000)), st.st_size)
    except OSError:
        return None


def _pack_file(code):
    code = normalize_interface_code(code)
    if code in ("ar", "de", "fr", "tr"):
        return os.path.join(_PACK_DIR, "%s.json" % code)
    return pack_path(code)


def _external_pack(code):
    code = normalize_interface_code(code)
    if code == "en" or not code:
        return {}
    with _LOCK:
        if code in _EXTERNAL_PACKS:
            return _EXTERNAL_PACKS.get(code) or {}
    data = {}
    try:
        path = _pack_file(code)
        if path and os.path.isfile(path) and os.path.getsize(path) <= 4 * 1024 * 1024:
            with open(path, "r", encoding="utf-8") as handle:
                value = json.load(handle)
            if isinstance(value, dict):
                value = value.get("translations") if isinstance(value.get("translations"), dict) else {}
                data = {str(k): str(v) for k, v in value.items() if v not in (None, "")}
    except Exception:
        data = {}
    with _LOCK:
        _EXTERNAL_PACKS[code] = data
    return data


def _language_available(code):
    code = normalize_interface_code(code)
    if code in _BUILTIN_CODES:
        return True
    return bool(_external_pack(code))


def _read_language():
    global _CACHE_SIGNATURE, _CACHE_LANGUAGE
    sig = _settings_signature()
    with _LOCK:
        if _LANG_OVERRIDE and _language_available(_LANG_OVERRIDE):
            return _LANG_OVERRIDE
        if sig == _CACHE_SIGNATURE:
            return _CACHE_LANGUAGE
    code = "en"
    try:
        if sig and os.path.getsize(CONFIG_FILE) <= 1024 * 1024:
            with open(CONFIG_FILE, "r", encoding="utf-8") as handle:
                data = json.load(handle)
            candidate = normalize_interface_code((data or {}).get("plugin_language") or "en")
            if _language_available(candidate):
                code = candidate
    except Exception:
        code = "en"
    with _LOCK:
        _CACHE_SIGNATURE = sig
        _CACHE_LANGUAGE = code
    return code


def set_plugin_language(code):
    global _LANG_OVERRIDE, _CACHE_LANGUAGE
    code = normalize_interface_code(code)
    if not _language_available(code):
        code = "en"
    with _LOCK:
        _LANG_OVERRIDE = code
        _CACHE_LANGUAGE = code
    return code


def clear_language_override():
    global _LANG_OVERRIDE, _CACHE_SIGNATURE
    with _LOCK:
        _LANG_OVERRIDE = None
        _CACHE_SIGNATURE = None


def current_language():
    return _read_language()


def language_name(code=None):
    return interface_language_name(code or _read_language())


def _arabic_gettext(text):
    global _AR_GETTEXT
    try:
        if _AR_GETTEXT is None:
            path = os.path.join(LOCALE_DIR, "ar", "LC_MESSAGES", "UltraStalker.mo")
            with open(path, "rb") as handle:
                _AR_GETTEXT = gettext.GNUTranslations(handle)
        value = _AR_GETTEXT.gettext(text)
        return value if value != text else None
    except Exception:
        return None


def translate(text):
    if text is None:
        return ""
    original = str(text)
    code = _read_language()
    if code == "en" or not original:
        return original
    value = _external_pack(code).get(original)
    if value:
        return value
    if code == "ar":
        value = _arabic_gettext(original)
        if value:
            return value
    return original
