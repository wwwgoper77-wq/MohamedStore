# -*- coding: utf-8 -*-
"""Ultra Stalker receiver-local media library.

R56 turns Local into a first-class media source:
- Local Home is only three Home-style cards on the Palestine master background.
- Movies / Series open the *existing* Premium Global Cinematic presentation.
- Local storage is scanned lazily only when Movies / Series is opened.
- Local poster/backdrop files are reused immediately when present.
- Missing metadata/artwork is left to the existing TMDb/cache authority, so it is
  resolved once and reused from HDD on later visits.
- Series use the native Details -> Seasons -> Episodes hierarchy.
- Playback stays on the existing UltraStalkerPlayer via a local-path client.
- Browse remains a clean glass-card grid for manual filesystem access.
"""
from __future__ import absolute_import

import hashlib
import json
import os
from collections import OrderedDict
import re
import threading
import time

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from enigma import ePoint, eTimer

from . import _
from .storage import load_settings
from .title_clean import display_title as _display_title
from .ui_fixed_adaptive import fixed_home_assets
from .persistent_cache import INDEX as _CACHE_INDEX, hdd_ready as _hdd_ready, hdd_read_ready as _hdd_read_ready, ensure_persistent_dirs as _ensure_cache_dirs, persistent_write_gate as _persistent_write_gate


VIDEO_EXTENSIONS = {
    ".mkv", ".mp4", ".avi", ".mov", ".m4v", ".ts", ".m2ts", ".mts",
    ".webm", ".mpg", ".mpeg", ".vob", ".wmv", ".flv", ".3gp",
}
IMAGE_EXTENSIONS = (".jpg", ".jpeg", ".png", ".webp")
MOVIE_DIR_NAMES = {
    "movie", "movies", "film", "films", "video", "videos", "vod",
    "افلام", "أفلام", "فيلم",
}
SERIES_DIR_NAMES = {
    "series", "serie", "serial", "serials", "tv", "tvshow", "tvshows",
    "tv show", "tv shows", "shows", "show", "مسلسل", "مسلسلات",
}
SEASON_RE = re.compile(r"(?i)^(?:season|series|s)[ ._-]*(\d{1,3})$")
_BARE_SEASON_RE = re.compile(r"^\s*0*(\d{1,3})\s*$")
_LOCALIZED_SEASON_RE = re.compile(r"(?iu)^(?:part|pt|الموسم|موسم|الجزء|جزء)[ ._-]*(\d{1,3})$")
EPISODE_RE = re.compile(r"(?i)(?:\bS(\d{1,3})[ ._-]*E(\d{1,4})\b|\b(\d{1,3})x(\d{1,4})\b)")
YEAR_RE = re.compile(r"(?<!\d)((?:19|20)\d{2})(?!\d)")
_SIMPLE_EPISODE_RE = re.compile(r"(?iu)^\s*(?:(episode|ep|e|الحلقة|حلقه)[ ._-]*)?0*(\d{1,4})(?:[ ._-]+.*)?$")
_EPISODE_FALSE_NUMBERS = {360, 480, 576, 720, 1080, 1440, 2160, 4320}

# R57: Local Movies/Series scan the storage itself instead of trusting one
# specially named library folder.  Technical receiver/cache trees are pruned so
# a media scan never wastes time walking picons, backups or Ultra Stalker cache.
_MEDIA_SCAN_SKIP = {
    "ajpanel backup", "ajpanel eliesatpanel", "backup", "backups",
    "channels backup", "crossepg", "imagebackups", "picon", "setpicon",
    "timeshift", "title logos", "transmission", "ultrastalker",
    "lost+found", "cache", "tmp", "temp",
}
RECEIVER_LOCAL_ROOT = "/home/root"

# R60 Local index: classification is expensive only once.  The index lives in
# Ultra Stalker's existing HDD index directory, not in a separate Local cache.
# Movies/Series reopen from this compact JSON without walking the HDD again.
_LOCAL_INDEX_SCHEMA = 4
_LOCAL_INDEX_PATH = os.path.join(_CACHE_INDEX, "local_media_index_v3.json")
_LOCAL_INDEX_LOCK = threading.RLock()
_LOCAL_INDEX_MEMORY_MAX = 4
_LOCAL_INDEX_MEMORY = OrderedDict()


def _remember_local_media_index(key,row):
    if not isinstance(row,dict):
        return
    with _LOCAL_INDEX_LOCK:
        try:_LOCAL_INDEX_MEMORY.pop(key,None)
        except Exception:pass
        _LOCAL_INDEX_MEMORY[key]=dict(row)
        while len(_LOCAL_INDEX_MEMORY)>_LOCAL_INDEX_MEMORY_MAX:
            try:_LOCAL_INDEX_MEMORY.popitem(last=False)
            except Exception:break


def _local_index_key(roots):
    values=[]
    for path in roots or []:
        try:values.append(os.path.realpath(str(path or "")))
        except Exception:pass
    return tuple(sorted(set(x for x in values if x)))


def _load_local_media_index(roots):
    key=_local_index_key(roots)
    with _LOCAL_INDEX_LOCK:
        row=_LOCAL_INDEX_MEMORY.get(key)
        if isinstance(row,dict):
            try:_LOCAL_INDEX_MEMORY.move_to_end(key)
            except Exception:pass
            return dict(row)
    if not _hdd_read_ready():return {}
    try:
        with open(_LOCAL_INDEX_PATH,"r",encoding="utf-8") as h:row=json.load(h)
        if not isinstance(row,dict) or int(row.get("schema") or 0)!=_LOCAL_INDEX_SCHEMA:return {}
        if tuple(row.get("roots") or ())!=key:return {}
        if not isinstance(row.get("movies"),list) or not isinstance(row.get("series"),list):return {}
        _remember_local_media_index(key,row)
        return row
    except Exception:
        return {}


def _save_local_media_index(roots,movies,groups):
    key=_local_index_key(roots)
    movie_rows=[]
    for raw in movies or []:
        path=str(raw.get("path") if isinstance(raw,dict) else raw or "")
        if not path:continue
        title=str(raw.get("title") or "") if isinstance(raw,dict) else ""
        if not title:title=_clean_filename(path)
        movie_rows.append({
            "path":path,"title":title,"year":str((raw.get("year") if isinstance(raw,dict) else "") or _year_from(os.path.basename(path)))[:4],
            "poster":str((raw.get("poster") if isinstance(raw,dict) else "") or _sidecar_art(path,"poster") or ""),
            "backdrop":str((raw.get("backdrop") if isinstance(raw,dict) else "") or _sidecar_art(path,"backdrop") or ""),
        })
    payload={
        "schema":_LOCAL_INDEX_SCHEMA,"roots":list(key),"built_at":int(time.time()),
        "movies":movie_rows,"series":[],
    }
    for _key,group in (groups or {}).items():
        if not isinstance(group,dict):continue
        series_dir=str(group.get("dir") or "")
        payload["series"].append({
            "title":str(group.get("title") or ""),"dir":series_dir,
            "poster":str(group.get("poster") or _sidecar_art(series_dir,"poster") or ""),
            "backdrop":str(group.get("backdrop") or _sidecar_art(series_dir,"backdrop") or ""),
            "episodes":[[str(x[0]),int(x[1]),int(x[2]),str(x[3] or "")] for x in (group.get("episodes") or []) if isinstance(x,(list,tuple)) and len(x)>=4],
        })
    _remember_local_media_index(key,payload)
    if not _hdd_ready():return False
    try:
        if not _ensure_cache_dirs(_CACHE_INDEX):return False
        temp=_LOCAL_INDEX_PATH+".tmp.%d.%d"%(os.getpid(),threading.get_ident())
        if not _persistent_write_gate(temp):return False
        with open(temp,"w",encoding="utf-8") as h:
            json.dump(payload,h,ensure_ascii=False,separators=(",",":"));h.flush();os.fsync(h.fileno())
        if not _persistent_write_gate(_LOCAL_INDEX_PATH):return False
        os.replace(temp,_LOCAL_INDEX_PATH)
        return True
    except Exception:
        try:
            if os.path.exists(temp) and _persistent_write_gate(temp):os.unlink(temp)
        except Exception:pass
        return False


def _decode_local_media_index(row):
    movies=[]
    for raw in row.get("movies") or []:
        if isinstance(raw,dict) and raw.get("path"):
            movies.append({"path":str(raw.get("path")),"title":str(raw.get("title") or ""),"year":str(raw.get("year") or "")[:4],"poster":str(raw.get("poster") or ""),"backdrop":str(raw.get("backdrop") or "")})
        elif raw:
            movies.append({"path":str(raw),"title":"","year":"","poster":"","backdrop":""})
    groups={}
    for idx,group in enumerate(row.get("series") or []):
        if not isinstance(group,dict):continue
        title=str(group.get("title") or "").strip();series_dir=str(group.get("dir") or "")
        episodes=[]
        for x in group.get("episodes") or []:
            try:episodes.append((str(x[0]),int(x[1]),int(x[2]),str(x[3] or "")))
            except Exception:continue
        if title and episodes:groups[(idx,title,series_dir)]={"title":title,"dir":series_dir,"poster":str(group.get("poster") or ""),"backdrop":str(group.get("backdrop") or ""),"episodes":episodes}
    return movies,groups


def _invalidate_local_media_index(roots=None):
    key=_local_index_key(roots or []) if roots is not None else None
    with _LOCAL_INDEX_LOCK:
        if key is None:_LOCAL_INDEX_MEMORY.clear()
        else:_LOCAL_INDEX_MEMORY.pop(key,None)
    try:
        if _hdd_ready() and os.path.isfile(_LOCAL_INDEX_PATH) and _persistent_write_gate(_LOCAL_INDEX_PATH):os.unlink(_LOCAL_INDEX_PATH)
    except Exception:pass


def _asset(name):
    return os.path.join(os.path.dirname(__file__), "assets_fhd", str(name or ""))


def _natural_key(value):
    return [int(x) if x.isdigit() else x.lower() for x in re.split(r"(\d+)", str(value or ""))]


def _norm(value):
    text = str(value or "").strip().casefold().replace("_", " ").replace("-", " ")
    return " ".join(text.split())


def _clean_text(value):
    raw = re.sub(r"[._]+", " ", str(value or ""))
    raw = re.sub(r"\s+", " ", raw).strip()
    try:
        return str(_display_title(raw, enabled=True) or raw).strip()
    except Exception:
        return raw


def _clean_filename(path):
    return _clean_text(os.path.splitext(os.path.basename(path))[0])


def _is_storage_path(path):
    try:
        path = os.path.realpath(path)
        if not os.path.isdir(path):
            return False
        root_dev = os.stat("/").st_dev
        return os.stat(path).st_dev != root_dev or os.path.ismount(path)
    except Exception:
        return False


def _storage_roots():
    candidates = ["/media/hdd", "/media/usb"]
    for base in ("/media", "/mnt"):
        try:
            for name in os.listdir(base):
                candidates.append(os.path.join(base, name))
        except Exception:
            pass
    out, seen = [], set()
    for raw in candidates:
        try:
            real = os.path.realpath(raw)
        except Exception:
            continue
        if real in seen or not _is_storage_path(real):
            continue
        seen.add(real)
        out.append(real)
    # Explicit receiver-local browse/scan root.  It is intentionally *not* fed
    # through _is_storage_path because it lives on the receiver root filesystem.
    try:
        receiver = os.path.realpath(RECEIVER_LOCAL_ROOT)
        if os.path.isdir(receiver) and receiver not in seen:
            seen.add(receiver);out.append(receiver)
    except Exception:
        pass
    hdd = os.path.realpath("/media/hdd")
    receiver = os.path.realpath(RECEIVER_LOCAL_ROOT)
    def order_key(path):
        low = str(path or "").lower()
        if path == hdd:return (0, _natural_key(path))
        if path == receiver:return (1, _natural_key(path))
        if "usb" in low:return (2, _natural_key(path))
        return (3, _natural_key(path))
    out.sort(key=order_key)
    return out


def _discover_named_dirs(roots, aliases):
    aliases = {_norm(x) for x in aliases}
    found, seen = [], set()
    for root in roots:
        try:
            names = os.listdir(root)
        except Exception:
            continue
        for name in names:
            if name.startswith(".") or _norm(name) not in aliases:
                continue
            path = os.path.realpath(os.path.join(root, name))
            try:
                if not os.path.isdir(path) or path in seen:
                    continue
            except Exception:
                continue
            seen.add(path)
            found.append(path)
    found.sort(key=_natural_key)
    return found


def _iter_video_files(base, cancel_event=None):
    """Yield playable local media while pruning receiver/cache-only trees."""
    for current, dirs, files in os.walk(base):
        if cancel_event is not None and cancel_event.is_set():
            return
        kept=[]
        for d in dirs:
            if d.startswith(".") or d == "@eaDir":
                continue
            if _norm(d) in _MEDIA_SCAN_SKIP:
                continue
            kept.append(d)
        dirs[:] = kept
        for name in files:
            if name.startswith("."):
                continue
            if os.path.splitext(name)[1].lower() in VIDEO_EXTENSIONS:
                yield os.path.join(current, name)


def _stable_id(prefix, value):
    digest = hashlib.sha1(os.path.realpath(str(value or "")).encode("utf-8", "ignore")).hexdigest()[:20]
    return "%s-%s" % (prefix, digest)


def _year_from(value):
    match = YEAR_RE.search(str(value or ""))
    return match.group(1) if match else ""



def _simple_episode_number(value):
    """Return a conservative episode number for filenames like 08 / E08 / Episode 08.

    Bare four-digit movie years/resolutions are deliberately rejected.  This is
    used only after folder context says the file is series-like.
    """
    stem=os.path.splitext(os.path.basename(str(value or "")))[0]
    match=_SIMPLE_EPISODE_RE.match(stem)
    if not match:return None
    try:number=int(match.group(2) or 0)
    except Exception:return None
    if number<=0 or number>9999:return None
    explicit=bool(match.group(1))
    if not explicit:
        if number in _EPISODE_FALSE_NUMBERS:return None
        if 1900<=number<=2099:return None
        # Bare numeric episode filenames above three digits are too ambiguous.
        if len(str(number))>3:return None
    return number


def _is_under(path, root):
    try:
        real=os.path.realpath(path);base=os.path.realpath(root)
        return real==base or real.startswith(base.rstrip("/")+"/")
    except Exception:return False


def _meaningful_series_dir(path):
    name=os.path.basename(os.path.realpath(str(path or "")).rstrip("/"))
    norm=_norm(name)
    generic={_norm(x) for x in (MOVIE_DIR_NAMES|SERIES_DIR_NAMES)}|set(_MEDIA_SCAN_SKIP)|{"hdd","usb","media","mnt","root"}
    return bool(name and norm and norm not in generic)


def _season_dir_number(value, allow_bare=False):
    """Return a real season number from a folder label.

    Named labels (Season 2 / S02 / Part 2 / الموسم 2) are always accepted.
    Bare numeric folders (1 / 02 / 3) are accepted only when the caller has
    already established series/show context.  Keeping that context requirement
    prevents numeric movie/show titles such as ``24`` from being mistaken for a
    season at the library root.
    """
    text=str(value or "").strip()
    match=SEASON_RE.match(text) or _LOCALIZED_SEASON_RE.match(text)
    if not match and allow_bare:
        match=_BARE_SEASON_RE.match(text)
    if not match:return None
    try:number=int(match.group(1) or 0)
    except Exception:return None
    if number<1 or number>999:return None
    return number


def _named_series_show_dir(path, named_roots):
    """Return the first show folder below a conventional Series/TV root."""
    real=os.path.realpath(path)
    for root in sorted([os.path.realpath(x) for x in (named_roots or [])],key=len,reverse=True):
        if not _is_under(real,root) or real==root:continue
        try:parts=os.path.relpath(real,root).split(os.sep)
        except Exception:continue
        # parts includes the filename.  A show folder must exist before it.
        if len(parts)>=2 and not SEASON_RE.match(str(parts[0] or "").strip()):
            return os.path.join(root,parts[0])
    return ""


def _smart_series_identity(path, named_series_roots=None, direct_stats=None):
    """Classify one local video as an episode using filename + folder structure.

    Priority is explicit SxxEyy/1x02 and Season folders, followed by receiver-local
    library structure: Series/Show/08.mkv or Show/08.mkv.  Numeric files inside a
    movie/vod tree need multiple episode-like siblings before they are promoted to
    a series, preventing numeric movie titles from being stolen by the TV lane.
    """
    explicit=_series_identity(path)
    if explicit:
        title,season,episode,episode_title,series_dir=explicit
        # Repair a generic fallback title (e.g. .../series/Season 01/08.mkv)
        # from the first meaningful show folder when one exists.
        show_dir=_named_series_show_dir(path,named_series_roots or [])
        if show_dir and _norm(title) in ({_norm(x) for x in SERIES_DIR_NAMES}|{_norm(x) for x in MOVIE_DIR_NAMES}):
            title=_clean_text(os.path.basename(show_dir.rstrip("/")));series_dir=show_dir
        return title,season,episode,episode_title,series_dir

    parent=os.path.dirname(os.path.realpath(path));stem=os.path.splitext(os.path.basename(path))[0]
    simple=_simple_episode_number(stem)
    show_dir=_named_series_show_dir(path,named_series_roots or [])
    season=1
    # If a conventional Series/TV root owns the file, the first child folder is
    # the show identity even when episodes are named only 01.mkv / Pilot.mkv.
    if show_dir:
        cur=parent
        while _is_under(cur,show_dir) and cur!=show_dir:
            # R66: many receiver libraries use bare numeric season folders:
            #   Series/Bloodhounds/1/01.mkv
            #   Series/Bloodhounds/2/01.mkv
            # In established show context, 1/2 are Season 1/2, not generic
            # subfolders.  This keeps duplicate episode numbers separated.
            parsed_season=_season_dir_number(os.path.basename(cur.rstrip("/")),allow_bare=True)
            if parsed_season is not None:
                season=int(parsed_season)
                break
            nxt=os.path.dirname(cur.rstrip("/")) or cur
            if nxt==cur:break
            cur=nxt
        stats=(direct_stats or {}).get(parent,{})
        episode=simple
        if episode is None:
            # In an explicit Series tree, arbitrary episode labels are legal.
            # Give them a stable natural-order number supplied by the inventory.
            episode=(stats.get("ordinal") or {}).get(os.path.realpath(path))
        if episode:
            title=_clean_text(os.path.basename(show_dir.rstrip("/")))
            ep_title=_clean_text(stem)
            if not ep_title or ep_title==str(episode):ep_title=_("Episode %s")%int(episode)
            return title,int(season),int(episode),ep_title,show_dir

    # R66: outside a conventionally named Series/TV root, a bare numeric
    # parent folder still carries season meaning when its parent is a sensible
    # show folder.  Example: /media/hdd/My Show/2/08.mkv.
    bare_season=_season_dir_number(os.path.basename(parent.rstrip("/")),allow_bare=True)
    if simple is not None and bare_season is not None:
        show_parent=os.path.dirname(parent.rstrip("/"))
        if _meaningful_series_dir(show_parent):
            stats=(direct_stats or {}).get(parent,{})
            if int(stats.get("count") or 0)>=1:
                title=_clean_text(os.path.basename(show_parent.rstrip("/")))
                ep_title=_clean_text(stem)
                if not ep_title or ep_title==str(simple):ep_title=_("Episode %s")%int(simple)
                return title,int(bare_season),int(simple),ep_title,show_parent

    if simple is None or not _meaningful_series_dir(parent):return None
    stats=(direct_stats or {}).get(parent,{})
    simple_count=int(stats.get("simple_count") or 0);count=int(stats.get("count") or 0)
    parent_parent=_norm(os.path.basename(os.path.dirname(parent.rstrip("/"))))
    movie_parents={_norm(x) for x in MOVIE_DIR_NAMES}
    # Outside a named Series root, a direct numeric/Episode filename is accepted
    # when the folder clearly contains an episode run.  A single episode is also
    # accepted outside a conventional movie/vod folder.
    if simple_count<2 and parent_parent in movie_parents:return None
    if simple_count<1 or count<1:return None
    title=_clean_text(os.path.basename(parent.rstrip("/")))
    ep_title=_clean_text(stem)
    if not ep_title or ep_title==str(simple):ep_title=_("Episode %s")%int(simple)
    return title,1,int(simple),ep_title,parent


def _series_identity(path):
    stem = os.path.splitext(os.path.basename(path))[0]
    parent = os.path.dirname(path)
    parent_name = os.path.basename(parent.rstrip("/"))
    season_dir_match = SEASON_RE.match(parent_name.strip())
    match = EPISODE_RE.search(stem)
    fallback_match = None
    if not match and season_dir_match:
        # Common local-library layouts use Season 01/01.mkv or
        # Season 01/Episode 01.mkv instead of repeating S01E01 in every file.
        fallback_match = re.search(r"(?i)(?:^|[ ._-])(?:episode|ep|e)[ ._-]*(\d{1,4})(?:\b|$)", stem)
        if not fallback_match:
            fallback_match = re.search(r"^\s*(\d{1,4})(?:[ ._-]|$)", stem)
    if not match and not fallback_match:
        return None
    if match:
        season = int(match.group(1) or match.group(3) or 0)
        episode = int(match.group(2) or match.group(4) or 0)
        prefix = re.sub(r"[._-]+", " ", stem[:match.start()]).strip()
        suffix = re.sub(r"^[ ._-]+", "", stem[match.end():])
    else:
        season = int(season_dir_match.group(1) or 0)
        episode = int(fallback_match.group(1) or 0)
        prefix = ""
        suffix = re.sub(r"^[ ._-]+", "", stem[fallback_match.end():])
    series_dir = os.path.dirname(parent) if season_dir_match else parent
    title = _clean_text(prefix) if prefix else _clean_text(os.path.basename(series_dir.rstrip("/")))
    if not title:
        title = _clean_text(os.path.basename(os.path.dirname(parent).rstrip("/")))
    episode_title = _clean_text(suffix)
    if not episode_title or episode_title == title:
        episode_title = _("Episode %s") % episode
    return title, season, episode, episode_title, series_dir


def _first_existing(candidates):
    for path in candidates:
        try:
            if path and os.path.isfile(path) and os.path.getsize(path) > 100:
                return path
        except Exception:
            pass
    return ""


def _sidecar_art(video_or_dir, kind):
    """Reuse common local-media artwork names without copying or rescaling them."""
    is_dir = os.path.isdir(video_or_dir)
    base_dir = video_or_dir if is_dir else os.path.dirname(video_or_dir)
    stem = "" if is_dir else os.path.splitext(os.path.basename(video_or_dir))[0]
    names = []
    if kind == "poster":
        if stem:
            names += [stem + ext for ext in IMAGE_EXTENSIONS]
            names += [stem + "-poster" + ext for ext in IMAGE_EXTENSIONS]
        for base in ("poster", "folder", "cover", "movie", "season"):
            names += [base + ext for ext in IMAGE_EXTENSIONS]
    else:
        if stem:
            for suffix in ("-fanart", "-backdrop", "-background"):
                names += [stem + suffix + ext for ext in IMAGE_EXTENSIONS]
        for base in ("fanart", "backdrop", "background", "landscape"):
            names += [base + ext for ext in IMAGE_EXTENSIONS]
    return _first_existing([os.path.join(base_dir, name) for name in names])


def _attach_local_art(item, poster="", backdrop=""):
    if poster and os.path.isfile(poster):
        item["poster_local"] = poster
        item["_poster_local"] = poster
        item["_poster_source_local"] = poster
        item["_cin_provider_poster_local"] = poster
        item["_ultra_poster_source"] = poster
        item["_ultra_palette_source"] = poster
        item["_adaptive_source_local"] = poster
        item["_player_poster"] = poster
    if backdrop and os.path.isfile(backdrop):
        item["backdrop_local"] = backdrop
        item["_backdrop_source_local"] = backdrop
        item["_cin_provider_backdrop_local"] = backdrop
    return item


def _base_local_item(path, title, media_type="vod"):
    item_id = _stable_id("local-%s" % media_type, path)
    item = {
        "id": item_id,
        "movie_id": item_id if media_type == "vod" else None,
        "series_id": item_id if media_type == "series" else None,
        "name": str(title or ""),
        "title": str(title or ""),
        "_raw_name": str(title or ""),
        "_local_path": str(path or ""),
        "cmd": str(path or ""),
        "url": str(path or ""),
        "_source_type": "local",
        "source_type": "local",
        "_portal": "local://receiver",
        "_mac": "local",
        "_server_name": "Local",
        "_local_media": True,
        "_local_artwork_required": True,
        # Local has no provider TMDb id. Resolve the clean name first, then hand
        # the verified id to the one shared canonical HDD media library.
        "_local_name_first_identity": True,
        "_local_identity_title": str(title or ""),
        "media_type": ("tv" if media_type == "series" else ("episode" if media_type == "episode" else "movie")),
        "_provider_name": str(title or ""),
        "display_name": str(title or ""),
    }
    year = _year_from(os.path.basename(path) if path else title)
    if year:
        item["year"] = year
    item["_history_item"] = dict(item)
    return {k: v for k, v in item.items() if v is not None}


def _movie_item(path):
    title = _clean_filename(path)
    if _norm(title) in {_norm(x) for x in MOVIE_DIR_NAMES}|{"video","file"}:
        parent=os.path.basename(os.path.dirname(os.path.realpath(path)).rstrip("/"))
        if parent and _norm(parent) not in {_norm(x) for x in MOVIE_DIR_NAMES|SERIES_DIR_NAMES}:
            title=_clean_text(parent)
    item = _base_local_item(path, title, "vod")
    item["movie_name"]=title
    return _attach_local_art(item, _sidecar_art(path, "poster"), _sidecar_art(path, "backdrop"))


def _episode_item(path, title, season, episode, episode_title, series_item=None):
    item = _base_local_item(path, episode_title, "episode")
    item.update({
        "episode_id": item["id"],
        "episode": int(episode),
        "episode_number": int(episode),
        "number": int(episode),
        "season": int(season),
        "season_number": int(season),
        "series_title": title,
        "_series_title": title,
    })
    if isinstance(series_item, dict):
        item["_series_id"] = series_item.get("series_id") or series_item.get("id")
        poster = str(series_item.get("_poster_source_local") or series_item.get("poster_local") or "")
        if poster and os.path.isfile(poster):
            item["_player_poster"] = poster
            item["_adaptive_source_local"] = poster
    item["_history_item"] = dict(item)
    return item


def _make_local_profile(profile=None):
    out = dict(profile or {})
    out.update({
        "portal": "local://receiver",
        "mac": "LOCAL",
        "name": "Local",
        "source_type": "local",
        "type": "local",
    })
    # Never let stale provider credentials/source flags classify Local as M3U/Xtream.
    for key in ("m3u_url", "playlist_url", "xtream", "xtream_url"):
        out.pop(key, None)
    return out


class LocalMediaClient(object):
    """Tiny provider-compatible adapter backed exclusively by receiver storage."""
    PAGE_SIZE = 14

    def __init__(self, roots, mode):
        self.roots = list(roots or [])
        self.mode = "series" if str(mode) == "series" else "vod"
        self._items = None
        self._series = {}

    def _library_roots(self):
        """Return fast-path media folders first, then every local storage root.

        R56 stopped after finding e.g. /media/hdd/movie.  A receiver with an
        empty movie folder and real media under /media/hdd/vod therefore looked
        empty.  R57 keeps named folders only as scan-order hints; storage roots
        remain authoritative so arbitrary user folder names work too.
        """
        aliases = SERIES_DIR_NAMES if self.mode == "series" else MOVIE_DIR_NAMES
        preferred = _discover_named_dirs(self.roots, aliases)
        out=[];seen=set()
        for path in list(preferred)+list(self.roots):
            try:real=os.path.realpath(path)
            except Exception:continue
            if real in seen or not os.path.isdir(real):continue
            seen.add(real);out.append(real)
        return out

    def _scan_inventory(self, cancel_event=None):
        """Return persistent Local inventory; walk storage only on the first build.

        R60 deliberately keeps this index independent from TMDb/artwork. It stores
        only local paths/classification, while all metadata/artwork continues to
        live in the existing shared TMDb-ID HDD cache.
        """
        cached=_load_local_media_index(self.roots)
        if cached:
            return _decode_local_media_index(cached)
        videos=[];seen=set()
        # Scan each real storage root once. Named movie/series directories are
        # classification hints, not separate recursive scans of the same bytes.
        for base in list(self.roots or []):
            for path in _iter_video_files(base,cancel_event):
                if cancel_event is not None and cancel_event.is_set():return [],{}
                try:real=os.path.realpath(path)
                except Exception:continue
                if real in seen:continue
                seen.add(real);videos.append(real)
        videos.sort(key=_natural_key)

        direct={}
        for path in videos:
            parent=os.path.dirname(path);row=direct.setdefault(parent,{"files":[],"count":0,"simple_count":0,"ordinal":{}})
            row["files"].append(path);row["count"]+=1
            if _simple_episode_number(os.path.splitext(os.path.basename(path))[0]) is not None:row["simple_count"]+=1
        for parent,row in direct.items():
            for pos,path in enumerate(sorted(row.get("files") or [],key=_natural_key),1):row["ordinal"][os.path.realpath(path)]=pos

        named_series=_discover_named_dirs(self.roots,SERIES_DIR_NAMES)
        groups={};movies=[]
        for path in videos:
            parsed=_smart_series_identity(path,named_series,direct)
            if not parsed:
                movies.append(path);continue
            title,season,episode,episode_title,series_dir=parsed
            key=(_norm(title),os.path.realpath(series_dir))
            group=groups.setdefault(key,{"title":title,"dir":series_dir,"episodes":[]})
            group["episodes"].append((path,int(season),int(episode),episode_title))
        _save_local_media_index(self.roots,movies,groups)
        cached=_load_local_media_index(self.roots)
        return _decode_local_media_index(cached) if cached else (movies,groups)

    def _build_movies(self, cancel_event=None):
        movie_rows,_groups=self._scan_inventory(cancel_event)
        if cancel_event is not None and cancel_event.is_set():return []
        rows=[]
        for raw in movie_rows:
            if isinstance(raw,dict):
                path=str(raw.get("path") or "");title=str(raw.get("title") or "") or _clean_filename(path)
                item=_base_local_item(path,title,"vod");item["movie_name"]=title
                if raw.get("year"):item["year"]=str(raw.get("year"))[:4]
                rows.append(_attach_local_art(item,str(raw.get("poster") or ""),str(raw.get("backdrop") or "")))
            else:
                rows.append(_movie_item(str(raw)))
        rows.sort(key=lambda x:_natural_key(x.get("name") or ""))
        return rows

    def _build_series(self, cancel_event=None):
        _movie_paths,groups=self._scan_inventory(cancel_event)
        if cancel_event is not None and cancel_event.is_set():return []
        rows=[]
        for key,group in groups.items():
            episodes=sorted(group["episodes"],key=lambda x:(int(x[1]),int(x[2]),_natural_key(x[0])))
            if not episodes:continue
            series_dir=group["dir"]
            item=_base_local_item(series_dir,group["title"],"series")
            # Several SxxEyy shows may legally live in one generic folder.  The
            # playback path remains that real folder, but the logical series id
            # also includes the parsed show title so their season caches cannot
            # collide.
            logical_id=_stable_id("local-series",series_dir+"/__ultra_series__/"+_norm(group["title"]))
            item["id"]=logical_id;item["series_id"]=logical_id;item["series_name"]=group["title"]
            item["_history_item"]=dict(item)
            seasons=sorted({int(x[1]) for x in episodes})
            item["number_of_seasons"]=len(seasons);item["number_of_episodes"]=len(episodes)
            # Local-only structural identity hints.  They are never artwork keys;
            # they simply help a one-time name search distinguish same-title TV
            # shows before the verified TMDb id is written to the shared cache.
            item["_local_season_count"]=len(seasons)
            item["_local_max_season"]=max(seasons) if seasons else 0
            item["_local_episode_count"]=len(episodes)
            item["_local_series_key"]=item["id"];item["_local_series_dir"]=series_dir
            _attach_local_art(item,str(group.get("poster") or "") or _sidecar_art(series_dir,"poster"),str(group.get("backdrop") or "") or _sidecar_art(series_dir,"backdrop"))
            by_season={}
            for path,season,episode,episode_title in episodes:
                by_season.setdefault(int(season),[]).append(_episode_item(path,group["title"],season,episode,episode_title,item))
            self._series[item["id"]]=by_season;rows.append(item)
        rows.sort(key=lambda x:_natural_key(x.get("name") or ""))
        return rows

    def _ensure(self, cancel_event=None):
        if self._items is None:
            self._items = self._build_series(cancel_event) if self.mode == "series" else self._build_movies(cancel_event)
        return self._items

    def ordered_page(self, media_type, genre, page, cancel_event=None):
        rows = list(self._ensure(cancel_event) or [])
        page = max(1, int(page or 1));size = self.PAGE_SIZE
        start = (page - 1) * size
        return {"items": rows[start:start + size], "page_size": size, "total": len(rows)}

    def create_link(self, item_or_cmd, media_type="itv", series_id=None, cancel_event=None):
        if cancel_event is not None and cancel_event.is_set():
            return ""
        if isinstance(item_or_cmd, dict):
            return str(item_or_cmd.get("_local_path") or item_or_cmd.get("cmd") or item_or_cmd.get("url") or "")
        return str(item_or_cmd or "")

    def series_seasons(self, series_item, cancel_event=None):
        self._ensure(cancel_event)
        sid = str((series_item or {}).get("_local_series_key") or (series_item or {}).get("series_id") or (series_item or {}).get("id") or "")
        seasons = self._series.get(sid, {})
        rows = []
        for number in sorted(seasons):
            episodes = [dict(x) for x in seasons.get(number, []) if isinstance(x, dict)]
            rows.append({
                "id": int(number), "season_id": int(number), "season": int(number), "season_number": int(number),
                "name": _("Season %s") % int(number), "episodes": episodes, "series": episodes,
                "parent_series_id": sid, "episode_count": len(episodes),
            })
        return rows

    def series_episodes(self, series_item, season_item, cancel_event=None):
        if cancel_event is not None and cancel_event.is_set():
            return []
        self._ensure(cancel_event)
        sid = str((series_item or {}).get("_local_series_key") or (series_item or {}).get("series_id") or (series_item or {}).get("id") or "")
        try:
            sn = int((season_item or {}).get("season_number") or (season_item or {}).get("season") or (season_item or {}).get("season_id") or (season_item or {}).get("id") or 0)
        except Exception:
            sn = 0
        return [dict(x) for x in self._series.get(sid, {}).get(sn, []) if isinstance(x, dict)]

    def enrich_provider_artwork(self, item, media_type, cancel_event=None, force=False):
        return dict(item or {})

    def reset_failure_backoff(self, *args, **kwargs):
        return None

    def _bump_content_cache_generation(self, *args, **kwargs):
        return None


# ---------------------------------------------------------------------------
# Local root + manual Browse. Movies / Series use the existing Cinematic UI.
# ---------------------------------------------------------------------------
def _build_local_skin():
    parts = [r'''
<screen name="LocalLibraryScreen" position="center,center" size="1920,1080" backgroundColor="#02070b" flags="wfNoBorder">
 <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/category_palestine_static_1920x1080.jpg" alphatest="off" zPosition="0"/>
''']
    root_x = (495, 841, 1187);root_y = 840
    for i, x in enumerate(root_x):
        icon_x = x + (53 if i == 0 else 63)
        parts.append(' <widget name="root_bg%d" position="%d,%d" size="238,190" alphatest="blend" transparent="1" zPosition="5"/>\n' % (i, x, root_y))
        parts.append(' <widget name="root_icon%d" position="%d,%d" size="112,82" alphatest="blend" scale="1" transparent="1" zPosition="12"/>\n' % (i, icon_x, root_y + 22))
        parts.append(' <widget name="root_title%d" position="%d,%d" size="212,50" font="Regular;29" halign="center" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1"/>\n' % (i, x + 13, root_y + 116))
        parts.append(' <widget name="root_sel%d" position="%d,%d" size="238,190" alphatest="blend" transparent="1" zPosition="10"/>\n' % (i, x, root_y))

    xs = (55, 313, 571, 829, 1087, 1345, 1603);ys = (675, 885);slot = 0
    for y in ys:
        for x in xs:
            parts.append(' <widget name="grid_bg%d" position="%d,%d" size="238,190" alphatest="blend" transparent="1" zPosition="5"/>\n' % (slot, x, y))
            parts.append(' <widget name="grid_icon%d" position="%d,%d" size="112,82" alphatest="blend" scale="1" transparent="1" zPosition="12"/>\n' % (slot, x + 63, y + 18))
            parts.append(' <widget name="grid_title%d" position="%d,%d" size="212,66" font="Regular;20" halign="center" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1"/>\n' % (slot, x + 13, y + 108))
            parts.append(' <widget name="grid_sel%d" position="%d,%d" size="238,190" alphatest="blend" transparent="1" zPosition="10"/>\n' % (slot, x, y))
            slot += 1
    parts.append(' <widget name="refresh_status" position="55,1042" size="760,28" font="Regular;18" halign="left" valign="center" foregroundColor="#8fffc1" transparent="1" zPosition="30" noWrap="1"/>\n')
    parts.append("</screen>")
    return "".join(parts)


LOCAL_SKIN = _build_local_skin()


class LocalLibraryScreen(Screen):
    skin = LOCAL_SKIN
    PAGE_SIZE = 14;COLS = 7
    GRID_X = (55, 313, 571, 829, 1087, 1345, 1603);GRID_Y = (675, 885)

    def __init__(self, session, profile=None):
        Screen.__init__(self, session)
        self.profile = dict(profile or {})
        self.local_profile = _make_local_profile(self.profile)
        self.roots = _storage_roots()
        self.mode = "root";self.current_path = None;self.entries = [];self.index = 0;self._visuals_bound = False
        for i in range(3):
            self["root_bg%d" % i] = Pixmap();self["root_sel%d" % i] = Pixmap();self["root_icon%d" % i] = Pixmap();self["root_title%d" % i] = Label("")
        for i in range(self.PAGE_SIZE):
            self["grid_bg%d" % i] = Pixmap();self["grid_sel%d" % i] = Pixmap();self["grid_icon%d" % i] = Pixmap();self["grid_title%d" % i] = Label("")
        self["refresh_status"] = Label("")
        self._local_refresh_pending=False
        self._local_refresh_start_timer=eTimer();self._local_refresh_hide_timer=eTimer()
        self._local_refresh_start_conn=None;self._local_refresh_hide_conn=None
        try:self._local_refresh_start_conn=self._local_refresh_start_timer.timeout.connect(self._run_local_refresh)
        except Exception:self._local_refresh_start_timer.callback.append(self._run_local_refresh)
        try:self._local_refresh_hide_conn=self._local_refresh_hide_timer.timeout.connect(self._hide_local_refresh_status)
        except Exception:self._local_refresh_hide_timer.callback.append(self._hide_local_refresh_status)
        self.onClose.append(self._stop_local_refresh_timers)
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"], {
            "cancel": self.go_back, "ok": self.open_selected,
            "left": lambda: self._move(-1, 0), "right": lambda: self._move(1, 0),
            "up": lambda: self._move(0, -1), "down": lambda: self._move(0, 1),
            # No visible button is added. GREEN is a deliberate manual Local
            # re-index for newly copied media; normal entry never rescans.
            "green": self.refresh_local_index,
        }, -1)
        self.onLayoutFinish.append(self._first_paint)

    def refresh_local_index(self):
        # Manual refresh is intentionally available only on the three-card
        # Local Home. Show visible feedback first, then rebuild on the next UI
        # turn so the viewer can see that GREEN was accepted.
        if self.mode != "root" or getattr(self,"_local_refresh_pending",False):
            return
        self._local_refresh_pending=True
        try:self._local_refresh_hide_timer.stop()
        except Exception:pass
        try:self["refresh_status"].setText(_("Refreshing local library..."));self["refresh_status"].show()
        except Exception:pass
        try:self._local_refresh_start_timer.start(30,True)
        except Exception:self._run_local_refresh()

    def _run_local_refresh(self):
        ok=True
        try:
            self.roots = _storage_roots()
            _invalidate_local_media_index(self.roots)
            # Movies and Series share one inventory, so one scan rebuilds both.
            LocalMediaClient(self.roots, "vod")._scan_inventory(None)
        except Exception:
            ok=False
        self._local_refresh_pending=False
        try:
            self["refresh_status"].setText(_("Local library refreshed") if ok else _("Local refresh failed"))
            self["refresh_status"].show()
        except Exception:pass
        try:self._local_refresh_hide_timer.start(2200,True)
        except Exception:pass

    def _hide_local_refresh_status(self):
        try:self["refresh_status"].setText("");self["refresh_status"].hide()
        except Exception:pass

    def _stop_local_refresh_timers(self):
        for timer in (getattr(self,"_local_refresh_start_timer",None),getattr(self,"_local_refresh_hide_timer",None)):
            if timer is None:continue
            try:timer.stop()
            except Exception:pass
        for timer,conn,callback in (
            (getattr(self,"_local_refresh_start_timer",None),getattr(self,"_local_refresh_start_conn",None),self._run_local_refresh),
            (getattr(self,"_local_refresh_hide_timer",None),getattr(self,"_local_refresh_hide_conn",None),self._hide_local_refresh_status),
        ):
            if timer is None:continue
            try:
                if conn is not None:conn.disconnect()
            except Exception:pass
            try:
                if callback in timer.callback:timer.callback.remove(callback)
            except Exception:pass

    def _first_paint(self):
        self._bind_visuals();self.show_root()

    def _bind_visuals(self):
        if self._visuals_bound:return
        fixed = fixed_home_assets() or {};mood = fixed.get("mood") if isinstance(fixed.get("mood"), dict) else {};focus = fixed.get("focus") if isinstance(fixed.get("focus"), dict) else {}
        normal = str(mood.get("menu") or _asset("home129_menu_fallback.png"));selected = str(focus.get("menu") or _asset("home129_menu_focus.png"))
        for prefix, count in (("root", 3), ("grid", self.PAGE_SIZE)):
            for i in range(count):
                try:self["%s_bg%d" % (prefix, i)].instance.setPixmapFromFile(normal)
                except Exception:pass
                try:self["%s_sel%d" % (prefix, i)].instance.setPixmapFromFile(selected)
                except Exception:pass
        for i, name in enumerate(("home_movies.png", "home_series.png", "home_local.png")):
            try:self["root_icon%d" % i].instance.setPixmapFromFile(_asset(name))
            except Exception:pass
        self._visuals_bound = True

    def _hide_root(self):
        for i in range(3):
            for suffix in ("bg", "sel", "icon", "title"):
                try:self["root_%s%d" % (suffix, i)].hide()
                except Exception:pass

    def _hide_grid(self):
        for i in range(self.PAGE_SIZE):
            for suffix in ("bg", "sel", "icon", "title"):
                try:self["grid_%s%d" % (suffix, i)].hide()
                except Exception:pass

    def show_root(self):
        self.mode = "root";self.current_path = None;self.entries = [];self.index = max(0, min(2, self.index if self.index < 3 else 0));self._hide_grid()
        for i, title in enumerate((_("Movies"), _("Series"), "Browse")):
            for suffix in ("bg", "icon", "title"):
                try:self["root_%s%d" % (suffix, i)].show()
                except Exception:pass
            self["root_title%d" % i].setText(title)
        self._render_root_focus()

    def _render_root_focus(self):
        for i in range(3):
            try:(self["root_sel%d" % i].show() if i == self.index else self["root_sel%d" % i].hide())
            except Exception:pass

    def _open_cinematic(self, mode):
        self.roots = _storage_roots()
        client = LocalMediaClient(self.roots, "series" if mode == "series" else "vod")
        try:
            from .ui_cinematic_global import PremiumGlobalCinematicScreen
            media_type = "series" if mode == "series" else "vod"
            title = _("Series") if mode == "series" else _("Movies")
            self.session.open(PremiumGlobalCinematicScreen, self.local_profile, client, media_type, "*", title)
        except Exception:
            # Keep Local Home alive even if a receiver image rejects the child.
            return

    def _allowed(self, path):
        try:
            real = os.path.realpath(path)
            return any(real == r or real.startswith(r.rstrip("/") + "/") for r in self.roots)
        except Exception:return False

    def _storage_title(self, path):
        real=os.path.realpath(str(path or ""))
        if real == os.path.realpath("/media/hdd"):return "HDD"
        if real == os.path.realpath(RECEIVER_LOCAL_ROOT):return "Receiver"
        low=real.lower()
        if "usb" in low:return "USB"
        return os.path.basename(real.rstrip("/")) or real

    def _browse_root_entries(self):
        rows=[]
        for root in self.roots:
            rows.append({"kind":"storage","title":self._storage_title(root),"path":root,"icon":"home_local.png"})
        return rows

    def _browse_entries(self, path):
        rows = []
        try:names = os.listdir(path)
        except Exception:names = []
        for name in sorted(names, key=_natural_key):
            if name.startswith("."):continue
            full = os.path.join(path, name)
            try:
                if os.path.isdir(full):rows.append({"kind":"folder","title":name,"path":full,"icon":"home_local.png"})
                elif os.path.isfile(full) and os.path.splitext(name)[1].lower() in VIDEO_EXTENSIONS:rows.append({"kind":"file","title":_clean_filename(full),"path":full,"icon":"home_movies.png"})
            except Exception:pass
        return rows

    def _enter_browse(self):
        self.roots = _storage_roots()
        self.mode = "browse";self.current_path = None;self.index = 0
        self.entries = self._browse_root_entries()
        self._render_grid()

    def _render_grid(self):
        self._hide_root();page = int(self.index // self.PAGE_SIZE) if self.entries else 0;start = page * self.PAGE_SIZE;visible = self.entries[start:start + self.PAGE_SIZE]
        one_row = len(visible) <= self.COLS
        for slot in range(self.PAGE_SIZE):
            if slot >= len(visible):
                for suffix in ("bg", "sel", "icon", "title"):
                    try:self["grid_%s%d" % (suffix, slot)].hide()
                    except Exception:pass
                continue
            entry = visible[slot]
            col = slot % self.COLS;logical_row = slot // self.COLS
            # A single row sits on the bottom rail. Two rows occupy the final
            # 405 px of the page, leaving only 5 px below the bottom cards.
            row_y = self.GRID_Y[1] if one_row else self.GRID_Y[logical_row]
            icon_name = str(entry.get("icon") or "home_local.png")
            xoff = 53 if icon_name == "home_movies.png" else 63
            for suffix in ("bg", "sel", "icon", "title"):
                try:self["grid_%s%d" % (suffix, slot)].show()
                except Exception:pass
            try:
                self["grid_bg%d" % slot].instance.move(ePoint(self.GRID_X[col], row_y))
                self["grid_sel%d" % slot].instance.move(ePoint(self.GRID_X[col], row_y))
                self["grid_title%d" % slot].instance.move(ePoint(self.GRID_X[col] + 13, row_y + 108))
                inst = self["grid_icon%d" % slot].instance
                if inst is not None:
                    inst.move(ePoint(self.GRID_X[col] + xoff, row_y + 18));inst.setPixmapFromFile(_asset(icon_name))
            except Exception:pass
            self["grid_title%d" % slot].setText(str(entry.get("title") or "")[:42])
            try:(self["grid_sel%d" % slot].show() if (start + slot) == self.index else self["grid_sel%d" % slot].hide())
            except Exception:pass

    def _move(self, horizontal, vertical):
        if self.mode == "root":
            delta = horizontal if horizontal else vertical
            if delta:self.index = (self.index + (1 if delta > 0 else -1)) % 3;self._render_root_focus()
            return
        if not self.entries:return
        old = self.index
        if horizontal:self.index = max(0, min(len(self.entries)-1, self.index + (1 if horizontal > 0 else -1)))
        elif vertical:
            target = self.index + (self.COLS if vertical > 0 else -self.COLS)
            if 0 <= target < len(self.entries):self.index = target
            elif vertical > 0 and len(self.entries)-1 > self.index:self.index = len(self.entries)-1
        if old != self.index:self._render_grid()

    def open_selected(self):
        if self.mode == "root":
            if self.index == 0:self._open_cinematic("movies")
            elif self.index == 1:self._open_cinematic("series")
            else:self._enter_browse()
            return
        if not self.entries or not (0 <= self.index < len(self.entries)):return
        entry = self.entries[self.index];path = os.path.realpath(str(entry.get("path") or ""))
        if not self._allowed(path):return
        if entry.get("kind") in ("folder", "storage"):
            self.current_path = path;self.entries = self._browse_entries(path);self.index = 0;self._render_grid();return
        if entry.get("kind") != "file" or not os.path.isfile(path):return
        item = _movie_item(path);media_type = "episode" if _series_identity(path) else "vod"
        if media_type == "episode":
            parsed = _series_identity(path)
            if parsed:
                title, season, episode, ep_title, series_dir = parsed
                item = _episode_item(path, title, season, episode, ep_title)
        try:
            ref = self.session.nav.getCurrentlyPlayingServiceReference()
            if ref is not None:item["_return_service_ref_string"] = ref.toString()
        except Exception:pass
        try:engine = int(load_settings().get("service_type", 4097) or 4097)
        except Exception:engine = 4097
        if engine not in (4097, 5001, 5002, 8193):engine = 4097
        try:
            from .services.player import UltraStalkerPlayer
            self.session.open(UltraStalkerPlayer, path, str(item.get("name") or os.path.basename(path)), media_type, engine, item)
        except Exception:pass

    def go_back(self):
        if self.mode == "root":self.close();return
        # Browse chooser -> Local Home.  Inside a storage tree BACK always means
        # parent; at the storage root it returns to HDD / Receiver / USB chooser.
        if not self.current_path:
            self.show_root();return
        current = os.path.realpath(self.current_path)
        roots = {os.path.realpath(x) for x in self.roots}
        if current in roots:
            self.current_path = None;self.entries = self._browse_root_entries();self.index = 0;self._render_grid();return
        parent = os.path.dirname(current.rstrip("/")) or current
        if parent == current or not self._allowed(parent):
            self.current_path = None;self.entries = self._browse_root_entries();self.index = 0;self._render_grid();return
        self.current_path = parent;self.entries = self._browse_entries(parent);self.index = 0;self._render_grid()
