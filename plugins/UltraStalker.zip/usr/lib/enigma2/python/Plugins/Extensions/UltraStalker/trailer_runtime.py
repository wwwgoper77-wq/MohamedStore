# -*- coding: utf-8 -*-
"""Exact-TMDb trailer helpers for Ultra Stalker.

TMDb owns identity. This module never searches YouTube by title or year. It
resolves only the exact YouTube video key already attached to the verified item.
"""


def youtube_watch_url(video_key):
    key = str(video_key or "").strip()
    return ("https://www.youtube.com/watch?v=" + key) if key else ""


def trailer_from_rows(*rows):
    """Return the first exact cached trailer descriptor from metadata rows."""
    for row in rows:
        if not isinstance(row, dict):
            continue
        key = str(row.get("trailer_key") or "").strip()
        site = str(row.get("trailer_site") or "").strip().lower()
        if key and site in ("youtube", ""):
            return {
                "site": "YouTube",
                "key": key,
                "name": str(row.get("trailer_name") or "Trailer").strip() or "Trailer",
                "url": str(row.get("trailer_url") or youtube_watch_url(key)).strip(),
                "official": bool(row.get("trailer_official")),
                "language": str(row.get("trailer_language") or "").strip(),
            }
    return {}


def _resolve_with_ultrastalker(video_key, timeout=18):
    key = str(video_key or "").strip()
    if not key:
        return ""
    try:
        from .services.ultrastalker_youtube import UltraYouTubeResolver
        value = str(UltraYouTubeResolver().extract(key, timeout=max(5, int(timeout or 18))) or "").strip()
    except Exception:
        return ""
    return value if value.startswith(("http://", "https://")) else ""


def resolve_youtube_trailer(video_key, timeout=18, cancel_event=None):
    """Resolve an exact TMDb YouTube key to an Enigma2-playable media URL.

    UltraStalker prefers Full HD, then HD. Split YouTube video/audio is handed
    to Enigma2 using its native ``&suburi=`` convention. No title search is
    performed and no external resolver executable or plugin is consulted.
    """
    key = str(video_key or "").strip()
    if not key:
        return ""
    if cancel_event is not None:
        try:
            if cancel_event.is_set():
                return ""
        except Exception:
            pass
    value = _resolve_with_ultrastalker(key, timeout=timeout)
    if cancel_event is not None:
        try:
            if cancel_event.is_set():
                return ""
        except Exception:
            pass
    return value if value.startswith(("http://", "https://")) else ""
