# -*- coding: utf-8 -*-
# ==============================================================================
# Enigma2 Plugin: ChannelColorizer ARABIC V6 (MohamedStore Edition)
# \u0647\u0630\u0627 \u0627\u0644\u0628\u0644\u062c\u0646 \u0645\u062a\u0627\u062d \u0641\u064a \u0628\u0646\u0644 MohamedStore
# \u064a\u0639\u0627\u0644\u062c \u0646\u0647\u0627\u0626\u064a\u0627\u064b \u0645\u0634\u0643\u0644\u0629 \u0631\u062c\u0648\u0639 \u0644\u0648\u0646 \u0627\u0644\u0642\u0646\u0627\u0629 \u0648\u0627\u0644\u062a\u0631\u062f\u062f \u0644\u0644\u0648\u0646 \u0627\u0644\u0623\u0628\u064a\u0636 \u0639\u0646\u062f \u0641\u062a\u062d \u0627\u0644\u0642\u0646\u0627\u0629 (f:09)
# \u0645\u062a\u0648\u0627\u0641\u0642 100% \u0645\u0639 \u0635\u0648\u0631\u0629 EGAMI \u0648 OpenATV \u0648 OpenPLi (\u0628\u062f\u0648\u0646 \u062e\u0637\u0623 0xc7) + \u0623\u064a\u0642\u0648\u0646\u0629 plugin.png
# Directory: /usr/lib/enigma2/python/Plugins/Extensions/ChannelColorizer/
# ==============================================================================

from __future__ import print_function
import os
import sys
import re
import glob
import shutil

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.Label import Label
from Components.config import (
    config,
    ConfigSubsection,
    ConfigYesNo,
    ConfigSelection,
    getConfigListEntry,
    configfile
)
from enigma import eDVBDB

PY3 = sys.version_info[0] >= 3

def ar(text):
    """Ensure Arabic Unicode strings work in both Python 3 (EGAMI/OpenATV) and Python 2"""
    if PY3:
        return text
    try:
        if isinstance(text, unicode):
            return text.encode("utf-8")
    except Exception:
        pass
    return text

# ------------------------------------------------------------------------------
# 1. \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0623\u0644\u0648\u0627\u0646 \u0628\u0627\u0644\u0644\u063a\u0629 \u0627\u0644\u0639\u0631\u0628\u064a\u0629 (\u0645\u062d\u0645\u064a\u0629 \u0636\u062f \u062e\u0637\u0623 0xC7 \u0641\u064a \u0635\u0648\u0631\u0629 EGAMI)
# ------------------------------------------------------------------------------
COLOR_CHOICES = [
    ("FF4D6D", ar(u"\u0627\u0644\u0644\u0648\u0646 \u0627\u0644\u0645\u062e\u0635\u0635 \u0644\u0644\u0645\u0634\u0641\u0631 (#FF4D6D)")),
    ("FFD600", ar(u"\u0627\u0644\u0644\u0648\u0646 \u0627\u0644\u0645\u062e\u0635\u0635 \u0644\u0644\u0645\u0641\u062a\u0648\u062d (#FFD600)")),
    ("00E5FF", ar(u"\u0627\u0644\u0644\u0648\u0646 \u0627\u0644\u0645\u062e\u0635\u0635 \u0644\u0640 IPTV (#00E5FF)")),
    ("FF4D6D", ar(u"\u0623\u062d\u0645\u0631 \u0648\u0631\u062f\u064a \u0633\u0627\u0637\u0639")),
    ("FFD600", ar(u"\u0623\u0635\u0641\u0631 \u0630\u0647\u0628\u064a \u0633\u0627\u0637\u0639")),
    ("F59E0B", ar(u"\u0630\u0647\u0628\u064a \u0643\u0647\u0631\u0645\u0627\u0646\u064a")),
    ("10B981", ar(u"\u0623\u062e\u0636\u0631 \u0632\u0645\u0631\u062f\u064a")),
    ("FF3366", ar(u"\u0623\u062d\u0645\u0631 \u0642\u0631\u0645\u0632\u064a")),
    ("00E676", ar(u"\u0623\u062e\u0636\u0631 \u0633\u0627\u0637\u0639")),
    ("00E5FF", ar(u"\u0623\u0632\u0631\u0642 \u0633\u0645\u0627\u0648\u064a \u0645\u0634\u0639")),
    ("FF6D00", ar(u"\u0628\u0631\u062a\u0642\u0627\u0644\u064a \u0646\u0627\u0631\u064a")),
    ("76FF03", ar(u"\u0623\u062e\u0636\u0631 \u0644\u064a\u0645\u0648\u0646\u064a")),
    ("38BDF8", ar(u"\u0623\u0632\u0631\u0642 \u0647\u0627\u062f\u0626")),
    ("E040FB", ar(u"\u0628\u0646\u0641\u0633\u062c\u064a \u0645\u0634\u0639")),
    ("FF80AB", ar(u"\u0648\u0631\u062f\u064a \u0641\u0627\u062a\u062d")),
    ("F8FAFC", ar(u"\u0623\u0628\u064a\u0636 \u0646\u0642\u064a")),
    ("94A3B8", ar(u"\u0641\u0636\u064a \u0631\u0645\u0627\u062f\u064a"))
]

seen_hex = set()
UNIQUE_COLOR_CHOICES = []
for hex_val, label in COLOR_CHOICES:
    if hex_val not in seen_hex:
        seen_hex.add(hex_val)
        UNIQUE_COLOR_CHOICES.append((hex_val, label))

config.plugins.ChannelColorizer = ConfigSubsection()
config.plugins.ChannelColorizer.enabled = ConfigYesNo(default=True)
config.plugins.ChannelColorizer.encrypted_color = ConfigSelection(
    default="FF4D6D",
    choices=UNIQUE_COLOR_CHOICES
)
config.plugins.ChannelColorizer.fta_color = ConfigSelection(
    default="FFD600",
    choices=UNIQUE_COLOR_CHOICES
)
config.plugins.ChannelColorizer.iptv_color = ConfigSelection(
    default="00E5FF",
    choices=UNIQUE_COLOR_CHOICES
)
config.plugins.ChannelColorizer.lock_transponder_colors = ConfigYesNo(
    default=True
)
config.plugins.ChannelColorizer.add_symbol_prefix = ConfigYesNo(
    default=False
)


def hex_to_enigma_color_tag(hex_str):
    clean = hex_str.strip().lstrip("#").upper()
    if len(clean) == 8:
        clean = clean[2:]
    clean = clean[:6].zfill(6)
    return "\\c00" + clean


def strip_existing_color_tags(text):
    if not text:
        return text
    cleaned = re.sub(r'(\\c[0-9a-fA-F]{8})', '', text)
    for sym in (ar(u"[\u0645\u0634\u0641\u0631] "), ar(u"[\u0645\u0641\u062a\u0648\u062d] "), "[$] ", "[FTA] "):
        if cleaned.startswith(sym):
            cleaned = cleaned[len(sym):]
    return cleaned.strip()


def apply_true_hold_name_and_nosdt_flags(provider_line, enable_lock=True):
    """
    \u0642\u0641\u0644 \u0627\u0644\u0642\u0646\u0627\u0629 \u0628\u0627\u0644\u0639\u0644\u0645 (f:09 = dxNoSDT 0x01 + dxHoldName 0x08) \u0641\u064a \u0646\u0648\u0627\u0629 \u0627\u0644\u0625\u0646\u062c\u064a\u0645\u0627 C++
    \u0644\u0645\u0646\u0639 \u0631\u062c\u0648\u0639 \u0627\u0644\u0642\u0646\u0627\u0629 \u0625\u0644\u0649 \u0627\u0644\u0644\u0648\u0646 \u0627\u0644\u0623\u0628\u064a\u0636 \u0627\u0644\u0623\u0635\u0644\u064a \u0639\u0646\u062f \u0641\u062a\u062d\u0647\u0627!
    """
    stripped = provider_line.rstrip("\r\n")
    parts = stripped.split(",")
    found_f = False
    new_parts = []

    for part in parts:
        if part.startswith("f:"):
            found_f = True
            try:
                cur_flag = int(part[2:], 16)
                cur_flag = cur_flag & (~0x04)
                if enable_lock:
                    new_flag = cur_flag | 0x09
                else:
                    new_flag = cur_flag & (~0x09)
                if new_flag > 0:
                    new_parts.append("f:%02x" % new_flag)
            except Exception:
                if enable_lock:
                    new_parts.append("f:09")
        else:
            new_parts.append(part)

    if not found_f and enable_lock:
        new_parts.append("f:09")

    return ",".join(new_parts) + "\n"


def disable_enigma_background_sdt_scan():
    try:
        if hasattr(config, "usage") and hasattr(config.usage, "disable_background_scan"):
            config.usage.disable_background_scan.value = True
            config.usage.disable_background_scan.save()
        if hasattr(config, "scan") and hasattr(config.scan, "sdt"):
            config.scan.sdt.value = False
            config.scan.sdt.save()
    except Exception:
        pass


def open_utf8(filepath, mode="r"):
    if PY3:
        return open(filepath, mode, encoding="utf-8", errors="ignore")
    return open(filepath, mode)


# ------------------------------------------------------------------------------
# 2. \u0627\u0644\u0645\u062d\u0631\u0643 \u0627\u0644\u062c\u0630\u0631\u064a \u0644\u062a\u0644\u0648\u064a\u0646 \u0627\u0644\u0642\u0646\u0648\u0627\u062a \u0648\u0642\u0641\u0644\u0647\u0627 \u0628\u0640 (f:09 = dxNoSDT + dxHoldName)
# ------------------------------------------------------------------------------
def apply_direct_database_colorizing(restore_original=False):
    enigma_dir = "/etc/enigma2"
    enc_hex = config.plugins.ChannelColorizer.encrypted_color.value
    fta_hex = config.plugins.ChannelColorizer.fta_color.value
    iptv_hex = config.plugins.ChannelColorizer.iptv_color.value
    use_prefix = config.plugins.ChannelColorizer.add_symbol_prefix.value
    lock_names = config.plugins.ChannelColorizer.lock_transponder_colors.value

    if lock_names and not restore_original:
        disable_enigma_background_sdt_scan()

    enc_tag = hex_to_enigma_color_tag(enc_hex)
    fta_tag = hex_to_enigma_color_tag(fta_hex)
    iptv_tag = hex_to_enigma_color_tag(iptv_hex)

    encrypted_refs = set()
    colored_count = {"encrypted": 0, "fta": 0, "iptv": 0}

    # A) Process /etc/enigma2/lamedb
    lamedb_path = os.path.join(enigma_dir, "lamedb")
    if os.path.isfile(lamedb_path):
        bak_path = lamedb_path + ".orig_backup"
        if not os.path.isfile(bak_path):
            try:
                shutil.copy2(lamedb_path, bak_path)
            except Exception:
                pass

        try:
            with open_utf8(lamedb_path, "r") as f:
                lines = f.readlines()

            new_lines = []
            in_services = False
            i = 0
            n = len(lines)

            while i < n:
                line = lines[i]
                stripped = line.strip()

                if stripped == "services":
                    in_services = True
                    new_lines.append(line)
                    i += 1
                    continue
                elif stripped == "end" and in_services:
                    in_services = False
                    new_lines.append(line)
                    i += 1
                    continue

                if in_services and (i + 2) < n and ":" in stripped:
                    ref_line = line
                    name_line = lines[i + 1]
                    provider_line = lines[i + 2]

                    ref_parts = stripped.split(":")
                    if len(ref_parts) >= 6:
                        is_crypted = (",C:" in provider_line) or provider_line.strip().startswith("C:")
                        clean_name = strip_existing_color_tags(name_line.rstrip("\r\n"))

                        try:
                            sid = int(ref_parts[0], 16)
                            ns = int(ref_parts[1], 16)
                            tsid = int(ref_parts[2], 16)
                            onid = int(ref_parts[3], 16)
                            ref_key = "%X:%X:%X:%X" % (sid, tsid, onid, ns)
                            if is_crypted:
                                encrypted_refs.add(ref_key.upper())
                        except Exception:
                            pass

                        if restore_original or not config.plugins.ChannelColorizer.enabled.value:
                            new_name_line = clean_name + "\n"
                            new_provider_line = apply_true_hold_name_and_nosdt_flags(provider_line, False)
                        else:
                            prefix_str = (ar(u"[\u0645\u0634\u0641\u0631] ") if is_crypted else ar(u"[\u0645\u0641\u062a\u0648\u062d] ")) if use_prefix else ""
                            tag = enc_tag if is_crypted else fta_tag
                            new_name_line = tag + prefix_str + clean_name + "\n"
                            new_provider_line = apply_true_hold_name_and_nosdt_flags(provider_line, lock_names)
                            if is_crypted:
                                colored_count["encrypted"] += 1
                            else:
                                colored_count["fta"] += 1

                        new_lines.append(ref_line)
                        new_lines.append(new_name_line)
                        new_lines.append(new_provider_line)
                        i += 3
                        continue

                new_lines.append(line)
                i += 1

            with open_utf8(lamedb_path, "w") as f:
                f.writelines(new_lines)
        except Exception as err:
            print("[ChannelColorizer] Error processing lamedb:", str(err))

    # B) Process /etc/enigma2/lamedb5
    lamedb5_path = os.path.join(enigma_dir, "lamedb5")
    if os.path.isfile(lamedb5_path):
        bak5_path = lamedb5_path + ".orig_backup"
        if not os.path.isfile(bak5_path):
            try:
                shutil.copy2(lamedb5_path, bak5_path)
            except Exception:
                pass

        try:
            with open_utf8(lamedb5_path, "r") as f:
                lines5 = f.readlines()

            new_lines5 = []
            for line in lines5:
                if line.startswith("s:"):
                    parts = line.split('"', 2)
                    if len(parts) >= 3:
                        before_name = parts[0]
                        ch_name = parts[1]
                        after_name = parts[2]
                        is_crypted = (",C:" in after_name) or ("C:" in after_name)
                        clean_name = strip_existing_color_tags(ch_name)

                        if restore_original or not config.plugins.ChannelColorizer.enabled.value:
                            new_ch_name = clean_name
                            new_after = apply_true_hold_name_and_nosdt_flags(after_name, False)
                        else:
                            prefix_str = (ar(u"[\u0645\u0634\u0641\u0631] ") if is_crypted else ar(u"[\u0645\u0641\u062a\u0648\u062d] ")) if use_prefix else ""
                            tag = enc_tag if is_crypted else fta_tag
                            new_ch_name = tag + prefix_str + clean_name
                            new_after = apply_true_hold_name_and_nosdt_flags(after_name, lock_names)

                        new_lines5.append('%s"%s"%s' % (before_name, new_ch_name, new_after))
                        continue
                new_lines5.append(line)

            with open_utf8(lamedb5_path, "w") as f:
                f.writelines(new_lines5)
        except Exception as err:
            print("[ChannelColorizer] Error processing lamedb5:", str(err))

    # C) Process /etc/enigma2/userbouquet.*.tv
    bouquet_files = glob.glob(os.path.join(enigma_dir, "userbouquet.*.tv"))
    for bq_path in bouquet_files:
        try:
            with open_utf8(bq_path, "r") as f:
                bq_lines = f.readlines()

            new_bq_lines = []
            last_service_is_iptv = False
            last_service_is_crypted = False

            for line in bq_lines:
                if line.startswith("#SERVICE "):
                    srv_str = line[9:].strip()
                    srv_parts = srv_str.split(":")
                    last_service_is_iptv = ("http" in srv_str.lower()) or srv_str.startswith("4097:") or srv_str.startswith("5001:") or srv_str.startswith("5002:")
                    last_service_is_crypted = False
                    if len(srv_parts) >= 7:
                        ref_key = "%s:%s:%s:%s" % (srv_parts[3].upper(), srv_parts[4].upper(), srv_parts[5].upper(), srv_parts[6].upper())
                        if ref_key in encrypted_refs:
                            last_service_is_crypted = True
                    new_bq_lines.append(line)
                elif line.startswith("#DESCRIPTION "):
                    desc_text = line[13:].rstrip("\r\n")
                    clean_desc = strip_existing_color_tags(desc_text)
                    if restore_original or not config.plugins.ChannelColorizer.enabled.value:
                        new_bq_lines.append("#DESCRIPTION " + clean_desc + "\n")
                    else:
                        if last_service_is_iptv:
                            tag = iptv_tag
                            colored_count["iptv"] += 1
                        elif last_service_is_crypted:
                            tag = enc_tag
                        else:
                            tag = fta_tag
                        new_bq_lines.append("#DESCRIPTION " + tag + clean_desc + "\n")
                else:
                    new_bq_lines.append(line)

            with open_utf8(bq_path, "w") as f:
                f.writelines(new_bq_lines)
        except Exception as err:
            print("[ChannelColorizer] Error processing bouquet:", bq_path, str(err))

    # D) Force eDVBDB in C++ RAM to reload immediately
    try:
        db = eDVBDB.getInstance()
        db.reloadServicelist()
        db.reloadBouquets()
    except Exception as err:
        print("[ChannelColorizer] eDVBDB reload warning:", str(err))

    return colored_count


# ------------------------------------------------------------------------------
# 3. \u062d\u0627\u0631\u0633 \u0627\u0644\u062a\u0644\u0648\u064a\u0646 \u0627\u0644\u062a\u0644\u0642\u0627\u0626\u064a (Auto-Guard Hook when opening Channel List)
# ------------------------------------------------------------------------------
_guard_installed = False

def install_channel_selection_guard():
    global _guard_installed
    if _guard_installed:
        return
    try:
        from Screens.ChannelSelection import ChannelSelection
        if hasattr(ChannelSelection, "zap"):
            orig_zap = ChannelSelection.zap
            def guarded_zap(self, *args, **kwargs):
                res = orig_zap(self, *args, **kwargs)
                try:
                    if config.plugins.ChannelColorizer.enabled.value and config.plugins.ChannelColorizer.lock_transponder_colors.value:
                        eDVBDB.getInstance().reloadServicelist()
                except Exception:
                    pass
                return res
            ChannelSelection.zap = guarded_zap
        _guard_installed = True
    except Exception as err:
        print("[ChannelColorizer] Guard hook info:", str(err))


# ------------------------------------------------------------------------------
# 4. \u0634\u0627\u0634\u0629 \u0627\u0644\u0625\u0639\u062f\u0627\u062f\u0627\u062a \u0627\u0644\u0639\u0631\u0628\u064a\u0629 \u062f\u0627\u062e\u0644 \u0627\u0644\u0631\u0633\u064a\u0641\u0631 \u0645\u0639 \u0634\u0639\u0627\u0631 MohamedStore
# ------------------------------------------------------------------------------
class ChannelColorizerSetupScreen(ConfigListScreen, Screen):
    skin = """
    <screen name="ChannelColorizerSetupScreen" position="center,center" size="880,580" title="\u0645\u0644\u0648\u0646 \u0627\u0644\u0642\u0646\u0648\u0627\u062a - MohamedStore - MohamedStore">
        <widget name="store_banner" position="20,15" size="840,45" font="Regular;24" halign="center" valign="center" foregroundColor="#FBBF24" backgroundColor="#0F172A" />
        <widget name="config" position="20,75" size="840,330" itemHeight="40" font="Regular;22" scrollbarMode="showOnDemand" />
        <widget name="preview_box" position="20,420" size="840,70" font="Regular;20" halign="center" valign="center" foregroundColor="#F8FAFC" backgroundColor="#1E293B" />
        <widget name="key_red" position="20,515" zPosition="1" size="180,40" font="Regular;19" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#9F1313" />
        <widget name="key_green" position="220,515" zPosition="1" size="220,40" font="Regular;19" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#1F771F" />
        <widget name="key_yellow" position="460,515" zPosition="1" size="220,40" font="Regular;19" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#A08500" />
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.list = []
        ConfigListScreen.__init__(self, self.list, session=self.session)

        self["store_banner"] = Label(ar(u"\u2605 \u0647\u0630\u0627 \u0627\u0644\u0628\u0644\u062c\u0646 \u0645\u062a\u0627\u062d \u0641\u064a \u0628\u0646\u0644 MohamedStore \u2605"))
        self["key_red"] = Label(ar(u"\u0625\u063a\u0644\u0627\u0642"))
        self["key_green"] = Label(ar(u"\u062a\u0637\u0628\u064a\u0642 \u0648\u0642\u0641\u0644 \u0627\u0644\u0623\u0644\u0648\u0627\u0646"))
        self["key_yellow"] = Label(ar(u"\u0627\u0633\u062a\u0639\u0627\u062f\u0629 \u0627\u0644\u0623\u0635\u0644"))
        self["preview_box"] = Label(ar(u"\u0647\u0630\u0627 \u0627\u0644\u0628\u0644\u062c\u0646 \u0645\u062a\u0627\u062d \u0641\u064a \u0628\u0646\u0644 MohamedStore - \u0627\u062e\u062a\u0631 \u0627\u0644\u0623\u0644\u0648\u0627\u0646 \u062b\u0645 \u0627\u0636\u063a\u0637 \u0627\u0644\u0632\u0631 \u0627\u0644\u0623\u062e\u0636\u0631 \u0644\u0644\u062d\u0641\u0638 \u0648\u0627\u0644\u062a\u062b\u0628\u064a\u062a"))

        self["actions"] = ActionMap(
            ["SetupActions", "ColorActions"],
            {
                "ok": self.keySave,
                "save": self.keySave,
                "green": self.keySave,
                "cancel": self.keyCancel,
                "red": self.keyCancel,
                "yellow": self.restoreOriginalColors,
            },
            -2
        )
        self.createSetupList()

    def createSetupList(self):
        self.list = [
            getConfigListEntry(ar(u"\u062a\u0641\u0639\u064a\u0644 \u062a\u0644\u0648\u064a\u0646 \u0627\u0644\u0642\u0646\u0648\u0627\u062a:"), config.plugins.ChannelColorizer.enabled),
            getConfigListEntry(ar(u"\u0644\u0648\u0646 \u0627\u0644\u0642\u0646\u0648\u0627\u062a \u0627\u0644\u0645\u0634\u0641\u0631\u0629:"), config.plugins.ChannelColorizer.encrypted_color),
            getConfigListEntry(ar(u"\u0644\u0648\u0646 \u0627\u0644\u0642\u0646\u0648\u0627\u062a \u0627\u0644\u0645\u0641\u062a\u0648\u062d\u0629:"), config.plugins.ChannelColorizer.fta_color),
            getConfigListEntry(ar(u"\u0644\u0648\u0646 \u0642\u0646\u0648\u0627\u062a \u0627\u0644\u0628\u062b IPTV:"), config.plugins.ChannelColorizer.iptv_color),
            getConfigListEntry(ar(u"\u0645\u0646\u0639 \u0631\u062c\u0648\u0639 \u0627\u0644\u0642\u0646\u0627\u0629 \u0644\u0644\u0648\u0646 \u0627\u0644\u0623\u0628\u064a\u0636 \u0639\u0646\u062f \u0641\u062a\u062d\u0647\u0627 (\u0642\u0641\u0644 f:09):"), config.plugins.ChannelColorizer.lock_transponder_colors),
            getConfigListEntry(ar(u"\u0625\u0636\u0627\u0641\u0629 \u0643\u0644\u0645\u0629 [\u0645\u0634\u0641\u0631] \u0648 [\u0645\u0641\u062a\u0648\u062d] \u0642\u0628\u0644 \u0627\u0633\u0645 \u0627\u0644\u0642\u0646\u0627\u0629:"), config.plugins.ChannelColorizer.add_symbol_prefix),
        ]
        self["config"].list = self.list
        self["config"].l.setList(self.list)

    def restoreOriginalColors(self):
        apply_direct_database_colorizing(restore_original=True)
        self.session.open(
            MessageBox,
            ar(u"\u062a\u0645\u062a \u0627\u0633\u062a\u0639\u0627\u062f\u0629 \u0623\u0633\u0645\u0627\u0621 \u0648\u0623\u0644\u0648\u0627\u0646 \u0627\u0644\u0642\u0646\u0648\u0627\u062a \u0627\u0644\u0623\u0635\u0644\u064a\u0629 \u0628\u0646\u062c\u0627\u062d!\n\n\u0647\u0630\u0627 \u0627\u0644\u0628\u0644\u062c\u0646 \u0645\u062a\u0627\u062d \u0641\u064a \u0628\u0646\u0644 MohamedStore"),
            MessageBox.TYPE_INFO,
            timeout=4
        )

    def keySave(self):
        for x in self["config"].list:
            x[1].save()
        configfile.save()
        install_channel_selection_guard()
        stats = apply_direct_database_colorizing(restore_original=not config.plugins.ChannelColorizer.enabled.value)
        msg = ar(u"\u062a\u0645 \u062a\u0644\u0648\u064a\u0646 \u0627\u0644\u0642\u0646\u0648\u0627\u062a \u0648\u0642\u0641\u0644\u0647\u0627 \u0628\u0646\u062c\u0627\u062d!\n\n- \u0627\u0644\u0642\u0646\u0648\u0627\u062a \u0627\u0644\u0645\u0634\u0641\u0631\u0629 \u0627\u0644\u0645\u0644\u0648\u0646\u0629: %d\n- \u0627\u0644\u0642\u0646\u0648\u0627\u062a \u0627\u0644\u0645\u0641\u062a\u0648\u062d\u0629 \u0627\u0644\u0645\u0644\u0648\u0646\u0629: %d\n\n\u2605 \u0647\u0630\u0627 \u0627\u0644\u0628\u0644\u062c\u0646 \u0645\u062a\u0627\u062d \u0641\u064a \u0628\u0646\u0644 MohamedStore \u2605") % (
            stats.get("encrypted", 0),
            stats.get("fta", 0)
        )
        self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=6)
        self.close()

    def keyCancel(self):
        for x in self["config"].list:
            x[1].cancel()
        self.close()


def sessionstart(reason, **kwargs):
    if reason == 0:
        install_channel_selection_guard()


def main(session, **kwargs):
    install_channel_selection_guard()
    session.open(ChannelColorizerSetupScreen)


def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name=ar(u"\u0645\u0644\u0648\u0646 \u0627\u0644\u0642\u0646\u0648\u0627\u062a - MohamedStore"),
            description=ar(u"\u0647\u0630\u0627 \u0627\u0644\u0628\u0644\u062c\u0646 \u0645\u062a\u0627\u062d \u0641\u064a \u0628\u0646\u0644 MohamedStore"),
            where=[PluginDescriptor.WHERE_PLUGINMENU, PluginDescriptor.WHERE_EXTENSIONSMENU],
            icon="plugin.png",
            fnc=main
        ),
        PluginDescriptor(
            where=[PluginDescriptor.WHERE_SESSIONSTART],
            fnc=sessionstart
        )
    ]
