#!/bin/sh
# =========================================================================
# VU+ / Enigma2 Universal Channel Package Installer
# Compatible with OpenATV, OpenPLi, Egami, BlackHole, and DreamOS
# Optimized for fixed satellite systems.
# Generated on: 2026-07-06
# =========================================================================

echo "================================================"
echo "Installing Universal Channel Settings..."
echo "Target Image: OPENATV"
echo "================================================"

# Backup existing settings
echo "1. Creating backup of current settings in /etc/enigma2/backup_settings..."
mkdir -p /etc/enigma2/backup_settings
cp /etc/enigma2/lamedb /etc/enigma2/backup_settings/ 2>/dev/null
cp /etc/enigma2/bouquets.tv /etc/enigma2/backup_settings/ 2>/dev/null
cp /etc/enigma2/userbouquet.* /etc/enigma2/backup_settings/ 2>/dev/null
cp /etc/tuxbox/satellites.xml /etc/enigma2/backup_settings/ 2>/dev/null

# Copy new settings
echo "2. Installing satellites.xml..."
cp -f tuxbox/satellites.xml /etc/tuxbox/

echo "3. Copying Enigma2 DB and channel bouquets..."
cp -f enigma2/* /etc/enigma2/

# Set strict permissions
echo "4. Adjusting file permissions..."
chmod 644 /etc/tuxbox/satellites.xml
chmod 644 /etc/enigma2/lamedb
chmod 644 /etc/enigma2/bouquets.tv
chmod 644 /etc/enigma2/userbouquet.*.tv

# Reload channel lists
echo "5. Reloading service list on receiver..."
wget -qO - http://127.0.0.1/web/servicelistreload?mode=0 || wget -qO - http://127.0.0.1/web/servicelistreload?mode=4

echo "================================================"
echo "Installation completed successfully!"
echo "Enjoy your channels!"
echo "================================================"
