VU+ Receiver Channel Package Installation Manual
-----------------------------------------------------------
Configured for: OPENATV
Satellites included: Astra (19.2°E), Hotbird (13.0°E)

METHOD 1: Automated Installation (Recommended for quick setup)
1. Extract the downloaded ZIP file to your computer.
2. Upload the entire extracted folder to your VU+ receiver's '/tmp' directory using an FTP client (e.g., FileZilla).
3. Connect to your VU+ receiver via SSH or Telnet (using PuTTY or terminal).
   - Default IP: Check your receiver's Network settings.
   - Default Username: 'root'
   - Default Password: (empty, 'root', or 'dreambox')
4. Run the following command:
   sh /tmp/enigma2_package/install.sh
5. Done! The receiver will reload services automatically.

METHOD 2: FTP Manual Transfer (For DreamBoxEdit or Dreambox Explorer)
1. Extract the ZIP package.
2. Copy the file 'tuxbox/satellites.xml' to your receiver's directory:
   '/etc/tuxbox/' (overwrite if exists)
3. Copy all files inside the 'enigma2/' folder to your receiver's directory:
   '/etc/enigma2/' (overwrite if exists)
4. Execute service list reload using your browser. Type the following URL (replace VU_IP with your receiver IP):
   http://VU_IP/web/servicelistreload?mode=0
   Or restart the receiver completely via GUI.

METHOD 3: DiSEqC Fixed Dish Configuration
Since you have a Fixed Dish setup, please configure your LNB ports in Enigma2 exactly as follows:
- Tuner A Config: Simple
- Mode: DiSEqC A/B (or A/B/C/D depending on LNB count)
  * Port A: Astra (19.2°E)
  * Port B: Hotbird (13.0°E)
